// Model picker — a 🧠 toolbar button that opens a sheet of Claude Code models.
// Tapping a row sends `/model <arg>` + Enter to the active pane (the same
// mechanism tmux-web's model picker falls back to for subscription models).
//
// Ported from tmux-web's CC_MODELS list (public/index.html) — args verified
// against Claude Code aliases + the [1m] 1M-context suffix + `default`.
// mobile-agent has no subscription<->gateway wrapper concept, so we skip the
// server-side /api/model-switch dance and just send the slash command.
//
// Touch handling mirrors the other plugins: tabIndex=-1 + mousedown
// .preventDefault so a tap never blurs the input; the sheet opens on `click`
// (a trailing synthetic click would otherwise close a just-opened overlay).
const CC_MODELS = [
  { name: 'Fable 5', arg: 'fable', icon: '📖' },
  { name: 'Sonnet 5', arg: 'sonnet', icon: '🎵' },
  { name: 'Opus 4.8', arg: 'opus', icon: '🎭' },
  { name: 'Opus 4.8 · 1M ctx', arg: 'opus[1m]', icon: '🔭' },
  { name: 'Haiku 4.5', arg: 'haiku', icon: '⚡' },
  { name: 'Account default', arg: 'default', icon: '↩' },
];

export default function init(host) {
  const btn = document.createElement('button');
  btn.textContent = '🧠';
  btn.title = 'Switch Claude Code model (/model)';
  btn.style.cssText = 'flex:0 0 auto;font:inherit;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer';
  btn.tabIndex = -1;
  btn.addEventListener('mousedown', (e) => e.preventDefault());
  host.mount('toolbar', btn);

  // Track the active session so the sheet header can show it (mirrors tmux-web).
  let active = '';
  host.bus.on('terminal.active', ({ session }) => { active = session || ''; });

  btn.onclick = () => {           // click, not pointerup — avoids trailing-click closing the sheet
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center';
    const box = document.createElement('div');
    box.style.cssText = 'background:var(--chrome);border:1px solid var(--border);border-radius:12px;padding:8px;min-width:280px;max-width:92vw;display:flex;flex-direction:column;gap:2px';

    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:6px 8px 8px';
    const title = document.createElement('span');
    title.style.cssText = 'font-size:13px;color:var(--fg)';
    title.innerHTML = 'Switch model · <b style="color:var(--accent)">' + (active || '—') + '</b>';
    const close = document.createElement('div');
    close.textContent = '×'; close.style.cssText = 'font-size:20px;color:var(--fg);opacity:.6;cursor:pointer;line-height:1;padding:0 4px';
    close.onclick = () => back.remove();
    head.append(title, close);
    box.appendChild(head);

    for (const m of CC_MODELS) {
      const row = document.createElement('button');
      row.tabIndex = -1;
      row.addEventListener('mousedown', (e) => e.preventDefault());
      row.style.cssText = 'display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:10px 10px;border-radius:8px;border:1px solid transparent;background:transparent;color:var(--fg);cursor:pointer;font:inherit';
      row.innerHTML =
        '<span style="font-size:18px;width:22px;text-align:center;flex-shrink:0">' + m.icon + '</span>' +
        '<span style="font-size:14px;flex:1">' + m.name + '</span>' +
        '<span style="font-size:11px;color:var(--fg);opacity:.5;font-family:monospace">/model ' + m.arg + '</span>';
      row.onclick = () => {
        back.remove();
        host.bus.emit('terminal.input', { data: '/model ' + m.arg });
        host.bus.emit('terminal.input', { key: 'Enter' });
      };
      box.appendChild(row);
    }

    back.appendChild(box);
    back.onclick = (e) => { if (e.target === back) back.remove(); };
    host.mount('footer', back);
  };
}
