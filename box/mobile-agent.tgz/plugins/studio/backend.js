// Studio — makes the app malleable + safe. Git-checkpoints the config dir
// (config.json + user plugins + settings), auto-commits on every edit, and
// exposes checkpoint/history/revert + config (enable/disable/order) + an AI
// customize launcher. The "save state so I can revert" Pi lacks.
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

module.exports = function setup(ctx) {
  const dir = ctx.configDir;                       // the git-tracked root
  const userPlugins = path.join(dir, 'plugins');
  const configFile = path.join(dir, 'config.json');
  const git = (args) => execSync(`git ${args}`, { cwd: dir, encoding: 'utf8' });
  const gitOk = (args) => { try { return git(args); } catch (e) { ctx.log('git', args, 'failed:', e.message); return null; } };

  // --- one-time: make the config dir a git repo (checkpoints) ----------------
  try {
    if (!fs.existsSync(path.join(dir, '.git'))) {
      fs.writeFileSync(path.join(dir, '.gitignore'), 'uploads/\n*.jsonl\npush-vapid.json\npush-subs.json\n');
      git('init -q'); git('add -A'); git('-c user.name=studio -c user.email=studio@local commit -q -m "initial checkpoint" --allow-empty');
      ctx.log('git checkpoint repo initialized at', dir);
    }
  } catch (e) { ctx.log('git init failed:', e.message); }

  // keep presets/ out of checkpoints (local state; copies, some secret-bearing-stripped)
  try { const gi = path.join(dir, '.gitignore'); let cur = ''; try { cur = fs.readFileSync(gi, 'utf8'); } catch {} if (!cur.split('\n').includes('presets/')) fs.writeFileSync(gi, cur + (cur && !cur.endsWith('\n') ? '\n' : '') + 'presets/\n'); } catch {}

  function commit(msg) { gitOk('add -A'); return gitOk(`-c user.name=studio -c user.email=studio@local commit -q -m ${JSON.stringify(msg)} --allow-empty`); }

  // === Presets: named, switchable app configurations (distinct from checkpoints,
  // which are the linear undo timeline). A preset captures look + behavior but NOT
  // secrets — API keys stay in the live files, untouched by switching. ===========
  const presetsDir = path.join(dir, 'presets');
  const curFile = path.join(presetsDir, '.current');
  const CAPTURE = ['config.json', 'voice.json', 'ask-profiles.json', 'tabs.json']; // synced settings
  const KEEP_ENABLED = ['studio', 'terminal', 'tabs', 'theme']; // never let a preset strand the user
  const rj = (p) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return null; } };
  const wj = (p, o) => fs.writeFileSync(p, JSON.stringify(o, null, 2));
  function stripSecrets(f, o) {
    if (f === 'voice.json') { const x = { ...o }; delete x.groqKey; delete x.deepgramKey; return x; }
    if (f === 'ask-profiles.json') { const x = { ...o }; x.profiles = (x.profiles || []).map((p) => { const q = { ...p }; delete q.apiKey; return q; }); return x; }
    return o;
  }
  function mergeKeys(f, o) { // restore preset settings but keep the LIVE keys
    const live = rj(path.join(dir, f)) || {};
    if (f === 'voice.json') return { ...o, groqKey: live.groqKey || '', deepgramKey: live.deepgramKey || '' };
    if (f === 'ask-profiles.json') { const lk = {}; (live.profiles || []).forEach((p) => { lk[p.id] = p.apiKey; }); return { ...o, profiles: (o.profiles || []).map((p) => ({ ...p, apiKey: lk[p.id] || '' })) }; }
    return o;
  }
  const setCurrent = (n) => { fs.mkdirSync(presetsDir, { recursive: true }); fs.writeFileSync(curFile, n); };
  const getCurrent = () => { try { return fs.readFileSync(curFile, 'utf8').trim(); } catch { return null; } };
  const listPresets = () => { try { return fs.readdirSync(presetsDir).filter((n) => !n.startsWith('.') && fs.statSync(path.join(presetsDir, n)).isDirectory()); } catch { return []; } };
  const safeName = (n) => String(n || '').trim().replace(/[^\w .-]/g, '_').slice(0, 40);

  function savePreset(name, client) {
    const pdir = path.join(presetsDir, name);
    fs.rmSync(pdir, { recursive: true, force: true }); fs.mkdirSync(pdir, { recursive: true });
    for (const f of CAPTURE) { const o = rj(path.join(dir, f)); if (o) wj(path.join(pdir, f), stripSecrets(f, o)); }
    if (fs.existsSync(userPlugins)) fs.cpSync(userPlugins, path.join(pdir, 'plugins'), { recursive: true });
    wj(path.join(pdir, 'client-state.json'), client || {});
    setCurrent(name);
  }
  function switchPreset(name) {
    const pdir = path.join(presetsDir, name);
    if (!fs.existsSync(pdir)) return null;
    commit(`before switching to preset: ${name}`);              // safety checkpoint
    for (const f of CAPTURE) {
      const o = rj(path.join(pdir, f)); if (!o) continue;
      let out = mergeKeys(f, o);
      if (f === 'config.json') out.disabled = (out.disabled || []).filter((id) => !KEEP_ENABLED.includes(id));
      wj(path.join(dir, f), out);
    }
    const pp = path.join(pdir, 'plugins');
    if (fs.existsSync(pp)) { fs.rmSync(userPlugins, { recursive: true, force: true }); fs.cpSync(pp, userPlugins, { recursive: true }); }
    setCurrent(name);
    ctx.reloadAll();
    return rj(path.join(pdir, 'client-state.json')) || {};
  }

  ctx.route('presets', (req, res) => json(res, { current: getCurrent(), names: listPresets() }));
  ctx.route('savePreset', async (req, res) => { const b = await body(req); const n = safeName(b.name); if (!n) return json(res, { ok: false, error: 'bad name' }); savePreset(n, b.client || {}); json(res, { ok: true, current: getCurrent(), names: listPresets() }); });
  ctx.route('switchPreset', async (req, res) => { const b = await body(req); const cs = switchPreset(safeName(b.name)); json(res, cs === null ? { ok: false } : { ok: true, client: cs }); });
  ctx.route('deletePreset', async (req, res) => { const b = await body(req); const n = safeName(b.name); fs.rmSync(path.join(presetsDir, n), { recursive: true, force: true }); if (getCurrent() === n) { try { fs.rmSync(curFile); } catch {} } json(res, { ok: true, current: getCurrent(), names: listPresets() }); });

  // auto-checkpoint on every user-plugin edit (debounced)
  let acTimer = null;
  ctx.onUserEdit((id) => { clearTimeout(acTimer); acTimer = setTimeout(() => commit(`auto: edit ${id}`), 1500); });

  // checkpoint-before-mutation: the omnibox (ask) emits app.checkpoint before a
  // confirmed structural change so it can always be reverted.
  ctx.onEvent('app.checkpoint', (d) => commit(`before: ${(d && d.label) || 'change'}`));

  // --- seed the plugin-authoring contract for the AI session -----------------
  fs.mkdirSync(userPlugins, { recursive: true });
  const agentsMd = path.join(userPlugins, 'AGENTS.md');
  if (!fs.existsSync(agentsMd)) fs.writeFileSync(agentsMd, AGENTS_DOC);
  const ex = path.join(userPlugins, 'example-button');
  if (!fs.existsSync(ex)) {
    fs.mkdirSync(ex, { recursive: true });
    fs.writeFileSync(path.join(ex, 'plugin.json'), JSON.stringify({ id: 'example-button', name: 'Example Button', frontend: 'frontend.js', version: '0.0.1' }, null, 2));
    fs.writeFileSync(path.join(ex, 'frontend.js'), EXAMPLE_FRONTEND);
  }

  // capped: config/preset JSON is small; a runaway POST must not buffer forever.
  // (A preset's client-state snapshot is localStorage — comfortably under 1 MiB.)
  function body(req) { return new Promise((r) => { const c = []; let n = 0; req.on('data', (x) => { n += x.length; if (n > 4 << 20) { req.destroy(); return r({}); } c.push(x); }); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString())); } catch { r({}); } }); }); }
  const json = (res, o) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };

  ctx.route('info', (req, res) => json(res, { userPlugins }));
  ctx.route('config', (req, res) => { let c = {}; try { c = JSON.parse(fs.readFileSync(configFile, 'utf8')); } catch {} json(res, c); });
  ctx.route('setconfig', async (req, res) => { const b = await body(req); fs.writeFileSync(configFile, JSON.stringify({ disabled: b.disabled || [], order: b.order || [] }, null, 2)); commit('config change'); json(res, { ok: true }); });
  ctx.route('checkpoint', async (req, res) => { const b = await body(req); commit(`checkpoint: ${b.label || 'manual'}`); json(res, { ok: true, hash: (gitOk('rev-parse --short HEAD') || '').trim() }); });
  ctx.route('history', (req, res) => {
    const out = gitOk("log --pretty=format:'%h|%s|%cr' -n 25") || '';
    const items = out.split('\n').filter(Boolean).map((l) => { const [hash, subject, when] = l.split('|'); return { hash, subject, when }; });
    json(res, { items });
  });
  ctx.route('revert', async (req, res) => {
    const b = await body(req); const ref = (b.hash || '').replace(/[^a-f0-9~^]/gi, '');
    if (!ref) return json(res, { ok: false });
    commit('before revert');                 // safety: snapshot current first
    gitOk(`reset --hard ${ref}`);
    ctx.reloadAll();                          // re-scan plugins (files changed)
    json(res, { ok: true });
  });

  ctx.log('ready');
};

const AGENTS_DOC = `# Authoring plugins for mobile-agent (appcore)

This folder holds **user plugins**. Drop a plugin here and it loads live (no
restart). A plugin = a folder with \`plugin.json\` + optional \`frontend.js\`
(browser) and/or \`backend.js\` (node). A user plugin with the same \`id\` as a
shipped one OVERRIDES it.

## plugin.json
\`\`\`json
{ "id": "my-thing", "name": "My Thing", "frontend": "frontend.js", "version": "0.0.1" }
\`\`\`

## frontend.js — runs in the browser, gets \`host\`
\`\`\`js
export default function init(host) {
  const b = document.createElement('button');
  b.textContent = 'hi';
  host.mount('toolbar', b);              // slots: header, main, toolbar, accessory, footer
  b.onclick = () => host.bus.emit('terminal.input', { data: 'echo hi' });
}
\`\`\`
- host.mount(slot, el) — add UI to a named slot
- host.bus.emit(topic, data) / host.bus.on(topic, fn) — talk to other plugins
  (terminal.input {data|key}, terminal.switch {session}, terminal.insertText {text})
- host.send(type, payload) / host.on(type, fn) — talk to THIS plugin's backend (ws)
- host.api(subpath, init) — fetch this plugin's backend route (/api/p/<id>/<subpath>)
- host.storage.get/set(key, val) — persisted, per-plugin

## backend.js — runs in node, gets \`ctx\`
\`\`\`js
module.exports = (ctx) => {
  ctx.route('hello', (req, res) => { res.end('hi'); });   // GET /api/p/<id>/hello
  ctx.on('ping', (payload, client) => client.send('pong', {}));
  // ctx.broadcast, ctx.emit/onEvent, ctx.storage, ctx.configDir, ctx.log
};
\`\`\`

Edits hot-reload automatically and are git-checkpointed — revert from the
Studio panel (🛠) if something breaks. See \`example-button/\` for a template.
`;

const EXAMPLE_FRONTEND = `// Example user plugin: a toolbar button that types a command into the agent.
export default function init(host) {
  const b = document.createElement('button');
  b.textContent = '👋'; b.title = 'example';
  b.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg)';
  host.mount('toolbar', b);
  b.onclick = () => host.bus.emit('terminal.insertText', { text: 'hello from a user plugin ' });
}
`;
