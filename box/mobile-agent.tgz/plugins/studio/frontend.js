// Studio panel (🛠): make the app malleable from inside it.
//  • Plugins: enable/disable + reorder (writes config.json, applies live)
//  • Checkpoints: save state + revert (git, the safety net)
//  • Customize with AI: open a Claude Code session in the user-plugins dir
export default function init(host) {
  const btn = document.createElement('button');
  btn.textContent = '🛠'; btn.title = 'customize (studio)';
  btn.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer';
  btn.tabIndex = -1;
  host.mount('toolbar', btn);

  const api = (sub, init) => host.api(sub, init).then((r) => r.json());
  const post = (sub, b) => host.api(sub, { method: 'POST', body: JSON.stringify(b || {}), headers: { 'content-type': 'application/json' } }).then((r) => r.json());

  function sheet(title) {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:300;background:var(--bg);display:flex;flex-direction:column';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid var(--border);flex:0 0 auto';
    const h = document.createElement('div'); h.textContent = title; h.style.cssText = 'font-size:15px;font-weight:bold;color:var(--fg)';
    const x = document.createElement('button'); x.textContent = '✕'; x.style.cssText = 'font-size:13px;width:28px;height:28px;border-radius:4px;border:1px solid var(--border);background:transparent;color:var(--fg)';
    x.onclick = () => back.remove();
    head.append(h, x);
    const bodyEl = document.createElement('div'); bodyEl.style.cssText = 'flex:1;overflow-y:auto;padding:14px 16px;display:flex;flex-direction:column;gap:20px';
    back.append(head, bodyEl); document.body.appendChild(back);
    return { back, bodyEl };
  }
  const sectionTitle = (t) => { const d = document.createElement('div'); d.textContent = t; d.style.cssText = 'font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:#888;margin-bottom:8px'; return d; };
  const mkBtn = (t, primary) => { const b = document.createElement('button'); b.textContent = t; b.style.cssText = `font:inherit;font-size:12px;padding:5px 10px;border-radius:4px;cursor:pointer;border:1px solid ${primary ? 'var(--accent)' : 'var(--border)'};background:${primary ? 'var(--accent)' : 'transparent'};color:${primary ? 'var(--accent-fg)' : 'var(--fg)'}`; return b; };

  async function open() {
    const { back, bodyEl } = sheet('Customize');
    const inst = await (await fetch((window.__APP_BASE === '/' ? '' : window.__APP_BASE.slice(0, -1)) + '/api/instance')).json();
    const cfg = await api('config');
    const disabled = new Set(cfg.disabled || []);
    let order = cfg.order && cfg.order.length ? cfg.order.slice() : inst.available.map((p) => p.id);
    // include any not in order, at the end
    for (const p of inst.available) if (!order.includes(p.id)) order.push(p.id);

    // ---- Customize with AI ----
    const aiSec = document.createElement('div');
    aiSec.append(sectionTitle('Customize with AI'));
    const aiBtn = mkBtn('✨ Open a Claude session in the plugins folder', true);
    const aiNote = document.createElement('div'); aiNote.style.cssText = 'font-size:11px;color:#888;margin-top:6px';
    aiNote.textContent = 'Ask it to add buttons, change layout, write plugins — changes apply live and are checkpointed.';
    aiBtn.onclick = async () => {
      const { userPlugins } = await api('info');
      host.bus.emit('terminal.createSession', { name: 'app-studio', cc: true, cwd: userPlugins });
      host.bus.emit('terminal.switchWhenReady', { session: 'app-studio' });
      back.remove();
    };
    aiSec.append(aiBtn, aiNote);

    // ---- Presets (named, switchable app setups) ----
    const prSec = document.createElement('div');
    prSec.append(sectionTitle('Presets — saved app setups'));
    const prState = document.createElement('div'); prState.style.cssText = 'display:flex;flex-direction:column;gap:6px';
    const prSaveRow = document.createElement('div'); prSaveRow.style.cssText = 'display:flex;gap:8px;margin-top:8px';
    const prInput = document.createElement('input'); prInput.placeholder = 'Save current as…';
    prInput.style.cssText = 'flex:1;font:inherit;font-size:13px;padding:7px 9px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--fg)';
    const prSave = mkBtn('Save', true);
    prSaveRow.append(prInput, prSave);
    const prNote = document.createElement('div'); prNote.style.cssText = 'font-size:11px;color:#777;margin-top:6px';
    prNote.textContent = 'Captures plugins, layout, theme & settings (not API keys). Switching saves a checkpoint first.';
    prSec.append(prState, prSaveRow, prNote);
    const dumpClient = () => { const o = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); o[k] = localStorage.getItem(k); } return o; };
    const applyClient = (o) => { try { localStorage.clear(); for (const k in o) localStorage.setItem(k, o[k]); } catch {} };
    async function renderPresets() {
      const { current, names } = await api('presets');
      prState.textContent = '';
      if (!names.length) { const e = document.createElement('div'); e.style.cssText = 'font-size:12px;color:#777'; e.textContent = 'No presets yet — save your current setup below.'; prState.appendChild(e); return; }
      for (const n of names) {
        const isCur = n === current;
        const row = document.createElement('div'); row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:8px';
        const nm = document.createElement('div'); nm.style.cssText = `flex:1;font-size:13px;color:${isCur ? 'var(--accent)' : 'var(--fg)'}`; nm.textContent = n + (isCur ? ' · current' : '');
        const use = mkBtn(isCur ? 'current' : 'switch', isCur); if (!isCur) use.onclick = async () => { const r = await post('switchPreset', { name: n }); if (r && r.ok) { applyClient(r.client || {}); location.reload(); } };
        const upd = mkBtn('update'); upd.title = 'overwrite this preset with the current state'; upd.onclick = async () => { await post('savePreset', { name: n, client: dumpClient() }); renderPresets(); };
        const del = mkBtn('✕'); del.onclick = async () => { await post('deletePreset', { name: n }); renderPresets(); };
        row.append(nm, use, upd, del); prState.appendChild(row);
      }
    }
    prSave.onclick = async () => { const n = prInput.value.trim(); if (!n) return; await post('savePreset', { name: n, client: dumpClient() }); prInput.value = ''; renderPresets(); };
    renderPresets();

    // ---- Plugins (enable/disable + reorder) ----
    const plSec = document.createElement('div');
    plSec.append(sectionTitle('Plugins — toggle & reorder'));
    const list = document.createElement('div'); list.style.cssText = 'display:flex;flex-direction:column;gap:6px';
    plSec.append(list);
    async function saveCfg() { await post('setconfig', { disabled: [...disabled], order }); }
    function renderList() {
      list.textContent = '';
      for (let i = 0; i < order.length; i++) {
        const id = order[i]; const meta = inst.available.find((p) => p.id === id); if (!meta) continue;
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:9px 10px;border:1px solid var(--border);border-radius:8px';
        const name = document.createElement('div'); name.style.cssText = 'flex:1;font-size:13px';
        name.innerHTML = `${meta.name} ${meta.user ? '<span style="color:var(--accent);font-size:10px">user</span>' : ''}`;
        if (disabled.has(id)) name.style.opacity = '0.4';
        const up = mkBtn('↑'); const dn = mkBtn('↓'); const tog = mkBtn(disabled.has(id) ? 'off' : 'on', !disabled.has(id));
        up.onclick = () => { if (i > 0) { [order[i - 1], order[i]] = [order[i], order[i - 1]]; saveCfg(); renderList(); } };
        dn.onclick = () => { if (i < order.length - 1) { [order[i + 1], order[i]] = [order[i], order[i + 1]]; saveCfg(); renderList(); } };
        tog.onclick = () => { if (disabled.has(id)) disabled.delete(id); else disabled.add(id); saveCfg(); renderList(); };
        row.append(name, up, dn, tog); list.appendChild(row);
      }
    }
    renderList();

    // ---- Checkpoints ----
    const cpSec = document.createElement('div');
    cpSec.append(sectionTitle('Checkpoints — save & revert'));
    const cpRow = document.createElement('div'); cpRow.style.cssText = 'display:flex;gap:8px;margin-bottom:8px';
    const cpBtn = mkBtn('✓ Checkpoint now', true);
    cpRow.append(cpBtn);
    const histEl = document.createElement('div'); histEl.style.cssText = 'display:flex;flex-direction:column;gap:5px';
    cpSec.append(cpRow, histEl);
    async function renderHist() {
      const { items } = await api('history');
      histEl.textContent = '';
      for (const it of items) {
        const r = document.createElement('div'); r.style.cssText = 'display:flex;align-items:center;gap:8px;font-size:12px;padding:6px 8px;border-bottom:1px solid var(--border)';
        const t = document.createElement('div'); t.style.cssText = 'flex:1;color:#bbb'; t.innerHTML = `${it.subject} <span style="color:#777">· ${it.when}</span>`;
        const rev = mkBtn('revert'); rev.onclick = async () => { await post('revert', { hash: it.hash }); back.remove(); };
        r.append(t, rev); histEl.appendChild(r);
      }
    }
    cpBtn.onclick = async () => { await post('checkpoint', { label: 'manual' }); renderHist(); };
    renderHist();

    bodyEl.append(aiSec, prSec, plSec, cpSec);
  }

  btn.onclick = () => open();   // click, not pointerup (avoids the trailing-click flicker)

  // omni (ask) integration: expose customize/checkpoint/toggle/revert by language
  const omniActions = [
    { id: 'studio.open', title: 'Open the Customize panel', args: [], mutates: false, run: () => open() },
    { id: 'studio.checkpoint', title: 'Save a checkpoint', hint: 'git-snapshot the whole app config', args: [{ name: 'label' }], mutates: false, run: (a) => post('checkpoint', { label: a.label || 'omni' }) },
    { id: 'studio.toggle', title: 'Enable/disable an app plugin', hint: 'set off:true to hide it', args: [{ name: 'id', desc: 'plugin id' }, { name: 'off', desc: 'true=disable, false=enable' }], mutates: true,
      run: async (a) => { const cfg = await api('config'); const dis = new Set(cfg.disabled || []); const order = cfg.order || []; if (a.off === false) dis.delete(a.id); else dis.add(a.id); await post('setconfig', { disabled: [...dis], order }); } },
    { id: 'studio.revertLast', title: 'Undo the last change', hint: 'revert to the previous checkpoint', args: [], mutates: true,
      run: async () => { const { items } = await api('history'); if (items && items[1]) await post('revert', { hash: items[1].hash }); } },
  ];
  const announceOmni = () => omniActions.forEach((x) => host.bus.emit('omni.action', x));
  host.bus.on('omni.collect', announceOmni);
  announceOmni();
}
