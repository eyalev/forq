// Router — "one main agent that orchestrates topic areas".
//
// The pattern: you stop addressing threads/tabs and just say what you want.
// The router owns a set of AREAS (a topic == a project == a tmux session with
// an agent in it), classifies each message into one (or several) of them,
// rewrites it as a self-contained instruction, dispatches it into that area's
// agent, then watches the turn and brings the answer back to the ONE feed you
// are reading. Work happens in parallel across areas; you only ever talk here.
//
// Division of labour with the terminal plugin (which owns tmux):
//   - writes go through `agent.prompt` (terminal does the verified submit) —
//     terminal stays the only writer to a pane;
//   - turn state comes from the `session.states` event (terminal's poller);
//   - READS of the pane happen here (capture-pane is read-only and we need our
//     own baseline snapshots, one per dispatch).
//
// Provider config is SHARED with the ask plugin (same configDir, same
// ask-profiles.json): setting up a key twice for one app would be silly, and
// the router is the same kind of decision-maker as the omnibox.
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const { replyFromDiff, gist } = require('./reply');

const MAX_TASKS = 200;          // feed history kept on disk
const SETTLE_POLLS = 2;         // consecutive idle polls (~2s each) = turn over
const MAX_TURN_MS = 25 * 60e3;  // a turn that never ends is reported, not hidden
const NO_START_MS = 90e3;       // injected but the pane never moved

module.exports = function setup(ctx) {
  const areasFile = path.join(ctx.configDir, 'router.json');
  const tasksFile = path.join(ctx.configDir, 'router-tasks.json');
  const logFile = path.join(ctx.configDir, 'router-log.jsonl');
  const profilesFile = path.join(ctx.configDir, 'ask-profiles.json');

  // Feed + log are churn, not configuration: keep them out of Studio's
  // checkpoints (it makes configDir a git repo). router.json IS configuration
  // (your areas) and stays tracked on purpose.
  try {
    if (fs.existsSync(path.join(ctx.configDir, '.git'))) {
      const gi = path.join(ctx.configDir, '.gitignore');
      let cur = ''; try { cur = fs.readFileSync(gi, 'utf8'); } catch {}
      const have = cur.split('\n');
      let add = '';
      for (const f of ['router-tasks.json', 'router-log.jsonl']) if (!have.includes(f)) add += f + '\n';
      if (add) fs.writeFileSync(gi, cur + (cur && !cur.endsWith('\n') ? '\n' : '') + add);
    }
  } catch (e) { ctx.log('gitignore ensure failed:', e.message); }

  const jlog = (rec) => { try { fs.appendFileSync(logFile, JSON.stringify({ ts: new Date().toISOString(), ...rec }) + '\n'); } catch {} };

  // Every tmux name that reaches a shell string must be validated — an area
  // bound to `x; rm -rf ~` would otherwise be remote code execution (the same
  // hole the terminal plugin closed at every entry point).
  const validName = (s) => typeof s === 'string' && s.length > 0 && s.length <= 64 && /^[A-Za-z0-9_.-]+$/.test(s);
  const RD = { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] };
  const capture = (session, lines = 400) => {
    if (!validName(session)) return '';
    try { return execSync(`tmux capture-pane -p -t ${session} -S -${lines}`, { ...RD, maxBuffer: 8 * 1024 * 1024 }); } catch { return ''; }
  };

  // ---- areas ---------------------------------------------------------------
  // { areas:[{id,name,emoji,session,about,auto}], dismissed:[session] }
  const readAreas = () => { try { return JSON.parse(fs.readFileSync(areasFile, 'utf8')); } catch { return { areas: [], dismissed: [] }; } };
  const writeAreas = (s) => { try { fs.writeFileSync(areasFile, JSON.stringify(s, null, 2)); } catch (e) { ctx.log('areas save failed:', e.message); } };
  let store = readAreas();
  if (!Array.isArray(store.areas)) store.areas = [];
  if (!Array.isArray(store.dismissed)) store.dismissed = [];

  const EMOJI = ['🟣', '🟢', '🔵', '🟠', '🟡', '🔴', '🟤', '⚪'];
  const prettify = (s) => s.replace(/[-_]+/g, ' ').replace(/\s*\d+$/, '').trim() || s;

  // Zero-config: a session the app shows as a tab becomes a routable area on
  // sight (including one created minutes ago), unless you deleted it — that is
  // the difference between "set up your router" and "just talk".
  function syncAreas(sessions) {
    let changed = false;
    const known = new Set(store.areas.map((a) => a.session));
    for (const s of sessions) {
      if (known.has(s.session) || store.dismissed.includes(s.session)) continue;
      store.areas.push({
        id: s.session, session: s.session, name: prettify(s.session),
        emoji: EMOJI[store.areas.length % EMOJI.length], about: '', auto: true,
      });
      changed = true;
    }
    // an area whose session is gone stays listed (the project didn't stop
    // existing because the tab was closed) but is marked offline by liveAreas()
    if (changed) { writeAreas(store); broadcastAreas(); }
  }

  let lastStates = {};
  const liveAreas = () => store.areas.map((a) => ({
    ...a,
    online: !!lastStates[a.session],
    state: (lastStates[a.session] || {}).state || 'offline',
    cwd: (lastStates[a.session] || {}).cwd || '',
  }));

  // ---- tasks (the feed) ----------------------------------------------------
  // { id, ts, text, areaId, session, title, prompt, status, why, tier, model,
  //   route_ms, startedAt, doneAt, reply, error }
  let tasks = [];
  try { tasks = JSON.parse(fs.readFileSync(tasksFile, 'utf8')).tasks || []; } catch {}
  // nothing survives a restart mid-turn: the pane moved on without us
  for (const t of tasks) if (['queued', 'dispatched', 'working', 'needs-you'].includes(t.status)) { t.status = 'interrupted'; }
  const runtime = new Map();   // taskId -> { baseline, idle, sawActive, injectedAt }

  let saveTimer = null;
  const persist = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => { try { fs.writeFileSync(tasksFile, JSON.stringify({ tasks: tasks.slice(-MAX_TASKS) }, null, 2)); } catch {} }, 300);
  };
  const broadcastTasks = () => { ctx.broadcast('tasks', { tasks: tasks.slice(-60) }); persist(); };
  const broadcastAreas = () => ctx.broadcast('areas', { areas: liveAreas() });
  const newId = () => 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  // ---- provider (shared with the ask plugin) --------------------------------
  function profile() {
    try {
      const s = JSON.parse(fs.readFileSync(profilesFile, 'utf8'));
      const p = (s.profiles || []).find((x) => x.id === s.activeId) || (s.profiles || [])[0];
      return p && p.apiKey ? p : null;
    } catch { return null; }
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function callLLM(prof, system, user) {
    const url = String(prof.baseURL || '').replace(/\/$/, '') + '/chat/completions';
    const payload = JSON.stringify({
      model: prof.model, temperature: 0, response_format: { type: 'json_object' },
      messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
    });
    let lastErr;
    for (let attempt = 0; attempt < 3; attempt++) {
      let r;
      try { r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${prof.apiKey}` }, body: payload, signal: AbortSignal.timeout(30_000) }); }
      catch (e) { lastErr = e; if (attempt < 2) { await sleep(400 * 2 ** attempt); continue; } throw e; }
      if (r.ok) {
        const data = await r.json();
        const content = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
        if (!content) throw new Error('empty response');
        try { return JSON.parse(content); } catch { throw new Error('model did not return JSON'); }
      }
      const txt = (await r.text().catch(() => '')).slice(0, 200);
      lastErr = new Error(`${r.status} ${txt}`);
      if ((r.status === 429 || r.status >= 500) && attempt < 2) {
        const ra = Number(r.headers.get('retry-after'));
        await sleep(Math.min(ra ? ra * 1000 : 400 * 2 ** attempt, 4000));
        continue;
      }
      throw lastErr;
    }
    throw lastErr || new Error('route failed');
  }

  function sysPrompt(areas) {
    const list = areas.map((a) => `- id "${a.id}" · ${a.name}${a.about ? ` — ${a.about}` : ''}${a.cwd ? ` (dir: ${a.cwd})` : ''}${a.state && a.state !== 'offline' ? ` [${a.state}]` : ' [offline]'}`).join('\n');
    return `You are the ROUTER for a phone app that drives several AI coding agents at once. Each AREA is one project with its own always-running agent. The user speaks to you in one place; you decide which area's agent should do the work, and you hand that agent a self-contained instruction.

AREAS:
${list}

Reply with ONLY a JSON object:
{"tasks":[{"area":"<area id>","title":"<3-6 word label>","prompt":"<instruction for that area's agent>"}],"why":"<one short sentence: why these areas>","confidence":<0..1>}

Rules:
- Usually exactly ONE task. Emit several ONLY when the message genuinely asks for work in several areas ("bump the version everywhere", "and also ...").
- "prompt" is what the agent will literally receive. Keep the user's intent and wording; add only the minimum context they left implicit (they are already inside that project — never restate the repo path). Do not invent requirements, do not add pleasantries, do not answer the request yourself.
- "title" names the work, not the area (the area is shown next to it).
- Pick the best area even when the fit is loose, and lower "confidence" instead of refusing. Never invent an area id that is not listed.
- An [offline] area is fine to pick if it is clearly the right one; the app will report that it could not be reached.`;
  }

  // Tier 0 — free, instant, no model. Explicit "@area rest" wins over anything
  // an LLM might infer, and a single-area setup has nothing to decide.
  function localRoute(text, areas) {
    const m = String(text).match(/^@([A-Za-z0-9_.-]+)\s+([\s\S]+)$/);
    if (m) {
      const key = m[1].toLowerCase();
      const hit = areas.find((a) => a.id.toLowerCase() === key || a.session.toLowerCase() === key || a.name.toLowerCase() === key)
        || areas.find((a) => a.session.toLowerCase().startsWith(key) || a.name.toLowerCase().startsWith(key));
      if (hit) return { tier: 'local', why: 'you addressed it directly', confidence: 1, tasks: [{ area: hit.id, title: m[2].trim().slice(0, 48), prompt: m[2].trim() }] };
    }
    if (areas.length === 1) return { tier: 'local', why: 'only one area', confidence: 1, tasks: [{ area: areas[0].id, title: String(text).trim().slice(0, 48), prompt: String(text).trim() }] };
    return null;
  }

  async function route(text) {
    const areas = liveAreas();
    if (!areas.length) throw new Error('no areas yet — open a session first');
    const local = localRoute(text, areas);
    if (local) return { ...local, route_ms: 0 };
    const prof = profile();
    if (!prof) { const e = new Error('no_key'); e.code = 'no_key'; throw e; }
    const t0 = Date.now();
    const out = await callLLM(prof, sysPrompt(areas), String(text));
    const valid = (out.tasks || []).filter((t) => t && areas.some((a) => a.id === t.area)).slice(0, 4);
    if (!valid.length) throw new Error('router picked no valid area');
    return { tier: 'llm', tasks: valid, why: out.why || '', confidence: typeof out.confidence === 'number' ? out.confidence : null, route_ms: Date.now() - t0, model: prof.model, profile: prof.name };
  }

  // ---- dispatch ------------------------------------------------------------
  // One prompt at a time per session: injecting while the agent is mid-turn
  // types into a busy TUI and the two prompts merge into one garbled line
  // (OpenDev Bots hit exactly this with a heartbeat landing on a message).
  const busy = (session) => tasks.some((t) => t.session === session && ['dispatched', 'working', 'needs-you'].includes(t.status));

  function pump() {
    for (const t of tasks) {
      if (t.status !== 'queued') continue;
      if (busy(t.session)) continue;
      const st = lastStates[t.session];
      if (!st) { // the session isn't there (closed / renamed) — say so, don't hang
        if (Date.now() - t.ts > 15_000) { t.status = 'failed'; t.error = `no session "${t.session}"`; broadcastTasks(); }
        continue;
      }
      if (st.state === 'active') continue;   // let the agent finish what it's doing
      inject(t);
    }
  }

  function inject(t) {
    t.status = 'dispatched';
    t.startedAt = Date.now();
    runtime.set(t.id, { baseline: capture(t.session, 200).slice(-20000), idle: 0, sawActive: false, injectedAt: Date.now() });
    jlog({ ev: 'dispatch', id: t.id, area: t.areaId, session: t.session, tier: t.tier, route_ms: t.route_ms, text: t.text, prompt: t.prompt });
    ctx.emit('agent.prompt', { session: t.session, text: t.prompt, ref: t.id });
    broadcastTasks();
  }

  ctx.onEvent('agent.prompt.result', ({ ref, ok, error }) => {
    const t = tasks.find((x) => x.id === ref); if (!t) return;
    if (!ok) { t.status = 'failed'; t.error = error || 'could not reach the agent'; runtime.delete(t.id); jlog({ ev: 'dispatch_failed', id: t.id, error }); }
    else if (t.status === 'dispatched') t.status = 'working';
    broadcastTasks();
  });

  // ---- turn tracking (terminal's poller is the clock) -----------------------
  ctx.onEvent('session.states', ({ states }) => {
    lastStates = states || {};
    syncAreas(Object.keys(lastStates).map((s) => ({ session: s })));
    let changed = false;
    for (const t of tasks) {
      if (!['dispatched', 'working', 'needs-you'].includes(t.status)) continue;
      const rt = runtime.get(t.id); if (!rt) continue;
      const st = lastStates[t.session];
      const age = Date.now() - rt.injectedAt;
      if (!st) continue;
      if (st.state === 'active') { rt.sawActive = true; rt.idle = 0; if (t.status !== 'working') { t.status = 'working'; changed = true; } continue; }
      if (st.state === 'prompt') { rt.idle = 0; if (t.status !== 'needs-you') { t.status = 'needs-you'; changed = true; jlog({ ev: 'needs_you', id: t.id, session: t.session }); } continue; }
      // idle / finished
      if (t.status === 'needs-you') { t.status = 'working'; changed = true; }   // the user answered it
      rt.idle += 1;
      const settled = rt.sawActive ? rt.idle >= SETTLE_POLLS : age > NO_START_MS;
      if (settled) { finish(t, rt.sawActive ? 'done' : 'no-response'); changed = true; continue; }
      if (age > MAX_TURN_MS) { finish(t, 'timeout'); changed = true; }
    }
    if (changed) broadcastTasks();
    pump();
  });

  function finish(t, status) {
    const rt = runtime.get(t.id) || {};
    const after = capture(t.session, 400);
    t.reply = replyFromDiff(rt.baseline || '', after, t.prompt);
    t.gist = gist(t.reply);
    t.status = status;
    if (!t.reply) t.reply = '(nothing new in the pane — open the area to look)';
    t.doneAt = Date.now();
    runtime.delete(t.id);
    jlog({ ev: 'finish', id: t.id, area: t.areaId, status: t.status, ms: t.doneAt - (t.startedAt || t.ts), reply_chars: t.reply.length });
  }

  // ---- routes --------------------------------------------------------------
  const body = (req) => new Promise((r) => { const c = []; req.on('data', (x) => c.push(x)); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString())); } catch { r({}); } }); });
  const json = (res, o, code = 200) => { res.writeHead(code, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify(o)); };

  // Sessions that exist right now but were removed from the areas list. Without
  // this, "remove" is a one-way door: the area is gone and nothing in the UI
  // can bring it back, even though the tab is still sitting there.
  const dismissedLive = () => store.dismissed.filter((sn) => lastStates[sn]).map((sn) => ({ session: sn, name: prettify(sn) }));

  ctx.route('state', (req, res) => {
    const prof = profile();
    json(res, { areas: liveAreas(), dismissed: dismissedLive(), tasks: tasks.slice(-60), ready: !!prof, model: prof ? prof.model : null });
  });

  ctx.route('send', async (req, res) => {
    const b = await body(req);
    const text = String(b.text || '').trim();
    if (!text) return json(res, { error: 'empty' }, 400);
    let dec;
    try { dec = await route(text); }
    catch (e) {
      jlog({ ev: 'route_failed', text, error: String(e.message || e) });
      return json(res, { error: e.code || String(e.message || e) }, 200);
    }
    jlog({ ev: 'route', text, tier: dec.tier, route_ms: dec.route_ms, confidence: dec.confidence, why: dec.why, picked: dec.tasks.map((t) => t.area) });
    const made = [];
    const group = newId();           // one user message = one card in the feed
    for (const d of dec.tasks) {
      const area = store.areas.find((a) => a.id === d.area);
      const t = {
        id: newId(), group, ts: Date.now(), text, areaId: area.id, session: area.session,
        title: String(d.title || text).slice(0, 60), prompt: String(d.prompt || text),
        status: 'queued', tier: dec.tier, why: dec.why, confidence: dec.confidence,
        route_ms: dec.route_ms, model: dec.model || null, fanout: dec.tasks.length,
      };
      tasks.push(t); made.push(t);
    }
    if (tasks.length > MAX_TASKS + 40) tasks = tasks.slice(-MAX_TASKS);
    broadcastTasks();
    pump();
    json(res, { ok: true, tasks: made, why: dec.why, tier: dec.tier, route_ms: dec.route_ms });
  });

  // The correction path: "wrong area" is one tap, and it is logged as training
  // data for the router prompt (this is the only honest way to improve it).
  ctx.route('retarget', async (req, res) => {
    const b = await body(req);
    const t = tasks.find((x) => x.id === b.id);
    const area = store.areas.find((a) => a.id === b.area);
    if (!t || !area) return json(res, { error: 'not found' }, 404);
    jlog({ ev: 'retarget', id: t.id, from: t.areaId, to: area.id, text: t.text, tier: t.tier });
    const t2 = { ...t, id: newId(), group: newId(), ts: Date.now(), areaId: area.id, session: area.session, status: 'queued', tier: 'retarget', reply: undefined, gist: undefined, error: undefined, doneAt: undefined, startedAt: undefined };
    if (['queued', 'failed', 'interrupted'].includes(t.status)) t.status = 'moved';
    tasks.push(t2); broadcastTasks(); pump();
    json(res, { ok: true, task: t2 });
  });

  // Follow-up inside an area — no routing, no re-classification.
  ctx.route('follow', async (req, res) => {
    const b = await body(req);
    const area = store.areas.find((a) => a.id === b.area);
    const text = String(b.text || '').trim();
    if (!area || !text) return json(res, { error: 'bad request' }, 400);
    const t = { id: newId(), group: newId(), ts: Date.now(), text, areaId: area.id, session: area.session, title: text.slice(0, 60), prompt: text, status: 'queued', tier: 'follow' };
    tasks.push(t); broadcastTasks(); pump();
    json(res, { ok: true, task: t });
  });

  ctx.route('areas', async (req, res) => {
    if (req.method !== 'POST') return json(res, { areas: liveAreas() });
    const b = await body(req);
    if (Array.isArray(b.areas)) {
      const keep = new Set(b.areas.map((a) => a.session));
      for (const a of store.areas) if (!keep.has(a.session) && !store.dismissed.includes(a.session)) store.dismissed.push(a.session);
      store.areas = b.areas.map((a) => ({
        id: a.session, session: a.session, name: String(a.name || a.session).slice(0, 40),
        emoji: String(a.emoji || '🟣').slice(0, 4), about: String(a.about || '').slice(0, 400), auto: false,
      })).filter((a) => validName(a.session));
      store.dismissed = store.dismissed.filter((s) => !keep.has(s));
      writeAreas(store); broadcastAreas();
    }
    json(res, { ok: true, areas: liveAreas(), dismissed: dismissedLive() });
  });

  ctx.route('clear', (req, res) => { tasks = tasks.filter((t) => ['queued', 'dispatched', 'working', 'needs-you'].includes(t.status)); broadcastTasks(); json(res, { ok: true }); });

  ctx.route('logs', (req, res, url) => {
    const n = Math.min(Number(url.searchParams.get('n')) || 200, 5000);
    let lines = []; try { lines = fs.readFileSync(logFile, 'utf8').trim().split('\n').filter(Boolean); } catch {}
    json(res, { items: lines.slice(-n).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean) });
  });

  ctx.on('sync', (_p, client) => client.send('tasks', { tasks: tasks.slice(-60) }));

  ctx.log('ready —', store.areas.length, 'areas');
  return () => { clearTimeout(saveTimer); try { fs.writeFileSync(tasksFile, JSON.stringify({ tasks: tasks.slice(-MAX_TASKS) }, null, 2)); } catch {} };
};
