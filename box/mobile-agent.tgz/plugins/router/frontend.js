// Router — the one surface you talk to.
//
// Not another thread. You say what you want; the router picks the topic area
// (a project with its own always-on agent), hands that agent a self-contained
// instruction, and brings the answer back HERE. Several messages = several
// areas working at once, one feed to read.
//
// Everything the router decides is visible and correctable in one tap: which
// area it picked, why, what it actually sent, and "move to ▾" when it was
// wrong (which is also what gets logged to improve it).
export default function init(host) {
  const el = (tag, css, txt) => { const e = document.createElement(tag); if (css) e.style.cssText = css; if (txt != null) e.textContent = txt; return e; };
  // A real element, not a braille/box-drawing character: those depend on the
  // font and render as tofu often enough that a recording caught it.
  if (!document.getElementById('router-css')) {
    const st = el('style'); st.id = 'router-css';
    st.textContent = '@keyframes router-spin{to{transform:rotate(360deg)}}'
      + '.router-spin{width:10px;height:10px;border-radius:50%;border:1.5px solid var(--border);border-top-color:var(--accent);animation:router-spin .8s linear infinite;display:inline-block;flex:0 0 auto}';
    document.head.appendChild(st);
  }
  const btnCss = (primary) => `font:inherit;font-size:11px;padding:4px 9px;border-radius:7px;cursor:pointer;border:1px solid ${primary ? 'var(--accent)' : 'var(--border)'};background:${primary ? 'var(--accent)' : 'transparent'};color:${primary ? 'var(--accent-fg)' : 'var(--fg)'}`;
  const mkBtn = (t, primary) => { const b = el('button', btnCss(primary), t); b.tabIndex = -1; b.addEventListener('mousedown', (e) => e.preventDefault()); return b; };

  let areas = [], tasks = [], dismissed = [], ready = false, model = null;
  const expanded = new Set();
  let moving = null;              // task id whose "Move ▾" picker is open
  const post = (sub, b) => host.api(sub, { method: 'POST', body: JSON.stringify(b || {}), headers: { 'content-type': 'application/json' } }).then((r) => r.json());

  // ---- toolbar entry (badge = work in flight / waiting on you) --------------
  const btn = el('button', 'flex:0 0 auto;display:flex;align-items:center;gap:4px;font:inherit;font-size:11px;height:26px;padding:0 9px;border-radius:4px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer;white-space:nowrap');
  btn.tabIndex = -1;
  btn.addEventListener('mousedown', (e) => e.preventDefault());
  const btnLabel = el('span', null, '⇄ Router');
  const badge = el('span', 'display:none;min-width:15px;height:15px;line-height:15px;border-radius:8px;background:var(--accent);color:var(--accent-fg);font-size:9.5px;text-align:center;padding:0 3px');
  btn.append(btnLabel, badge);
  btn.title = 'one place to ask — the router picks the project';
  host.mount('toolbar', btn);
  // The toolbar scrolls horizontally and this app already fills it, so an
  // appended button lands off-screen on a phone — which is fatal for the one
  // control that is supposed to be the way in. Claim the first slot.
  if (btn.parentElement) btn.parentElement.prepend(btn);
  btn.onclick = () => open();

  const ACTIVE = new Set(['queued', 'dispatched', 'working']);
  function refreshBadge() {
    const need = tasks.filter((t) => t.status === 'needs-you').length;
    const live = tasks.filter((t) => ACTIVE.has(t.status)).length;
    if (need) { badge.textContent = '!'; badge.style.background = '#e0a030'; badge.style.display = 'block'; }
    else if (live) { badge.textContent = String(live); badge.style.background = 'var(--accent)'; badge.style.display = 'block'; }
    else badge.style.display = 'none';
  }

  // ---- the panel -----------------------------------------------------------
  // Full-screen on purpose: while you are routing, this IS the app. The
  // terminal is one tap away on any card ("open"), which is also how you take
  // over an area by hand.
  const back = el('div', 'position:fixed;inset:0;z-index:340;display:none;flex-direction:column;background:var(--bg);font:13px system-ui,sans-serif');
  // Stable hooks, same reason the terminal exposes #term-input/#term-send:
  // scripts (and other plugins) need to find this panel without guessing at
  // classes or DOM order.
  back.dataset.routerPanel = '';

  const head = el('div', 'flex:0 0 auto;display:flex;align-items:center;gap:8px;height:38px;padding:0 10px;background:var(--chrome);border-bottom:1px solid var(--border)');
  const headTitle = el('div', 'flex:1;min-width:0;display:flex;align-items:baseline;gap:7px');
  headTitle.append(el('span', 'font-weight:600;font-size:14px;color:var(--fg)', '⇄ Router'));
  const headSub = el('span', 'font-size:11px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap');
  headTitle.append(headSub);
  const gear = mkBtn('⚙'); gear.title = 'areas';
  const close = mkBtn('✕');
  close.onclick = () => hide();
  head.append(headTitle, gear, close);

  // areas strip
  const strip = el('div', 'flex:0 0 auto;display:flex;gap:6px;padding:8px 10px;overflow-x:auto;border-bottom:1px solid var(--border);background:var(--chrome)');
  strip.style.scrollbarWidth = 'none';

  const feed = el('div', 'flex:1 1 auto;min-height:0;overflow-y:auto;padding:12px 10px 16px;display:flex;flex-direction:column;gap:10px');
  feed.dataset.routerFeed = '';

  // composer
  const bar = el('div', 'flex:0 0 auto;display:flex;gap:7px;align-items:flex-end;padding:9px 10px;border-top:1px solid var(--border);background:var(--chrome)');
  const ta = el('textarea', 'flex:1;min-width:0;box-sizing:border-box;height:38px;max-height:110px;font:inherit;font-size:15px;padding:9px 11px;border-radius:10px;border:1px solid var(--border);background:var(--bg);color:var(--fg);resize:none;overflow:hidden;line-height:1.25');
  ta.placeholder = 'what do you need done?';
  ta.rows = 1;
  const autoGrow = () => {
    ta.style.height = '38px';
    const h = Math.min(ta.scrollHeight, 110);
    ta.style.height = h + 'px';
    ta.style.overflowY = ta.scrollHeight > 110 ? 'auto' : 'hidden';   // no arrows at rest
  };
  ta.addEventListener('input', autoGrow);
  const send = el('button', 'flex:0 0 auto;width:42px;height:38px;border-radius:10px;border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg);font-size:16px;cursor:pointer', '▸');
  send.tabIndex = -1;
  send.addEventListener('mousedown', (e) => e.preventDefault());
  bar.append(ta, send);

  // dictation — "you only talk in one place" should be literal
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (SR) {
    const mic = el('button', 'flex:0 0 auto;width:40px;height:38px;border-radius:10px;border:1px solid var(--border);background:transparent;color:var(--fg);font-size:15px;cursor:pointer', '🎤');
    mic.tabIndex = -1;
    mic.addEventListener('mousedown', (e) => e.preventDefault());
    let rec = null, listening = false;
    const stop = () => { if (rec) { try { rec.stop(); } catch {} } listening = false; mic.textContent = '🎤'; mic.style.background = 'transparent'; mic.style.color = 'var(--fg)'; };
    mic.onclick = () => {
      if (listening) return stop();
      rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = false;
      const base = ta.value ? ta.value.trim() + ' ' : ''; let fin = '';
      rec.onresult = (e) => { let interim = ''; for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]; if (r.isFinal) fin += r[0].transcript; else interim += r[0].transcript; } ta.value = base + fin + interim; autoGrow(); };
      rec.onerror = stop;
      rec.onend = () => { ta.value = (base + fin).trim(); autoGrow(); ta.focus(); stop(); };
      listening = true; mic.textContent = '🔴'; mic.style.background = '#c0392b'; mic.style.color = '#fff';
      try { rec.start(); } catch { stop(); }
    };
    bar.insertBefore(mic, send);
  }

  back.append(head, strip, feed, bar);
  host.mount('header', back);      // slot is irrelevant — the panel is fixed

  const atBottom = () => feed.scrollHeight - feed.scrollTop - feed.clientHeight < 60;
  const toBottom = () => { feed.scrollTop = feed.scrollHeight; };

  function show() { back.style.display = 'flex'; renderAll(); setTimeout(toBottom, 0); }
  function hide() { back.style.display = 'none'; }
  const isOpen = () => back.style.display === 'flex';
  async function open() { await load(); show(); }

  // ---- data ---------------------------------------------------------------
  async function load() {
    try {
      const s = await host.api('state').then((r) => r.json());
      areas = s.areas || []; tasks = s.tasks || []; dismissed = s.dismissed || []; ready = !!s.ready; model = s.model;
    } catch (e) { host.log('state failed', e); }
    refreshBadge();
  }
  host.on('tasks', (p) => { tasks = (p && p.tasks) || []; refreshBadge(); if (isOpen()) { renderFeed(); renderStrip(); } });
  host.on('areas', (p) => { areas = (p && p.areas) || []; if (isOpen()) renderStrip(); });
  host.bus.on('shell.connected', () => load());
  load();

  // ---- areas strip --------------------------------------------------------
  const DOT = { active: '#4a9eff', prompt: '#e0a030', finished: '#e07a30', idle: '#4b8b5a', offline: '#555' };
  function renderStrip() {
    strip.innerHTML = '';
    const inflight = new Map();
    for (const t of tasks) if (ACTIVE.has(t.status) || t.status === 'needs-you') inflight.set(t.areaId, (inflight.get(t.areaId) || 0) + 1);
    for (const a of areas) {
      const chip = el('button', `flex:0 0 auto;display:flex;align-items:center;gap:5px;font:inherit;font-size:11.5px;padding:5px 10px;border-radius:14px;border:1px solid ${inflight.get(a.id) ? 'var(--accent)' : 'var(--border)'};background:var(--card);color:var(--card-fg);cursor:pointer;white-space:nowrap`);
      chip.tabIndex = -1;
      chip.addEventListener('mousedown', (e) => e.preventDefault());
      chip.append(el('span', null, a.emoji || '🟣'), el('span', null, a.name));
      chip.append(el('span', `width:7px;height:7px;border-radius:50%;background:${DOT[a.state] || DOT.idle}`));
      if (inflight.get(a.id)) chip.append(el('span', 'font-size:10px;color:var(--accent)', '·' + inflight.get(a.id)));
      chip.title = a.about || a.session;
      chip.onclick = () => jump(a.session);
      strip.append(chip);
    }
    const add = el('button', 'flex:0 0 auto;font:inherit;font-size:11.5px;padding:5px 10px;border-radius:14px;border:1px dashed var(--border);background:transparent;color:var(--muted);cursor:pointer', '⚙ areas');
    add.tabIndex = -1;
    add.addEventListener('mousedown', (e) => e.preventDefault());
    add.onclick = () => areaSheet();
    strip.append(add);
    headSub.textContent = `${areas.length} area${areas.length === 1 ? '' : 's'}${model ? ' · ' + model : ''}${ready ? '' : ' · no key'}`;
  }

  function jump(session) {
    host.bus.emit('terminal.switch', { session });
    hide();
  }

  // ---- feed ---------------------------------------------------------------
  const areaOf = (id) => areas.find((a) => a.id === id) || { emoji: '⚪', name: id, id };
  const fmt = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? s + 's' : Math.floor(s / 60) + 'm ' + String(s % 60).padStart(2, '0') + 's'; };
  const STATUS = {
    queued: ['waiting for the agent', 'var(--muted)'],
    dispatched: ['sent', 'var(--accent)'],
    working: ['working', 'var(--accent)'],
    'needs-you': ['needs you', '#e0a030'],
    done: ['done', '#4b8b5a'],
    failed: ['failed', '#e57373'],
    timeout: ['still running', '#e0a030'],
    'no-response': ['no response', '#e57373'],
    interrupted: ['interrupted', 'var(--muted)'],
    moved: ['moved', 'var(--muted)'],
  };

  const nodes = new Map();   // taskId -> { root, update }
  function renderFeed() {
    const stick = atBottom();
    const keepScroll = feed.scrollTop;
    // group tasks by the message that produced them (fan-out shows as one card)
    const groups = [];
    const byGroup = new Map();
    for (const t of tasks) {
      const g = t.group || t.id;
      if (!byGroup.has(g)) { byGroup.set(g, { key: g, text: t.text, ts: t.ts, why: t.why, tier: t.tier, items: [] }); groups.push(byGroup.get(g)); }
      byGroup.get(g).items.push(t);
    }
    feed.innerHTML = '';
    nodes.clear();
    if (!groups.length) { feed.append(emptyState()); return; }
    for (const g of groups) feed.append(groupCard(g));
    // The feed repaints on every task update. Sticking to the bottom is right
    // when you are watching the newest card; it is NOT right when you scrolled
    // up to read something — that yanked the view away mid-sentence.
    if (stick) toBottom(); else feed.scrollTop = keepScroll;
  }

  function emptyState() {
    const box = el('div', 'margin:auto;max-width:420px;display:flex;flex-direction:column;gap:12px;text-align:center;color:var(--muted);padding:20px 6px');
    box.append(el('div', 'font-size:30px', '⇄'));
    box.append(el('div', 'font-size:14px;color:var(--fg);line-height:1.45', 'Say what you need. The router picks which project it belongs to and puts its agent to work — you stay here.'));
    if (!ready) box.append(el('div', 'font-size:12px;color:#e0a030', 'No API key yet — set one in ✦ → ⚙ Router profiles. (“@area do this” still works without one.)'));
    const row = el('div', 'display:flex;flex-wrap:wrap;gap:6px;justify-content:center');
    const names = areas.slice(0, 3).map((a) => a.name);
    const SUGS = names.length ? [`what's the state of ${names[0]}?`, ...(names[1] ? [`run the tests in ${names[1]}`] : []), `@${(areas[0] || {}).session} status`] : [];
    for (const s of SUGS) { const c = el('button', 'font:inherit;font-size:11px;padding:4px 9px;border-radius:12px;border:1px solid var(--card-border);background:var(--card);color:var(--card-fg);cursor:pointer', s); c.tabIndex = -1; c.onclick = () => { ta.value = s; autoGrow(); ta.focus(); }; row.append(c); }
    box.append(row);
    return box;
  }

  function groupCard(g) {
    const wrap = el('div', 'display:flex;flex-direction:column;gap:7px');
    // what you said
    const mine = el('div', 'align-self:flex-end;max-width:88%;background:var(--card);border:1px solid var(--card-border);color:var(--card-fg);border-radius:13px 13px 3px 13px;padding:8px 11px;font-size:13.5px;white-space:pre-wrap;line-height:1.35', g.text);
    wrap.append(mine);
    if (g.items.length > 1) wrap.append(el('div', 'align-self:flex-end;font-size:10.5px;color:var(--muted)', `split across ${g.items.length} areas`));
    for (const t of g.items) wrap.append(taskCard(t));
    return wrap;
  }

  function taskCard(t) {
    const a = areaOf(t.areaId);
    const [label, color] = STATUS[t.status] || [t.status, 'var(--muted)'];
    const card = el('div', `align-self:flex-start;max-width:94%;min-width:62%;border:1px solid ${t.status === 'needs-you' ? '#6b5320' : 'var(--border)'};border-left:3px solid ${color};border-radius:3px 12px 12px 12px;background:var(--chrome);padding:9px 11px;display:flex;flex-direction:column;gap:6px`);
    card.dataset.taskStatus = t.status;
    card.dataset.taskArea = t.areaId;

    const top = el('div', 'display:flex;align-items:center;gap:6px;flex-wrap:wrap');
    top.append(el('span', 'font-size:13px', a.emoji || '🟣'));
    top.append(el('span', 'font-size:12.5px;font-weight:600;color:var(--fg)', a.name));
    top.append(el('span', 'font-size:11px;color:var(--muted);flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', '· ' + t.title));
    const stat = el('span', `font-size:10.5px;color:${color};white-space:nowrap`, label);
    top.append(stat);
    card.append(top);

    // live line: elapsed while working, duration when done
    const live = el('div', 'font-size:11px;color:var(--muted);display:flex;align-items:center;gap:6px');
    card.append(live);
    const spin = el('span', null); spin.className = 'router-spin';
    const liveText = el('span');
    live.append(spin, liveText);
    const tick = () => {
      const running = ACTIVE.has(t.status) && t.status !== 'queued';
      spin.style.display = running ? 'inline-block' : 'none';
      if (ACTIVE.has(t.status)) liveText.textContent = fmt(Date.now() - (t.startedAt || t.ts));
      else if (t.status === 'needs-you') liveText.textContent = `waiting for your answer · ${fmt(Date.now() - (t.startedAt || t.ts))}`;
      else if (t.doneAt) liveText.textContent = `${fmt(t.doneAt - (t.startedAt || t.ts))}${t.route_ms ? ' · routed in ' + t.route_ms + 'ms' : ''}`;
      else liveText.textContent = t.error || '';
    };
    tick();

    // the answer
    if (t.reply) {
      const isOpen = expanded.has(t.id);
      // clamp to whole lines — a max-height crop slices a line in half
      const clamp = 'display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:3;overflow:hidden;';
      // Collapsed = the conclusion; expanded = the whole turn.
      const shown = isOpen ? t.reply : (t.gist || t.reply);
      const body = el('div', `font-size:12.5px;color:var(--fg);line-height:1.4;white-space:pre-wrap;${isOpen ? '' : clamp}`, shown);
      body.style.cursor = 'pointer';
      body.onclick = () => { if (expanded.has(t.id)) expanded.delete(t.id); else expanded.add(t.id); renderFeed(); };
      card.append(body);
      if (t.reply !== shown || t.reply.length > 200) card.append(el('div', 'font-size:10.5px;color:var(--accent)', isOpen ? 'tap to collapse' : 'tap for the full turn'));
    }
    if (t.error && t.status !== 'needs-you') card.append(el('div', 'font-size:11.5px;color:#e57373', t.error));

    // actions
    const row = el('div', 'display:flex;gap:6px;flex-wrap:wrap;align-items:center');
    const openBtn = mkBtn(t.status === 'needs-you' ? 'Answer it →' : 'Open', t.status === 'needs-you');
    openBtn.onclick = () => jump(t.session);
    row.append(openBtn);
    const move = mkBtn('Move ▾', moving === t.id);
    move.onclick = () => { moving = moving === t.id ? null : t.id; renderFeed(); };
    row.append(move);
    const why = mkBtn('Why?');
    why.onclick = () => detailSheet(t);
    row.append(why);
    card.append(row);
    if (moving === t.id) card.append(movePicker(t));

    nodes.set(t.id, { root: card, tick });
    return card;
  }

  // one-tap correction: pick another area and the work is re-dispatched there.
  // Rendered as part of the card (not appended imperatively) so the feed's
  // 2-second repaint can't delete the options out from under your thumb —
  // which is exactly what happened the first time this was exercised.
  function movePicker(t) {
    const wrap = el('div', 'display:flex;gap:6px;flex-wrap:wrap;width:100%;padding-top:6px;border-top:1px dashed var(--border)');
    wrap.append(el('div', 'width:100%;font-size:10.5px;color:var(--muted)', 'send this to'));
    for (const a of areas) {
      if (a.id === t.areaId) continue;
      const b = mkBtn(`${a.emoji} ${a.name}`);
      b.onclick = async () => { moving = null; await post('retarget', { id: t.id, area: a.id }); renderFeed(); };
      wrap.append(b);
    }
    const cancel = mkBtn('cancel');
    cancel.onclick = () => { moving = null; renderFeed(); };
    wrap.append(cancel);
    return wrap;
  }

  // full transparency on one decision: what was sent, why, how fast
  function detailSheet(t) {
    const a = areaOf(t.areaId);
    const { back: b, bodyEl } = sheet('Routing decision');
    const kv = (k, v) => { const r = el('div', 'display:flex;flex-direction:column;gap:2px'); r.append(el('div', 'font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted)', k)); r.append(el('div', 'font-size:13px;color:var(--fg);white-space:pre-wrap', v || '—')); return r; };
    bodyEl.append(kv('you said', t.text));
    bodyEl.append(kv('area', `${a.emoji} ${a.name}  (tmux: ${t.session})`));
    bodyEl.append(kv('why', t.why || (t.tier === 'local' ? 'you addressed it directly' : '—')));
    bodyEl.append(kv('sent to the agent', t.prompt));
    bodyEl.append(kv('decided by', t.tier === 'llm' ? `${t.model || 'router model'} · ${t.route_ms}ms${t.confidence != null ? ' · confidence ' + t.confidence : ''}` : `${t.tier} · free, instant`));
    const cont = el('div', 'display:flex;gap:7px;flex-wrap:wrap');
    const fu = el('input', 'flex:1;min-width:150px;font:inherit;font-size:13px;padding:8px 10px;border-radius:8px;border:1px solid var(--border);background:var(--bg);color:var(--fg)');
    fu.placeholder = `follow up in ${a.name}…`;
    const go = mkBtn('Send', true);
    go.onclick = async () => { const v = fu.value.trim(); if (!v) return; await post('follow', { area: t.areaId, text: v }); b.remove(); };
    cont.append(fu, go);
    bodyEl.append(cont);
  }

  // ---- areas editor -------------------------------------------------------
  function sheet(title) {
    const b = el('div', 'position:fixed;inset:0;z-index:360;background:rgba(0,0,0,.45);display:flex;flex-direction:column;justify-content:flex-end');
    const panel = el('div', 'background:var(--chrome);border-top:1px solid var(--border);border-radius:16px 16px 0 0;display:flex;flex-direction:column;max-height:80vh');
    const h = el('div', 'display:flex;align-items:center;justify-content:space-between;padding:9px 12px;border-bottom:1px solid var(--border)');
    h.append(el('div', 'font-size:15px;font-weight:600;color:var(--fg)', title));
    const x = mkBtn('✕'); x.onclick = () => b.remove();
    h.append(x);
    const bodyEl = el('div', 'overflow-y:auto;padding:14px 14px 22px;display:flex;flex-direction:column;gap:13px');
    panel.append(h, bodyEl); b.append(panel);
    b.onclick = (e) => { if (e.target === b) b.remove(); };
    document.body.appendChild(b);
    return { back: b, bodyEl };
  }

  gear.onclick = () => areaSheet();
  function areaSheet() {
    const { back: b, bodyEl } = sheet('Topic areas');
    bodyEl.append(el('div', 'font-size:12px;color:var(--muted);line-height:1.45', 'One area = one project with its own agent. What you write under “what belongs here” is what the router reads when it decides — a sentence here is worth more than any setting.'));
    const draft = areas.map((a) => ({ ...a }));
    const rows = el('div', 'display:flex;flex-direction:column;gap:11px');
    const paint = () => {
      rows.innerHTML = '';
      draft.forEach((a, i) => {
        const card = el('div', 'border:1px solid var(--border);border-radius:10px;padding:10px;display:flex;flex-direction:column;gap:7px');
        const top = el('div', 'display:flex;gap:6px;align-items:center');
        const em = el('input', 'width:42px;font:inherit;font-size:15px;text-align:center;padding:6px 0;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg)');
        em.value = a.emoji || '🟣'; em.oninput = () => { a.emoji = em.value; };
        const nm = el('input', 'flex:1;min-width:0;font:inherit;font-size:13.5px;padding:7px 9px;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg)');
        nm.value = a.name; nm.oninput = () => { a.name = nm.value; };
        const rm = mkBtn('remove');
        rm.onclick = () => {
          const gone = draft.splice(i, 1)[0];
          if (gone && !dismissed.some((d) => d.session === gone.session)) dismissed = dismissed.concat([{ session: gone.session, name: gone.name }]);
          paint(); paintBack();
        };
        top.append(em, nm, rm);
        const ab = el('textarea', 'font:inherit;font-size:12.5px;padding:7px 9px;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg);resize:vertical;min-height:46px');
        ab.placeholder = 'what belongs here — e.g. “the iOS app: login, paywall, push notifications”';
        ab.value = a.about || ''; ab.oninput = () => { a.about = ab.value; };
        card.append(top, ab, el('div', 'font-size:10.5px;color:var(--muted)', `tmux: ${a.session}${a.online ? '' : ' · offline'}`));
        rows.append(card);
      });
    };
    paint();
    bodyEl.append(rows);
    // Removed-but-still-open sessions, offered back — "remove" used to be a
    // one-way door. Add straight into the draft: rebuilding the sheet would
    // re-derive the draft from the SAVED list and silently drop the addition.
    const back = el('div', 'display:flex;flex-direction:column;gap:6px;padding-top:4px;border-top:1px dashed var(--border)');
    const backRow = el('div', 'display:flex;gap:6px;flex-wrap:wrap');
    const paintBack = () => {
      const pending = dismissed.filter((d) => !draft.some((a) => a.session === d.session));
      back.style.display = pending.length ? 'flex' : 'none';
      backRow.innerHTML = '';
      for (const d of pending) {
        const btn = mkBtn('+ ' + d.name);
        btn.onclick = () => { draft.push({ session: d.session, name: d.name, emoji: '🟣', about: '' }); paint(); paintBack(); };
        backRow.append(btn);
      }
    };
    back.append(el('div', 'font-size:11px;color:var(--muted)', 'open sessions you removed'), backRow);
    bodyEl.append(back);
    paintBack();
    const save = mkBtn('Save areas', true);
    save.onclick = async () => { const r = await post('areas', { areas: draft }); areas = r.areas || areas; dismissed = r.dismissed || dismissed; renderStrip(); b.remove(); };
    bodyEl.append(save);
  }

  // ---- send ---------------------------------------------------------------
  let sending = false;
  async function submit() {
    const text = ta.value.trim();
    if (!text || sending) return;
    sending = true; send.disabled = true; send.textContent = '…';
    ta.value = ''; autoGrow();
    try {
      const r = await post('send', { text });
      if (r.error) {
        const msg = r.error === 'no_key'
          ? 'No API key for the router yet — open ✦ → ⚙ and add one (or address an area directly: “@name do this”).'
          : 'Router: ' + r.error;
        feed.append(el('div', 'align-self:center;font-size:12px;color:#e57373;padding:6px 10px;border:1px solid #5a2b2b;border-radius:9px', msg));
        toBottom();
        ta.value = text; autoGrow();
      }
    } catch (e) {
      feed.append(el('div', 'align-self:center;font-size:12px;color:#e57373', 'send failed: ' + e.message));
      ta.value = text; autoGrow();
    }
    sending = false; send.disabled = false; send.textContent = '▸';
    ta.focus();
  }
  send.onclick = submit;
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); } });

  function renderAll() { renderStrip(); renderFeed(); }

  // one timer for every live card — cheap, and the elapsed time is the whole
  // point of a feed you can leave running
  const timer = setInterval(() => {
    if (!document.body.contains(back)) return clearInterval(timer);   // hot-reload dropped us
    if (!isOpen()) return;
    for (const n of nodes.values()) n.tick();
  }, 250);

  // reachable by language from the omnibox too
  const announce = () => host.bus.emit('omni.action', {
    id: 'router.open', title: 'Open the Router', hint: 'one place to ask; it picks the project', args: [], mutates: false,
    run: () => open(),
  });
  host.bus.on('omni.collect', announce);
  announce();

  return () => clearInterval(timer);
}
