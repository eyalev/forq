// Turning a tmux pane tail into "what the agent answered".
//
// Ported from OpenDev Bots' computer-worker (replyFromDiff/tidy/unwrap), which
// earned every line of this the hard way:
//   - scraping the tail once returns Claude Code's startup banner, not the
//     answer -> anchor on the LAST echo of the prompt, diff against a baseline
//     snapshot only as the fallback;
//   - with alt-screen off, CC re-renders earlier blocks into scrollback, so a
//     whole-buffer diff drags the banner into replies;
//   - the pane is hard-wrapped at ~60 cols, so storing those breaks makes the
//     phone wrap a second time and every paragraph comes out ragged.

const CHROME = /auto mode on|shift\+tab|esc to interrupt|tokens\)|\? for shortcuts|^\s*[❯>][\s ]|^\s*[❯>]\s*$|^\s*⏵|^\s*─+\s*$|\$\d+\.\d+\s*\|\s*(api|sub)\b|\[(Opus|Sonnet|Haiku|Fable|Claude)/;

// Claude Code's own scaffolding around the answer: collapsed tool summaries
// ("Searched for 3 patterns, read 2 files (ctrl+o to expand)"), the todo
// checklist, and the boxed tool-output panes. All of it is the agent working,
// none of it is the agent ANSWERING — and the feed's one-line gist is the
// first surviving line, so leaving them in makes every card read "Read 2
// files" instead of the result.
const WORKING = /\(ctrl\+o to expand\)|^\s*[☐☑✔]\s|^\s*[│┌└├╭╰]|^\s*⎿|^\s*[✻✽✢]\s|^\s*\d+ tool uses?\b|^\s*(Bash|Read|Write|Edit|Update|Create|MultiEdit|NotebookEdit|Grep|Glob|Search|Task|Agent|Skill|SlashCommand|WebFetch|WebSearch|TodoWrite|BashOutput|KillShell)\(/;

// Rejoin terminal-wrapped continuation lines; let the reader's device wrap.
// Bullets, blank lines and short (deliberate) lines are preserved.
function unwrap(lines) {
  const width = Math.max(40, ...lines.map((l) => l.length));
  // Exact terminal rule: the break happened because the NEXT line's first word
  // would not have fit before the margin (catches breaks a long word short of
  // flush, which a "is the line full?" test misses).
  const firstWord = (l) => (l.trim().split(/\s+/)[0] || '');
  const wrappedBefore = (prev, next) => prev.length >= 20 && prev.length + 1 + firstWord(next).length > width - 1;
  // A break INSIDE a long token (a path, a URL) leaves the line flush at the
  // margin with no space anywhere near the end — rejoining those with a space
  // produced "/tmp/…/orders-a pi/src/server.js". Glue them back with nothing.
  const midToken = (prev, next) => prev.length >= width - 1 && /\S{12,}$/.test(prev) && /^[A-Za-z0-9_./-]/.test(next.trim());
  const startsBlock = (l) => !l.trim() || /^\s*([-•●*▪·]|\d+[.)])\s+/.test(l) || /^\s*[✻✽*]\s/.test(l) || /:\s*$/.test(l);
  const out = [];
  for (const l of lines) {
    const prev = out.length ? out[out.length - 1] : null;
    if (prev !== null && prev.trim() && !startsBlock(l) && wrappedBefore(prev, l)) {
      const glue = midToken(prev, l) ? '' : ' ';
      out[out.length - 1] = prev.replace(/\s+$/, '') + glue + l.trim();
    } else out.push(l);
  }
  return out;
}

function tidy(rawLines, cap = 4000) {
  // Unwrap FIRST. The pane is ~60 cols, so Claude Code's own chrome wraps too
  // ("Searched for 1 pattern, listed 1 directory (ctrl+o to\n expand)") and a
  // per-row filter never sees the whole phrase — chrome leaked into the card
  // gist until this ran in the right order.
  const lines = unwrap(rawLines);
  // CC's first-run explainer is a fixed block that appears whenever the capture
  // starts before the session had any conversation. Never part of an answer.
  const out = [];
  let skipping = false;
  let inTool = false;
  for (const l of lines) {
    if (/Auto mode lets Claude handle permission prompts/.test(l)) { skipping = true; continue; }
    if (skipping) { if (/Shift\+Tab to change mode/.test(l)) skipping = false; continue; }
    if (/Claude Code v\d|API Usage Billing|^\s*[▐▝▘▛▜█▙▟]+/.test(l)) continue;
    // '● ' prefixes both an assistant message AND a tool call in the pane, so
    // strip it BEFORE classifying (a bulleted "Bash(git …)" is still a tool call).
    const line = l.replace(/^\s*●\s+/, '');
    if (WORKING.test(line)) { inTool = true; continue; }
    // A tool call's output is rendered indented beneath it; drop the whole
    // block, not just its first line (otherwise git output lands in the reply).
    if (inTool && (!line.trim() || /^\s{4,}\S/.test(line))) continue;
    inTool = false;
    out.push(line);
  }
  const joined = out.filter((l) => !CHROME.test(l)).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  return dedupeParagraphs(joined).trim().slice(0, cap);
}

// The echoed prompt is hard-wrapped at the pane width, so a single anchor
// taken from its START often spans two lines and matches nothing — the diff
// fallback then kept the prompt's own tail as the first line of the "reply"
// (seen live: a card that opened with the word "state"). Try several anchors,
// tail first: the LAST wrapped line of the echo is immediately above the
// answer, which is exactly the boundary we want.
// Find the line on which `anchor` ENDS, matching across hard-wrapped lines.
// Matching line-by-line is what kept failing: the pane breaks the echoed
// prompt wherever the margin falls, so no single line contains the anchor.
// Normalising the whole capture into one string (and remembering which line
// each character came from) makes the wrap irrelevant.
function anchorEndsAt(lines, anchor) {
  let norm = '';
  const map = [];
  for (let i = 0; i < lines.length; i++) {
    const t = lines[i].replace(/\s+/g, ' ').trim();
    if (!t) continue;
    if (norm) { norm += ' '; map.push(i); }
    for (let c = 0; c < t.length; c++) map.push(i);
    norm += t;
  }
  const a = String(anchor).replace(/\s+/g, ' ').trim();
  if (a.length < 12) return -1;
  const idx = norm.lastIndexOf(a);
  if (idx < 0) return -1;
  return map[Math.min(idx + a.length - 1, map.length - 1)];
}

// Claude Code re-renders earlier blocks into scrollback (alt-screen is off),
// so the same paragraph can appear twice — once from a mid-stream render at a
// different width (which comes out word-mangled: "ther e's") and once
// settled. The LAST copy is the settled one.
function dedupeParagraphs(text) {
  const paras = text.split(/\n\s*\n/);
  const keyOf = (p) => p.replace(/\s+/g, '').toLowerCase();
  const lastAt = new Map();
  paras.forEach((p, i) => { const k = keyOf(p); if (k.length > 24) lastAt.set(k, i); });
  return paras.filter((p, i) => { const k = keyOf(p); return k.length <= 24 || lastAt.get(k) === i; }).join('\n\n');
}

function anchors(prompt) {
  const t = String(prompt).trim().replace(/\s+/g, ' ');
  const out = [];
  for (const n of [30, 20]) if (t.length > n) out.push(t.slice(-n));
  for (const n of [40, 24]) out.push(t.slice(0, n));
  return [...new Set(out.filter((x) => x.length >= 12))];
}

// before = pane tail captured just before the prompt was injected.
function replyFromDiff(before, after, prompt = '') {
  const a = String(after).split('\n').map((l) => l.trimEnd());
  for (const anchor of anchors(prompt)) {
    const last = anchorEndsAt(a, anchor);
    if (last >= 0) { const answer = tidy(a.slice(last + 1)); if (answer) return answer; }
  }
  const b = String(before).split('\n').map((l) => l.trimEnd());
  let i = 0;
  while (i < b.length && i < a.length && b[i] === a[i]) i++;
  return tidy(a.slice(i));
}

// What the card shows before you expand it: the agent's CONCLUSION.
// A long turn starts with narration ("Now let's look at server.js…") and ends
// with the answer, so the first line is the least useful thing to show.
function gist(reply, max = 300) {
  const paras = String(reply || '').split(/\n\s*\n/)
    .map((p) => p.replace(/\s+$/, ''))
    .filter((p) => p.trim() && !/^[─━=•*\-\s]{3,}$/.test(p.trim()));
  let last = paras[paras.length - 1] || '';
  // the pane indents assistant text; strip the common indent so the card's
  // text lines up with everything else in the feed
  const rows = last.split('\n');
  const pad = Math.min(...rows.filter((r) => r.trim()).map((r) => r.match(/^ */)[0].length));
  if (pad > 0 && Number.isFinite(pad)) last = rows.map((r) => r.slice(pad)).join('\n');
  return last.length > max ? last.slice(0, max - 1) + '…' : last;
}

module.exports = { replyFromDiff, tidy, gist, CHROME };
