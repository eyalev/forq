// Quick keys — a scrollable row of control keys for driving a TUI (Claude Code,
// vim, etc.) from a phone. Emits tmux key-names over the bus; the terminal sends
// them to the current pane. Knows nothing about sessions.
const KEYS = [
  { label: 'Esc', key: 'Escape' },
  { label: 'Tab', key: 'Tab' },
  { label: '^C', key: 'C-c' },
  { label: '^D', key: 'C-d' },
  { label: '^R', key: 'C-r' },
  { label: '↑', key: 'Up' },
  { label: '↓', key: 'Down' },
  { label: '←', key: 'Left' },
  { label: '→', key: 'Right' },
  { label: '⏎', key: 'Enter' },
];

export default function init(host) {
  const row = document.createElement('div');
  row.style.cssText = [
    'display:flex', 'gap:4px', 'overflow-x:auto', 'padding:4px 6px',
    'background:var(--chrome)', 'border-top:1px solid var(--border)',
    'scrollbar-width:none', '-webkit-overflow-scrolling:touch',
  ].join(';');
  for (const k of KEYS) {
    const b = document.createElement('button');
    b.textContent = k.label;
    b.style.cssText = [
      'flex:0 0 auto', 'font:inherit', 'font-size:12px', 'min-width:32px', 'padding:4px 7px', 'text-align:center',
      'border-radius:4px', 'border:1px solid var(--btn-border)', 'background:var(--btn)',
      'color:var(--fg)', 'cursor:pointer',
    ].join(';');
    // pointerup (not click) + preventDefault keeps focus off the key so the
    // soft keyboard / terminal input isn't disturbed — matches mobile-cc.
    b.tabIndex = -1;
    b.addEventListener('mousedown', (e) => e.preventDefault());
    b.addEventListener('pointerup', (e) => { e.preventDefault(); host.bus.emit('terminal.input', { key: k.key }); });
    row.appendChild(b);
  }
  host.mount('accessory', row);
}
