// Command chips — one-tap commands sent (with Enter) to the current pane.
// Editable list persisted in scoped storage; seeded once with CC-centric defaults.
// Agent-oriented defaults (this app drives agents, not a raw shell). Editable.
const DEFAULTS = [
  { label: '▶ cc', cmd: 'claude --dangerously-skip-permissions' },
  { label: 'continue', cmd: 'continue' },
  { label: '/clear', cmd: '/clear' },
  { label: '/compact', cmd: '/compact' },
];

export default function init(host) {
  let chips = host.storage.get('chips');
  if (!chips) { chips = DEFAULTS; host.storage.set('chips', chips); }

  const row = document.createElement('div');
  row.style.cssText = [
    'display:flex', 'gap:4px', 'overflow-x:auto', 'padding:4px 6px',
    'background:var(--chrome)', 'border-top:1px solid var(--border)',
    'scrollbar-width:none', '-webkit-overflow-scrolling:touch',
  ].join(';');

  for (const c of chips) {
    const b = document.createElement('button');
    b.textContent = c.label;
    b.style.cssText = [
      'flex:0 0 auto', 'font:inherit', 'font-size:12px', 'padding:4px 9px', 'border-radius:4px',
      'border:1px solid var(--btn-border)', 'background:var(--btn)', 'color:var(--fg)', 'cursor:pointer', 'white-space:nowrap',
    ].join(';');
    b.tabIndex = -1;
    b.addEventListener('mousedown', (e) => e.preventDefault());
    b.addEventListener('pointerup', (e) => {
      e.preventDefault();
      host.bus.emit('terminal.input', { data: c.cmd });
      host.bus.emit('terminal.input', { key: 'Enter' });
    });
    row.appendChild(b);
  }
  host.mount('accessory', row);
}
