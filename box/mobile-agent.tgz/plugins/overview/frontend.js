// Agent Overview — a "home" view: all agents at a glance (status + last line),
// the right front door for running many agents. Pure cross-plugin glue: reads
// the session list + per-session {state,last} the terminal publishes.
const DOT = { prompt: '#f0c040', active: '#4a9eff', finished: '#e8a828', idle: '#555' };
const LABEL = { prompt: 'waiting', active: 'working', finished: 'done', idle: 'idle' };
const RANK = { prompt: 3, finished: 2, active: 1, idle: 0 };

export default function init(host) {
  let sessions = [];
  let states = {};

  const btn = document.createElement('button');
  btn.textContent = '▤'; btn.title = 'all agents';
  btn.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer';
  btn.tabIndex = -1;
  host.mount('toolbar', btn);

  const stateOf = (s) => (states[s] && states[s].state) || 'idle';
  const lastOf = (s) => (states[s] && states[s].last) || '';

  function open() {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:300;background:var(--bg);display:flex;flex-direction:column';
    const head = document.createElement('div');
    head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid var(--border)';
    const h = document.createElement('div'); h.textContent = 'Agents'; h.style.cssText = 'font-size:15px;font-weight:bold;color:var(--fg)';
    const x = document.createElement('button'); x.textContent = '✕'; x.style.cssText = 'font-size:13px;width:28px;height:28px;border-radius:4px;border:1px solid var(--border);background:transparent;color:var(--fg);cursor:pointer';
    x.onclick = () => back.remove();
    head.append(h, x);
    const listEl = document.createElement('div');
    listEl.style.cssText = 'flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch';
    back.append(head, listEl);
    document.body.appendChild(back);

    // sort: waiting agents first (most urgent), then working, then the rest
    const sorted = [...sessions].sort((a, b) => (RANK[stateOf(b.session)] || 0) - (RANK[stateOf(a.session)] || 0));
    for (const s of sorted) {
      const st = stateOf(s.session);
      const row = document.createElement('button');
      row.style.cssText = 'display:flex;align-items:center;gap:10px;width:100%;text-align:left;padding:9px 12px;border:0;border-bottom:1px solid var(--border);background:transparent;color:var(--fg);cursor:pointer';
      const dot = document.createElement('span');
      dot.style.cssText = `flex:0 0 auto;width:10px;height:10px;border-radius:50%;background:${DOT[st]}`;
      if (st === 'prompt') dot.style.animation = 'mcc-pulse 1s infinite';
      const mid = document.createElement('div'); mid.style.cssText = 'flex:1;min-width:0';
      const name = document.createElement('div');
      name.innerHTML = `<span style="font-size:14px">${s.title || s.session}</span> <span style="font-size:11px;color:var(--accent);opacity:.8">${s.group && s.group !== s.session ? s.group : ''}</span>`;
      const last = document.createElement('div');
      last.textContent = lastOf(s.session) || '—';
      last.style.cssText = 'font-size:11px;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px';
      mid.append(name, last);
      const lbl = document.createElement('span');
      lbl.textContent = LABEL[st]; lbl.style.cssText = `flex:0 0 auto;font-size:10px;color:${DOT[st]}`;
      row.append(dot, mid, lbl);
      row.onclick = () => { host.bus.emit('terminal.switch', { session: s.session }); back.remove(); };
      listEl.appendChild(row);
    }
    if (!sorted.length) { const e = document.createElement('div'); e.textContent = 'No agents.'; e.style.cssText = 'padding:24px;color:#888'; listEl.appendChild(e); }
  }

  // open on CLICK (not pointerup): pointerup would open the overlay and then the
  // same tap's trailing synthetic click would land on a row underneath and close
  // it again (the flicker). One click = open, no trailing event.
  btn.onclick = () => open();
  host.bus.on('terminal.sessions', (l) => { sessions = l || []; });
  host.bus.on('terminal.states', (s) => { states = s || {}; });
  host.bus.emit('terminal.requestSessions');
}
