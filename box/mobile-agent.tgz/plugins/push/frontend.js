// Web Push frontend — 🔔 enables notifications: request permission, subscribe
// via PushManager with the server VAPID key, POST the subscription. After that
// the daemon pushes on every CC prompt even when the tab is closed.
function urlB64ToUint8Array(b64) {
  const pad = '='.repeat((4 - (b64.length % 4)) % 4);
  const base = (b64 + pad).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base);
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

export default function init(host) {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;

  const btn = document.createElement('button');
  btn.textContent = '🔔'; btn.title = 'notifications';
  btn.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer';
  btn.tabIndex = -1;
  host.mount('toolbar', btn);

  async function isSubscribed() {
    const reg = await navigator.serviceWorker.ready;
    return !!(await reg.pushManager.getSubscription());
  }
  async function refresh() { const on = await isSubscribed(); btn.textContent = '🔔'; btn.style.borderColor = on ? 'var(--accent)' : 'var(--btn-border)'; btn.style.background = 'var(--btn)'; btn.title = on ? 'notifications on' : 'enable notifications'; }

  async function enable() {
    btn.textContent = '🔔 …';
    try {
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') { btn.textContent = '🔔 denied'; return; }
      const { publicKey } = await (await host.api('vapid')).json();
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlB64ToUint8Array(publicKey) });
      await host.api('subscribe', { method: 'POST', body: JSON.stringify(sub), headers: { 'content-type': 'application/json' } });
    } catch (e) { host.log('push enable failed', e); btn.textContent = '🔔 failed'; setTimeout(refresh, 1500); return; }
    refresh();
  }

  btn.addEventListener('mousedown', (e) => e.preventDefault());
  btn.addEventListener('pointerup', async (e) => { e.preventDefault(); if (await isSubscribed()) return; enable(); });
  refresh();

  // notification tap -> SW posts a message -> switch to that session
  navigator.serviceWorker.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'focus-session' && e.data.session) host.bus.emit('terminal.switch', { session: e.data.session });
  });
}
