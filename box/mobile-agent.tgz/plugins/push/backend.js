// Web Push backend — VAPID keypair (generated once), subscription store, and a
// push on every CC permission prompt (kernel 'session.prompt' event from the
// terminal). The killer feature: phone buzzes when Claude needs you.
const fs = require('fs');
const path = require('path');
const webpush = require('web-push');

module.exports = function setup(ctx) {
  const keyFile = path.join(ctx.configDir, 'push-vapid.json');
  const subFile = path.join(ctx.configDir, 'push-subs.json');

  let vapid;
  try { vapid = JSON.parse(fs.readFileSync(keyFile, 'utf8')); }
  catch { vapid = webpush.generateVAPIDKeys(); fs.writeFileSync(keyFile, JSON.stringify(vapid)); }
  webpush.setVapidDetails('mailto:mobile-agent@localhost', vapid.publicKey, vapid.privateKey);

  let subs = [];
  try { subs = JSON.parse(fs.readFileSync(subFile, 'utf8')); } catch {}
  const saveSubs = () => fs.writeFileSync(subFile, JSON.stringify(subs));
  const keyOf = (s) => s && s.endpoint;

  ctx.route('vapid', (req, res) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ publicKey: vapid.publicKey })); });

  ctx.route('subscribe', (req, res) => {
    if (req.method !== 'POST') { res.writeHead(405); return res.end(); }
    const chunks = []; let n = 0; let over = false;
    req.on('data', (c) => { n += c.length; if (n > 1 << 20) { over = true; req.destroy(); } else chunks.push(c); }); // a push subscription is ~1 KB
    req.on('end', () => {
      if (over) { res.writeHead(413); return res.end('too large'); }
      try {
        const sub = JSON.parse(Buffer.concat(chunks).toString());
        if (keyOf(sub) && !subs.some((s) => keyOf(s) === keyOf(sub))) { subs.push(sub); saveSubs(); }
        res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ ok: true, count: subs.length }));
      } catch (e) { res.writeHead(400); res.end(e.message); }
    });
  });

  async function pushAll(payload) {
    const body = JSON.stringify(payload);
    for (const sub of [...subs]) {
      try { await webpush.sendNotification(sub, body); }
      catch (e) { if (e.statusCode === 404 || e.statusCode === 410) { subs = subs.filter((s) => keyOf(s) !== keyOf(sub)); saveSubs(); } }
    }
  }

  ctx.onEvent('session.prompt', ({ session }) => {
    ctx.log('push: prompt in', session);
    pushAll({ title: 'Claude needs you', body: `${session} is waiting for a response`, session });
  });

  // a manual test trigger (GET /api/p/push/test?session=foo)
  ctx.route('test', (req, res, url) => {
    pushAll({ title: 'mobile-agent test', body: 'push works 🎉', session: url.searchParams.get('session') || '' });
    res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ sent: subs.length }));
  });

  ctx.log(`ready (${subs.length} subs)`);
};
