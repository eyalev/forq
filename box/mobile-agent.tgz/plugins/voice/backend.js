// Voice backend — server-side settings store for the dictation pipeline.
//
// Single-user tool, so unlike ttyview's per-origin-localStorage model we keep
// the voice settings (engine, keys, vocabulary, toggles) on the daemon and
// hand them to whatever browser/phone connects — set your keys + vocabulary
// once and every device shares them. Stored in voice.json (git-ignored — never
// checkpointed). Keys ARE returned to the client: the Groq/Deepgram APIs are
// CORS-open and called browser-direct, and the client is the user (loopback /
// tailnet). Seeds keys from env (GROQ_API_KEY / DEEPGRAM_API_KEY) on first run.
const fs = require('fs');
const path = require('path');

const DEFAULTS = {
  engine: 'groq',                 // 'webspeech' | 'groq' (groq = the full pipeline)
  groqKey: '',
  deepgramKey: '',
  language: 'en',
  cleanup: true,
  livePreview: true,
  vocab: 'Claude Code, tmux, appcore, mobile-agent, git, commit, rebase, branch, ' +
         'repo, diff, merge, cargo, rustc, npm, systemd, journalctl, ssh, sudo, ' +
         'regex, JSON, API, CLI, stdout, stderr, localhost, daemon, plugin',
};

module.exports = function setup(ctx) {
  const file = path.join(ctx.configDir, 'voice.json');

  // keep keys out of any git checkpoint (studio makes configDir a repo)
  try {
    if (fs.existsSync(path.join(ctx.configDir, '.git'))) {
      const gi = path.join(ctx.configDir, '.gitignore');
      let cur = ''; try { cur = fs.readFileSync(gi, 'utf8'); } catch {}
      if (!cur.split('\n').includes('voice.json')) fs.writeFileSync(gi, cur + (cur && !cur.endsWith('\n') ? '\n' : '') + 'voice.json\n');
    }
  } catch (e) { ctx.log('gitignore ensure failed:', e.message); }

  const load = () => { let s = {}; try { s = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {} return Object.assign({}, DEFAULTS, s); };
  const save = (s) => fs.writeFileSync(file, JSON.stringify(s, null, 2));
  if (!fs.existsSync(file)) {
    const seed = Object.assign({}, DEFAULTS);
    if (process.env.GROQ_API_KEY) seed.groqKey = process.env.GROQ_API_KEY;
    if (process.env.DEEPGRAM_API_KEY) seed.deepgramKey = process.env.DEEPGRAM_API_KEY;
    save(seed);
    ctx.log('seeded voice.json', seed.groqKey ? '(groq key from env)' : '', seed.deepgramKey ? '(deepgram key from env)' : '');
  }

  // capped: settings JSON is tiny; refuse a runaway POST rather than buffer it
  // unbounded into memory (one client could OOM the daemon otherwise).
  const body = (req) => new Promise((r) => { const c = []; let n = 0; req.on('data', (x) => { n += x.length; if (n > 1 << 20) { req.destroy(); return r({}); } c.push(x); }); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString())); } catch { r({}); } }); });
  const json = (res, o) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };

  ctx.route('get', (req, res) => json(res, load()));
  ctx.route('set', async (req, res) => { const b = await body(req); save(Object.assign(load(), b)); json(res, { ok: true }); });

  ctx.log('ready');
};
