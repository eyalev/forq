// Voice Input — dictate into the agent's message box, with the full pipeline
// ported from mobile-cc/tmux-web (ttyview-stt-groq):
//
//   • LIVE preview while you speak — Deepgram nova-3 streaming (browser-direct
//     WebSocket, ['token', key] subprotocol; the only real-time engine that
//     works on Android, where the platform recognizer can't share the mic with
//     MediaRecorder). Falls back to the browser's Web Speech (desktop only).
//   • FINAL transcript — Groq Whisper (whisper-large-v3-turbo), recorded via
//     MediaRecorder and sent browser-direct (Groq's API is CORS-open).
//   • LLM CLEANUP overlay — llama-3.3-70b fixes punctuation, technical
//     near-misses, and Whisper's hallucinated trailing sign-offs.
//   • VOCABULARY — your technical terms bias Whisper (prompt), Deepgram
//     (keyterm), and the cleanup pass. Edit in the settings sheet (long-press
//     the mic).
//
// Settings (engine, keys, vocab, toggles) are stored SERVER-SIDE (single-user)
// so phone + desktop share them. The 🎤 mounts in the toolbar; tap to
// start/stop, long-press to open settings.
export default function init(host) {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const hasMediaRec = !!(navigator.mediaDevices && window.MediaRecorder);
  if (!SR && !hasMediaRec) return;

  const STT_MODEL = 'whisper-large-v3-turbo';
  const CLEANUP_MODEL = 'llama-3.3-70b-versatile';
  const GROQ_BASE = 'https://api.groq.com/openai/v1';
  const DG_LISTEN = 'wss://api.deepgram.com/v1/listen';
  const DG_MODEL = 'nova-3';
  const MAX_RECORD_MS = 120000;
  const IS_ANDROID = /Android/i.test(navigator.userAgent);

  const CLEANUP_PROMPT =
    'Clean this dictated text for a developer driving Claude Code in a terminal. ' +
    'Ensure the result has natural sentence capitalization and punctuation ' +
    '(periods, commas, question marks) the way a person would type it — add ' +
    'punctuation and capitalization where the raw transcript lacks it, without ' +
    'changing the wording. ' +
    'Correct obvious near-misses for technical words, paths, flags, and session names ' +
    'only when they are clearly present in the transcript. Never invent terms from ' +
    'context. Whisper STT frequently hallucinates a trailing "Thank you", "Thanks for ' +
    'watching", "Bye", "you", or similar sign-off when the recording ends in silence — ' +
    'remove ONLY such trailing sign-offs that look hallucinated (a single short polite ' +
    'phrase isolated at the very end after a complete sentence). Do not remove "Thank ' +
    'you" if it appears mid-sentence or is part of the actual message. Return only the ' +
    'cleaned text.';

  // ---- server-synced settings ----------------------------------------------
  let settings = null;   // populated async; record path guards on it
  const getJSON = (sub) => host.api(sub).then((r) => r.json());
  const setRemote = (partial) => host.api('set', { method: 'POST', body: JSON.stringify(partial), headers: { 'content-type': 'application/json' } });
  async function loadSettings() { settings = await getJSON('get'); return settings; }
  function patch(k, v) { if (settings) settings[k] = v; setRemote({ [k]: v }); }

  function log(ev, data) { try { console.log('[voice]', ev, data || ''); } catch (_) {} }

  // ---- target = the terminal's message box (stable ids) ---------------------
  const input = () => document.getElementById('term-input');
  function setText(t) { const el = input(); if (!el) return; el.value = t; el.dispatchEvent(new Event('input', { bubbles: true })); el.scrollLeft = el.scrollWidth; }
  function typedBase() { const el = input(); return el && el.value ? el.value.replace(/\s+$/, '') + ' ' : ''; }

  // ---- styles + toast -------------------------------------------------------
  if (!document.getElementById('voice-style')) {
    const st = document.createElement('style'); st.id = 'voice-style';
    st.textContent = `
      .voice-rec { border-color:#ff4444 !important; color:#ff4444 !important; }
      .voice-rec svg, .voice-busy svg { animation: voice-pulse 1s ease-in-out infinite; }
      .voice-busy svg { animation-duration:.6s; }
      @keyframes voice-pulse { 0%,100%{opacity:1} 50%{opacity:.35} }
      .voice-toast { position:fixed;left:50%;transform:translateX(-50%);bottom:110px;z-index:9999;max-width:86vw;
        background:var(--chrome);color:var(--fg);border:1px solid var(--border);border-radius:8px;padding:8px 14px;
        font-size:13px;box-shadow:0 4px 16px rgba(0,0,0,.4);opacity:0;transition:opacity .2s; }
      .voice-toast.err { border-color:#ff4444;color:#ff6666; }
      .voice-toast.show { opacity:1; }`;
    document.head.appendChild(st);
  }
  let toastEl = null, toastTimer = null;
  function toast(msg, isErr) {
    if (!toastEl) { toastEl = document.createElement('div'); toastEl.className = 'voice-toast'; document.body.appendChild(toastEl); }
    toastEl.textContent = msg; toastEl.classList.toggle('err', !!isErr); toastEl.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => toastEl.classList.remove('show'), 3500);
  }

  const MIC_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="18" height="18"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><line x1="12" y1="17" x2="12" y2="22"/><line x1="8" y1="22" x2="16" y2="22"/></svg>';

  function pickMime() {
    if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) return '';
    for (const c of ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus']) { try { if (MediaRecorder.isTypeSupported(c)) return c; } catch (_) {} }
    return '';
  }
  const extForMime = (m) => m.includes('mp4') ? 'mp4' : m.includes('ogg') ? 'ogg' : 'webm';

  // ---- Groq pipeline (browser-direct) --------------------------------------
  async function groqTranscribe(blob, mime, s) {
    const fd = new FormData();
    fd.append('file', blob, 'audio.' + extForMime(mime));
    fd.append('model', STT_MODEL); fd.append('response_format', 'json');
    if (s.language) fd.append('language', s.language);
    fd.append('prompt', s.vocab
      ? 'The following is a clearly punctuated technical message. Vocabulary: ' + s.vocab.slice(0, 760)
      : 'The following is a clearly punctuated technical message.');
    const t0 = performance.now();
    const r = await fetch(GROQ_BASE + '/audio/transcriptions', { method: 'POST', headers: { Authorization: 'Bearer ' + s.groqKey }, body: fd });
    const ms = Math.round(performance.now() - t0);
    if (!r.ok) { const b = await r.text().catch(() => ''); log('stt-error', { status: r.status, ms, body: b.slice(0, 160) }); throw new Error('Groq STT failed (HTTP ' + r.status + ')'); }
    const j = await r.json(); const text = (j.text || '').trim();
    log('stt-done', { ms, len: text.length });
    return text;
  }
  async function groqCleanup(text, s) {
    const prompt = CLEANUP_PROMPT + '\n\nContext and vocabulary:\n' + (s.vocab || '(none)') + '\n\nRaw transcript:\n' + text + '\n\nIf the raw transcript is empty or silence, return exactly EMPTY.';
    try {
      const t0 = performance.now();
      const r = await fetch(GROQ_BASE + '/chat/completions', { method: 'POST', headers: { Authorization: 'Bearer ' + s.groqKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: CLEANUP_MODEL, temperature: 0, messages: [{ role: 'user', content: prompt }] }) });
      if (!r.ok) { log('cleanup-error', { status: r.status }); return text; }
      const j = await r.json();
      let cleaned = ((j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content) || '').trim();
      if (cleaned === 'EMPTY') cleaned = '';
      log('cleanup-done', { ms: Math.round(performance.now() - t0), changed: cleaned !== text });
      return cleaned || text;   // never let cleanup erase a real transcript
    } catch (e) { log('cleanup-error', { error: String(e && e.message || e) }); return text; }
  }

  // ---- the mic button -------------------------------------------------------
  const btn = document.createElement('button');
  btn.tabIndex = -1; btn.innerHTML = MIC_SVG;
  btn.style.cssText = 'flex:0 0 auto;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--accent);cursor:pointer;display:inline-flex;align-items:center;justify-content:center';
  btn.title = 'Dictate (tap) · long-press for settings';
  host.mount('toolbar', btn);

  let state = 'idle';            // 'idle' | 'recording' | 'transcribing'
  let pendingSend = false;
  let base = '', preview = '', previewLocked = false;
  let rec = null, mediaRec = null, chunks = [], mime = '', safetyTimer = null;
  let dgWs = null, dgFinals = [], dgInterim = '', dgPending = [];

  function previewEngine(s) {
    if (!s.livePreview) return 'none';
    if (s.deepgramKey) return 'deepgram';
    if (SR && !IS_ANDROID) return 'webspeech';
    return 'none';
  }
  function setUiState(st) {
    state = st;
    btn.classList.toggle('voice-rec', st === 'recording');
    btn.classList.toggle('voice-busy', st === 'transcribing');
    btn.title = st === 'recording' ? 'Listening… tap to stop' : st === 'transcribing' ? 'Transcribing…' : 'Dictate (tap) · long-press for settings';
  }

  // --- Deepgram streaming ---
  function dgCompose() { const p = []; if (dgFinals.length) p.push(dgFinals.join(' ').trim()); if (dgInterim) p.push(dgInterim.trim()); return p.join(' ').replace(/\s+/g, ' ').trim(); }
  function dgFeed(blob) {
    if (!dgWs) return;
    blob.arrayBuffer().then((buf) => { if (!dgWs) return; if (dgWs.readyState === WebSocket.OPEN) { try { dgWs.send(buf); } catch (_) {} } else if (dgWs.readyState === WebSocket.CONNECTING) dgPending.push(buf); }).catch(() => {});
  }
  function startDeepgram(s) {
    dgFinals = []; dgInterim = ''; dgPending = [];
    const params = new URLSearchParams({ model: DG_MODEL, language: s.language || 'en', interim_results: 'true', smart_format: 'true', punctuate: 'true', endpointing: '300' });
    (s.vocab || '').split(',').map((x) => x.trim()).filter(Boolean).slice(0, 100).forEach((t) => params.append('keyterm', t));
    let ws;
    try { ws = new WebSocket(DG_LISTEN + '?' + params.toString(), ['token', s.deepgramKey]); ws.binaryType = 'arraybuffer'; }
    catch (e) { log('dg-create-error', { error: String(e && e.message || e) }); return; }
    dgWs = ws; const t0 = performance.now();
    ws.onopen = () => { const f = dgPending.length; for (const buf of dgPending) { try { ws.send(buf); } catch (_) { break; } } dgPending = []; log('dg-open', { ms: Math.round(performance.now() - t0), flushed: f }); };
    ws.onmessage = (ev) => {
      let msg; try { const raw = typeof ev.data === 'string' ? ev.data : new TextDecoder().decode(ev.data); msg = JSON.parse(raw); } catch (_) { return; }
      if (!msg || msg.type !== 'Results') return;
      const alt = msg.channel && msg.channel.alternatives && msg.channel.alternatives[0];
      const txt = ((alt && alt.transcript) || '').trim(); if (!txt) return;
      if (msg.is_final) { dgFinals.push(txt); dgInterim = ''; } else dgInterim = txt;
      preview = dgCompose(); if (!previewLocked) setText(base + preview);
    };
    ws.onerror = () => log('dg-error', {});
    ws.onclose = (e) => log('dg-close', { code: e && e.code, finals: dgFinals.length });
  }
  function stopDeepgram() { const ws = dgWs; dgWs = null; if (!ws) return; try { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'CloseStream' })); } catch (_) {} setTimeout(() => { try { ws.close(); } catch (_) {} }, 300); }

  // --- Web Speech (full engine or preview) ---
  function startRecognition(opts) {
    if (!SR) return null;
    const r = new SR(); let lang = (settings && settings.language) || navigator.language || 'en-US'; if (lang === 'en') lang = 'en-US';
    r.lang = lang; r.interimResults = true; r.continuous = !!opts.continuous;
    r.onresult = (e) => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) { const res = e.results[i]; if (res.isFinal) { if (opts.commitFinals) base += res[0].transcript.trim() + ' '; else preview += res[0].transcript.trim() + ' '; } else interim += res[0].transcript; }
      const committed = opts.commitFinals ? base : base + preview; setText(interim ? committed + interim : committed);
    };
    r.onerror = (e) => { if (e.error !== 'no-speech' && e.error !== 'aborted') log('webspeech-error', { error: e.error }); };
    r.onend = opts.onend || null;
    try { r.start(); } catch (e) { return null; }
    return r;
  }
  function startWebSpeech() {
    if (!SR) { toast('Web Speech unavailable — set engine to Groq in settings (long-press)', true); return; }
    base = typedBase();
    rec = startRecognition({ commitFinals: true, onend: () => { rec = null; setUiState('idle'); setText(base); finishAutoSend(); } });
    if (rec) setUiState('recording');
  }

  // --- Groq engine ---
  async function startGroq(s) {
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
    catch (e) { toast('Microphone access denied', true); log('mic-denied', { error: String(e && e.message || e) }); return; }
    mime = pickMime();
    try { mediaRec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined); }
    catch (e) { stream.getTracks().forEach((t) => t.stop()); toast('Recording unsupported here', true); return; }
    mime = mediaRec.mimeType || mime || 'audio/webm';
    chunks = []; base = typedBase(); preview = ''; previewLocked = false;
    const eng = previewEngine(s);
    mediaRec.ondataavailable = (e) => { if (e.data && e.data.size) { chunks.push(e.data); if (eng === 'deepgram') dgFeed(e.data); } };
    mediaRec.onstop = () => { stream.getTracks().forEach((t) => t.stop()); finishGroq(s); };
    if (eng === 'deepgram') { startDeepgram(s); mediaRec.start(250); } else mediaRec.start();
    log('record-start', { mime, preview: eng });
    if (eng === 'webspeech') rec = startRecognition({ commitFinals: false, onend: () => { rec = null; } });
    setUiState('recording');
    safetyTimer = setTimeout(() => { if (state === 'recording') stopGroqRecording(); }, MAX_RECORD_MS);
  }
  function stopGroqRecording() {
    clearTimeout(safetyTimer);
    if (rec) { try { rec.abort(); } catch (_) {} rec = null; }
    stopDeepgram();
    if (mediaRec && mediaRec.state !== 'inactive') { try { mediaRec.stop(); } catch (_) {} }
  }
  async function finishGroq(s) {
    mediaRec = null;
    const blob = new Blob(chunks, { type: mime }); chunks = [];
    log('record-stop', { bytes: blob.size });
    if (blob.size < 1000) { previewLocked = true; setUiState('idle'); setText(base); toast('No audio captured'); finishAutoSend(); return; }
    setUiState('transcribing'); setText(base + preview);
    try {
      let text = await groqTranscribe(blob, mime, s);
      if (text && s.cleanup) text = await groqCleanup(text, s);
      previewLocked = true; setUiState('idle');
      if (!text) { setText(base + preview); if (!preview) toast('No speech detected'); finishAutoSend(); return; }
      setText(base + text + ' '); finishAutoSend();
    } catch (e) {
      previewLocked = true; setUiState('idle'); setText(base + preview);
      toast(String(e && e.message || e) + (preview ? ' — kept live preview' : ''), true); finishAutoSend();
    }
  }

  // --- auto-send when Send is tapped mid-recording ---
  function finishAutoSend() { if (!pendingSend) return; pendingSend = false; const el = input(); if (!el || !el.value.trim()) return; const sb = document.getElementById('term-send'); if (sb) sb.click(); }
  function onSendClickCapture(e) {
    if (state === 'idle') return;
    e.preventDefault(); e.stopImmediatePropagation(); pendingSend = true;
    if (state === 'recording') { if (mediaRec) stopGroqRecording(); else if (rec) { try { rec.stop(); } catch (_) {} } }
  }
  const sendBtnEl = document.getElementById('term-send');
  if (sendBtnEl) sendBtnEl.addEventListener('click', onSendClickCapture, true);

  // --- tap = record toggle; long-press = settings ---
  let pressTimer = null, longFired = false;
  function toggleRecord() {
    const s = settings; if (!s) { toast('Loading settings…'); return; }
    if (s.engine === 'groq' && hasMediaRec) {
      if (!s.groqKey) { openSettings(); toast('Add a Groq API key to use the Groq engine', true); return; }
      if (state === 'idle') startGroq(s); else if (state === 'recording') stopGroqRecording();
    } else { if (rec) rec.stop(); else if (state === 'idle') startWebSpeech(); }
  }
  btn.addEventListener('mousedown', (e) => e.preventDefault());
  btn.addEventListener('pointerdown', () => { longFired = false; pressTimer = setTimeout(() => { longFired = true; openSettings(); }, 500); });
  btn.addEventListener('pointerup', (e) => { if (e.button !== undefined && e.button !== 0) return; clearTimeout(pressTimer); if (longFired) { longFired = false; return; } toggleRecord(); });
  btn.addEventListener('pointercancel', () => clearTimeout(pressTimer));

  loadSettings().then(() => log('settings-loaded', { engine: settings.engine, groq: !!settings.groqKey, deepgram: !!settings.deepgramKey }));

  // ---- settings sheet (bottom sheet) ---------------------------------------
  function openSettings() {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:340;background:rgba(0,0,0,.4);display:flex;flex-direction:column;justify-content:flex-end';
    const panel = document.createElement('div');
    panel.style.cssText = 'background:var(--chrome);border-top:1px solid var(--border);border-radius:16px 16px 0 0;display:flex;flex-direction:column;max-height:82vh';
    const head = document.createElement('div'); head.style.cssText = 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid var(--border)';
    const h = document.createElement('div'); h.textContent = 'Voice Input'; h.style.cssText = 'font-size:15px;font-weight:bold;color:var(--fg)';
    const x = document.createElement('button'); x.textContent = '✕'; x.style.cssText = 'font-size:13px;width:28px;height:28px;border-radius:4px;border:1px solid var(--border);background:transparent;color:var(--fg)'; x.onclick = () => back.remove();
    head.append(h, x);
    const bodyEl = document.createElement('div'); bodyEl.style.cssText = 'overflow-y:auto;padding:14px 16px 26px;display:flex;flex-direction:column;gap:14px';
    panel.append(head, bodyEl); back.append(panel); back.onclick = (e) => { if (e.target === back) back.remove(); };
    document.body.appendChild(back);

    const s = settings || {};
    const lblCss = 'display:block;font-size:12px;color:#888;margin-bottom:6px';
    const inCss = 'width:100%;box-sizing:border-box;background:var(--bg);color:var(--fg);border:1px solid var(--border);border-radius:6px;font:inherit;font-size:14px;padding:7px 10px';
    const hintCss = 'color:#777;font-size:11px;margin-top:4px';
    const mk = (tag, css, txt) => { const e = document.createElement(tag); if (css) e.style.cssText = css; if (txt != null) e.textContent = txt; return e; };
    const rowEl = () => { const d = mk('div'); bodyEl.appendChild(d); return d; };

    bodyEl.appendChild(mk('p', 'color:#888;font-size:12px;margin:0 0 4px', 'Tap 🎤 to dictate into the message box. Groq records → Whisper → LLM cleanup (accurate on technical words). Add a Deepgram key for real-time live preview as you speak (works on Android).'));

    // engine
    let d = rowEl(); d.appendChild(mk('label', lblCss, 'Engine'));
    const eSel = mk('select', inCss);
    for (const [v, t] of [['groq', 'Groq Whisper + LLM cleanup (recommended)'], ['webspeech', 'Web Speech (built-in, instant)']]) { const o = mk('option'); o.value = v; o.textContent = t; if ((s.engine || 'groq') === v) o.selected = true; eSel.appendChild(o); }
    eSel.onchange = () => patch('engine', eSel.value); d.appendChild(eSel);

    // key field helper with Test
    function keyRow(label, key, placeholder, tester, hint) {
      const dd = rowEl(); dd.appendChild(mk('label', lblCss, label));
      const wrap = mk('div', 'display:flex;gap:8px');
      const inp = mk('input', inCss + ';flex:1;-webkit-text-security:disc');
      inp.type = 'text'; inp.placeholder = placeholder; inp.value = s[key] || '';
      inp.autocomplete = 'off'; inp.spellcheck = false;
      for (const a of ['autocorrect', 'autocapitalize']) inp.setAttribute(a, 'off');
      for (const a of ['data-lpignore', 'data-1p-ignore', 'data-bwignore']) inp.setAttribute(a, 'true');
      inp.onchange = () => patch(key, inp.value.trim());
      const test = mk('button', 'background:var(--bg);color:var(--fg);border:1px solid var(--border);border-radius:6px;font:inherit;font-size:13px;padding:6px 14px;cursor:pointer', 'Test');
      test.onclick = () => tester(inp.value.trim(), test);
      wrap.append(inp, test); dd.appendChild(wrap);
      if (hint) dd.appendChild(mk('div', hintCss, hint));
    }
    keyRow('Groq API key', 'groqKey', 'gsk_…', async (key, test) => {
      if (!key) return toast('Enter a key first', true);
      test.disabled = true; test.textContent = '…';
      try { const r = await fetch(GROQ_BASE + '/models', { headers: { Authorization: 'Bearer ' + key } }); toast(r.ok ? 'Key works ✓' : 'Key rejected (HTTP ' + r.status + ')', !r.ok); }
      catch (e) { toast('Could not reach Groq', true); }
      test.disabled = false; test.textContent = 'Test';
    }, 'Required for the Groq engine. console.groq.com (free tier works).');
    keyRow('Deepgram API key (real-time preview)', 'deepgramKey', 'Token…', (key, test) => {
      if (!key) return toast('Enter a key first', true);
      test.disabled = true; test.textContent = '…'; let done = false; let ws;
      const fin = (ok, msg, err) => { if (done) return; done = true; test.disabled = false; test.textContent = 'Test'; toast(msg, err); try { if (ws) ws.close(); } catch (_) {} };
      try { ws = new WebSocket(DG_LISTEN + '?model=' + DG_MODEL, ['token', key]); } catch (e) { return fin(false, 'Could not open socket', true); }
      const tid = setTimeout(() => fin(false, 'Deepgram did not respond', true), 5000);
      ws.onopen = () => { clearTimeout(tid); fin(true, 'Key works ✓', false); };
      ws.onclose = (e) => { clearTimeout(tid); fin(false, 'Key rejected' + (e && e.code ? ' (code ' + e.code + ')' : ''), true); };
    }, 'Optional. Streams words live as you speak (nova-3) — the only live engine that works on Android. console.deepgram.com (free credit).');

    // language
    d = rowEl(); d.appendChild(mk('label', lblCss, 'Language (ISO code, blank = auto-detect)'));
    const langInp = mk('input', inCss + ';max-width:120px'); langInp.value = s.language || ''; langInp.placeholder = 'en';
    langInp.onchange = () => patch('language', langInp.value.trim()); d.appendChild(langInp);

    // toggles
    function toggle(label, key, hint) {
      const dd = rowEl(); const l = mk('label', 'display:inline-flex;align-items:center;gap:8px;color:var(--fg);font-size:14px;cursor:pointer');
      const cb = mk('input'); cb.type = 'checkbox'; cb.checked = !!s[key]; cb.onchange = () => patch(key, cb.checked);
      l.append(cb, document.createTextNode(label)); dd.appendChild(l);
      if (hint) dd.appendChild(mk('div', hintCss + ';margin-left:26px', hint));
    }
    toggle('LLM cleanup pass', 'cleanup', 'Fixes punctuation, technical near-misses, and Whisper\'s hallucinated trailing sign-offs (~0.5 s).');
    toggle('Live preview while recording', 'livePreview', 'Streams words into the box while recording; the Groq transcript replaces them on stop. Deepgram if keyed (Android-capable), else Web Speech (desktop).');

    // vocabulary
    d = rowEl(); d.appendChild(mk('label', lblCss, 'Technical vocabulary (comma-separated — biases Whisper, Deepgram & cleanup)'));
    const vta = mk('textarea', inCss + ';resize:vertical'); vta.rows = 4; vta.value = s.vocab || '';
    vta.onchange = () => patch('vocab', vta.value.trim()); d.appendChild(vta);
  }

  return function unmount() {
    clearTimeout(safetyTimer); clearTimeout(pressTimer);
    if (sendBtnEl) sendBtnEl.removeEventListener('click', onSendClickCapture, true);
    if (rec) { try { rec.abort(); } catch (_) {} rec = null; }
    if (dgWs) { try { dgWs.close(); } catch (_) {} dgWs = null; }
    if (mediaRec && mediaRec.state !== 'inactive') { try { mediaRec.stream.getTracks().forEach((t) => t.stop()); } catch (_) {} try { mediaRec.stop(); } catch (_) {} }
    mediaRec = null; btn.remove();
  };
}
