// Layouts — switch the whole chrome arrangement with one tap.
// A layout is just named CSS over the shell's slots and each plugin's mounted
// nodes (the shell tags them with data-plugin). Three shipped presets; the
// mechanism is data-driven, so more presets — or user-authored ones — are one
// object entry away.
export default function init(host) {
  const LAYOUTS = [
    { id: 'classic', label: 'Classic', hint: 'everything visible', css: '' },
    // Compact/Zen hide chrome AND flip the growth policy: mobile-agent's theme
    // plugin normally pins #slot-main at --term-h and lets the footer drawer
    // grow (tabs panel lives there). With the drawer contents hidden the
    // terminal should absorb the freed space — flex does the math, no pixel
    // constants. These rules tie on specificity+!important with the theme's,
    // and win because #layout-style is appended after #mobile-agent-layout.
    { id: 'compact', label: 'Compact', hint: 'keys, no tabs/toolbar', css: `
      #slot-toolbar > :not(#layout-btn), [data-plugin="tabs"] { display: none !important; }
      #slot-main   { flex: 1 1 auto !important; }
      #slot-footer { flex: 0 0 auto !important; }` },
    { id: 'zen', label: 'Zen', hint: 'just the terminal', css: `
      #slot-toolbar > :not(#layout-btn), #slot-accessory, [data-plugin="tabs"] { display: none !important; }
      #slot-main   { flex: 1 1 auto !important; }
      #slot-footer { flex: 0 0 auto !important; }` },
  ];

  let styleEl = document.getElementById('layout-style');
  if (!styleEl) {
    styleEl = document.createElement('style');
    styleEl.id = 'layout-style';
  }
  // (Re-)append even when it already exists: appendChild moves the node to the
  // end of <head>, keeping these rules after every other plugin's stylesheet so
  // the tie-breaking above stays true across hot-reloads.
  document.head.appendChild(styleEl);
  let current = host.storage.get('layout') || 'classic';

  function apply(id, announce) {
    const l = LAYOUTS.find((x) => x.id === id) || LAYOUTS[0];
    current = l.id;
    styleEl.textContent = l.css;
    host.storage.set('layout', current);
    btn.title = `Layout: ${l.label} — tap to switch`;
    host.bus.emit('ui.layout', { layout: current });
    // chrome rows appeared/disappeared → let the terminal re-measure
    window.dispatchEvent(new Event('resize'));
    if (announce) host.bus.emit('toast', { text: `Layout: ${l.label} (${l.hint})` });
  }

  const btn = document.createElement('button');
  btn.id = 'layout-btn';
  btn.tabIndex = -1;
  btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="16" height="16"><rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M3.5 14h17M9.5 14v6.5"/></svg>';
  btn.style.cssText = 'flex:0 0 auto;display:flex;align-items:center;justify-content:center;width:30px;height:26px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer;padding:0';
  btn.addEventListener('mousedown', (e) => e.preventDefault());
  btn.addEventListener('click', () => {
    const i = LAYOUTS.findIndex((x) => x.id === current);
    apply(LAYOUTS[(i + 1) % LAYOUTS.length].id, true);
  });
  host.mount('toolbar', btn);

  apply(current, false);
}
