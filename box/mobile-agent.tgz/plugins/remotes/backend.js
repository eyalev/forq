// Remote computers — backend only. Serves the header's switch-computer strip a
// merged list: this laptop first, then the user's running cloud boxes fetched
// from the remote control plane with a server-side session token.
//
// Why a plugin and not kernel code: the kernel stays domain-agnostic (it only
// knows "mounts": prefix -> target). This is the one place that knows what a
// "computer" is. The remote `url`s (/t/<id>/, /c/<id>/agent/) are passed
// through VERBATIM — the kernel's mounts make those paths live on OUR origin,
// which is the whole trick: same-origin navigation, no iframe, no token in the
// browser.
//
// Unconfigured (no remotes.json) it returns [] and the header strip stays
// hidden — the app degrades to exactly its non-remote UI.
const TTL_MS = 60_000;

module.exports = function setup(ctx) {
  const cfg = ctx.config || {};
  const base = String(cfg.base || '').replace(/\/+$/, '');
  const token = cfg.sessionToken || '';
  const localName = cfg.localName || 'laptop';

  let cache = null;      // { at, list }
  let inflight = null;   // dedupe concurrent fetches (every client tab asks at boot)

  const local = () => ({ name: localName, type: 'local', url: '/' });

  async function fetchRemotes() {
    // A signed-out / expired session answers with the login HTML, not JSON —
    // so "not an array" is the auth-expired signal, and it must degrade to an
    // empty strip rather than throwing. Failures are NOT cached (a box that
    // just booted should show up on the next poll, not 60s later).
    let r;
    try {
      r = await fetch(base + '/api/computers', {
        headers: { cookie: 'session=' + token, accept: 'application/json' },
        redirect: 'manual',
        signal: AbortSignal.timeout(10_000),
      });
    } catch (e) {
      ctx.log('remote list unreachable:', String((e && e.message) || e));
      return null;
    }
    if (!r.ok) { ctx.log('remote list rejected: http', r.status, '(auth expired?)'); return null; }
    let body;
    try { body = await r.json(); } catch { ctx.log('remote list not JSON (auth expired?)'); return null; }
    if (!Array.isArray(body)) { ctx.log('remote list not an array (auth expired?)'); return null; }
    return body;
  }

  async function computers() {
    if (!base || !token) return [];                       // unconfigured -> no strip
    if (cache && Date.now() - cache.at < TTL_MS) return cache.list;
    if (!inflight) {
      inflight = fetchRemotes().finally(() => { inflight = null; });
    }
    const list = await inflight;
    if (!list) return [];                                  // failure: no cache, no strip
    const merged = [local(), ...list];
    cache = { at: Date.now(), list: merged };
    return merged;
  }

  ctx.route('computers', async (req, res) => {
    let list;
    try { list = await computers(); } catch (e) { ctx.log('computers failed:', String((e && e.message) || e)); list = []; }
    res.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'no-store' });
    res.end(JSON.stringify(list));
  });

  return () => { cache = null; inflight = null; };
};
