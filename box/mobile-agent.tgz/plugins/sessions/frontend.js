// Session manager — create (FAB) + rename/kill (long-press a tab). Pure
// cross-plugin glue: emits terminal.{create,rename,kill}Session over the bus.
export default function init(host) {
  // --- "+ new agent" button in the toolbar (no more floating FAB overlap) -----
  const fab = document.createElement('button');
  fab.textContent = '➕'; fab.title = 'new agent session';
  fab.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer';
  fab.tabIndex = -1;
  host.mount('toolbar', fab);

  function card(title) {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center';
    const box = document.createElement('div');
    box.style.cssText = 'background:var(--chrome);border:1px solid var(--border);border-radius:12px;padding:16px;min-width:260px;display:flex;flex-direction:column;gap:10px';
    const h = document.createElement('div'); h.textContent = title; h.style.cssText = 'font-size:14px;color:var(--fg);font-weight:bold';
    box.appendChild(h);
    back.appendChild(box);
    back.onclick = (e) => { if (e.target === back) back.remove(); };
    host.mount('footer', back);
    return { back, box };
  }
  function button(label, primary) {
    const b = document.createElement('button');
    b.textContent = label;
    b.style.cssText = `font:inherit;font-size:13px;padding:6px 12px;border-radius:4px;border:1px solid ${primary ? 'var(--accent)' : 'var(--border)'};background:${primary ? 'var(--accent)' : 'transparent'};color:${primary ? 'var(--accent-fg)' : 'var(--fg)'};cursor:pointer`;
    return b;
  }

  const openCreate = () => {      // click (not pointerup) — avoids trailing-click closing the card
    const { back, box } = card('New session');
    const inputCss = 'background:var(--card);color:var(--fg);border:1px solid var(--btn-border);border-radius:8px;padding:8px 12px;font:inherit;width:100%';
    const lbl = (t) => { const d = document.createElement('div'); d.textContent = t; d.style.cssText = 'font-size:11px;color:var(--muted);margin-bottom:-4px'; return d; };
    const noCaps = (el) => { el.setAttribute('autocapitalize', 'none'); el.setAttribute('autocorrect', 'off'); el.spellcheck = false; };

    const name = document.createElement('input');
    name.placeholder = 'e.g. myproj'; name.autocomplete = 'off'; name.style.cssText = inputCss; noCaps(name);

    // Folder: relative names are created under the default project dir by the
    // backend, so "api" on a phone just works. Remembers last-used per device.
    const dir = document.createElement('input');
    dir.placeholder = 'default — or type one, created if missing'; dir.autocomplete = 'off';
    dir.value = host.storage.get('lastCwd') || '';
    dir.style.cssText = inputCss; noCaps(dir);

    // Claude permission mode: Auto (default) vs Bypass. Remembered per device.
    let mode = host.storage.get('ccMode') === 'bypass' ? 'bypass' : 'auto';
    const modeRow = document.createElement('div'); modeRow.style.cssText = 'display:flex;gap:8px';
    const mkMode = (id, label) => {
      const b = document.createElement('button'); b.textContent = label;
      const paint = () => { const on = mode === id; b.style.cssText = `flex:1;font:inherit;font-size:12px;padding:6px;border-radius:4px;cursor:pointer;border:1px solid ${on ? 'var(--accent)' : 'var(--border)'};background:${on ? 'var(--accent)' : 'transparent'};color:${on ? 'var(--accent-fg)' : 'var(--fg)'}`; };
      b.onclick = () => { mode = id; host.storage.set('ccMode', id); paintAll(); };
      b._paint = paint; return b;
    };
    const mAuto = mkMode('auto', 'Auto — approves routine edits');
    const mBypass = mkMode('bypass', 'Bypass — never asks');
    const paintAll = () => { mAuto._paint(); mBypass._paint(); };
    paintAll();
    modeRow.append(mAuto, mBypass);

    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:8px;justify-content:flex-end';
    const plain = button('Shell only'); const cc = button('+ Claude', true);
    const go = (withCc) => {
      const n = name.value.trim(); if (!n) return;
      const cwd = dir.value.trim();
      host.storage.set('lastCwd', cwd);
      host.bus.emit('terminal.createSession', { name: n, cc: withCc, mode, ...(cwd ? { cwd } : {}) });
      host.bus.emit('terminal.switchWhenReady', { session: n.replace(/[^a-zA-Z0-9_-]/g, '') });
      back.remove();
    };
    plain.onclick = () => go(false); cc.onclick = () => go(true);
    row.append(plain, cc);
    box.append(lbl('Session name'), name, lbl('Folder (optional)'), dir, lbl('Claude permissions'), modeRow, row);
    name.focus();
  };
  fab.onclick = openCreate;
  // Other plugins (e.g. the tabs rail's ➕) can open the same dialog.
  host.bus.on('sessions.openCreate', openCreate);

  // --- rename / kill menu (triggered by tab long-press) --------------------
  host.bus.on('session.menu', ({ session }) => {
    const { back, box } = card(session);
    const rename = button('Rename'); const kill = button('Kill'); kill.style.borderColor = '#e85b5b'; kill.style.color = '#e85b5b';
    const cancel = button('Cancel');
    rename.onclick = () => {
      box.textContent = '';
      const h = document.createElement('div'); h.textContent = `Rename ${session}`; h.style.cssText = 'font-size:14px;font-weight:bold';
      const inp = document.createElement('input'); inp.value = session;
      inp.style.cssText = 'background:var(--card);color:var(--fg);border:1px solid var(--btn-border);border-radius:8px;padding:8px 12px;font:inherit';
      const ok = button('Rename', true);
      ok.onclick = () => { const to = inp.value.trim(); if (to) host.bus.emit('terminal.renameSession', { session, to }); back.remove(); };
      box.append(h, inp, ok); inp.focus();
    };
    kill.onclick = () => { host.bus.emit('terminal.killSession', { session }); back.remove(); };
    cancel.onclick = () => back.remove();
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:8px;flex-direction:column';
    row.append(rename, kill, cancel);
    box.append(row);
  });
}
