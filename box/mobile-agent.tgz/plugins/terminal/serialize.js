// Serialize an @xterm/headless buffer line into compact colored spans.
// A span = { t:text, f?:fg-hex, b?:bg-hex, o?:flags } where flags bits are
// 1=bold 2=inverse 4=underline 8=dim. Defaults omitted to keep payload small.
// Rendering (theme default fg/bg) is the client's job.

// xterm 256-color palette -> hex.
// The 16 base colors use the VS Code terminal palette — the exact table
// tmux-web's ANSI classes use (.ansi-f1 #cd3131 … .ansi-f14 #29b8db) — so a
// TUI rendered here matches tmux-web pixel-for-pixel instead of the harsh
// raw-xterm defaults (#cd0000/#ff00ff…).
const PALETTE = (() => {
  const p = [
    '#000000', '#cd3131', '#0dbc79', '#e5e510', '#2472c8', '#bc3fbc', '#11a8cd', '#e5e5e5',
    '#666666', '#f14c4c', '#23d18b', '#f5f543', '#3b8eea', '#d670d6', '#29b8db', '#e5e5e5',
  ];
  const steps = [0, 95, 135, 175, 215, 255];
  for (let r = 0; r < 6; r++) for (let g = 0; g < 6; g++) for (let b = 0; b < 6; b++) {
    p.push('#' + [steps[r], steps[g], steps[b]].map((v) => v.toString(16).padStart(2, '0')).join(''));
  }
  for (let i = 0; i < 24; i++) { const v = (8 + i * 10).toString(16).padStart(2, '0'); p.push('#' + v + v + v); }
  return p;
})();

function hex(rgb) { return '#' + (rgb & 0xffffff).toString(16).padStart(6, '0'); }
function fgOf(c) { if (c.isFgDefault()) return null; if (c.isFgRGB()) return hex(c.getFgColor()); return PALETTE[c.getFgColor()] || null; }
function bgOf(c) { if (c.isBgDefault()) return null; if (c.isBgRGB()) return hex(c.getBgColor()); return PALETTE[c.getBgColor()] || null; }

function lineToSpans(line) {
  const spans = [];
  let cur = null;
  for (let x = 0; x < line.length; x++) {
    const c = line.getCell(x);
    if (!c) continue;
    if (c.getWidth() === 0) continue;        // trailing half of a wide char
    let ch = c.getChars();
    if (ch === '') ch = ' ';
    const f = fgOf(c), b = bgOf(c);
    let o = 0;
    if (c.isBold()) o |= 1;
    if (c.isInverse()) o |= 2;
    if (c.isUnderline()) o |= 4;
    if (c.isDim()) o |= 8;
    const sig = `${f}|${b}|${o}`;
    if (cur && cur.sig === sig) cur.t += ch;
    else { cur = { sig, t: ch, f, b, o }; spans.push(cur); }
  }
  // drop trailing default-styled whitespace
  while (spans.length) {
    const s = spans[spans.length - 1];
    if (s.f === null && s.b === null && s.o === 0 && /^\s*$/.test(s.t)) spans.pop();
    else break;
  }
  return spans.map((s) => ({ t: s.t, ...(s.f ? { f: s.f } : {}), ...(s.b ? { b: s.b } : {}), ...(s.o ? { o: s.o } : {}) }));
}

module.exports = { lineToSpans };
