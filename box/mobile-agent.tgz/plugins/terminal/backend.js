// Terminal plugin — backend (multi-session). The kernel has no terminal
// knowledge; all of it lives here. tmux -C control mode -> @xterm/headless
// model -> colored delta protocol, one attach per OPENED session (lazy).
//
// Protocol (kernel ws bus, plugin:'terminal'):
//   client -> 'list'              : -> 'sessions' {sessions:[{session,title}]}
//   client -> 'sub'   {session}   : attach if needed -> 'snapshot' {cols,rows} (rows=spans[])
//   client -> 'input' {data}      : send-keys to the subscribed session's active pane
//   backend-> 'snapshot' {session,cols,rows}
//   backend-> 'update'   {session,pre,rows}   (rows = changed-tail span-lines)
// 'pre' prefix-diff = frozen rows never re-keyed on append (push-semantics).
const { spawn, execSync, execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const { Terminal } = require('@xterm/headless');
const { lineToSpans } = require('./serialize');

const SCROLLBACK = 10000;

module.exports = function setup(ctx) {
  const cfg = ctx.config || {};

  // Read tmux output but DROP its stderr — when the tmux server is down, tmux
  // prints "no server running on …" to stderr on every call; execSync inherits
  // that to the daemon's stderr, flooding journald with thousands of identical
  // lines (seen in the access log). Ignoring fd 2 keeps the log clean; the
  // non-zero exit is still caught by the callers' try/catch.
  const RD = { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] };

  // --- JSONL instrumentation (ground every resize/restore decision in truth) --
  const diagPath = path.join(ctx.configDir, 'terminal-diag.jsonl');
  function diag(event, data) {
    try { fs.appendFileSync(diagPath, JSON.stringify({ t: new Date().toISOString(), event, ...data }) + '\n'); } catch {}
  }
  // A tmux session name in this app is always [A-Za-z0-9_.-] (that's what
  // creation allows and what real sessions look like). Every code path that
  // interpolates a session name into an execSync shell string MUST gate on this
  // — otherwise a name like `x; rm -rf ~` is remote code execution. The `sub`
  // handler used to pass the raw client value straight to activePane(); a PoC
  // proved the RCE. Validate at every tmux entry point, not just at creation.
  const validName = (s) => typeof s === 'string' && s.length > 0 && s.length <= 64 && /^[A-Za-z0-9_.-]+$/.test(s);
  function paneWidth(session) { if (!validName(session)) return null; try { return parseInt(execSync(`tmux list-panes -t ${session} -F '#{pane_width}'`, RD).split('\n')[0], 10); } catch { return null; } }

  // which sessions this app exposes as tabs
  function discover() {
    let all;
    try { all = execSync(`tmux list-sessions -F '#{session_name}'`, RD).trim().split('\n').filter(Boolean); }
    catch { return []; }
    let list;
    if (Array.isArray(cfg.sessions) && cfg.sessions.length) list = all.filter((s) => cfg.sessions.includes(s));
    else if (cfg.sessionFilter) { const re = new RegExp(cfg.sessionFilter); list = all.filter((s) => re.test(s)); }
    else list = all.slice();
    for (const c of created) if (all.includes(c) && !list.includes(c)) list.push(c); // UI-created sessions
    return list;
  }

  // group sessions into "projects" by stripping a trailing number
  // (api1..3 -> api, web2 -> web, build-bot -> build-bot).
  function groupOf(name) { const m = name.match(/^(.*?)-?\d+$/); return m ? m[1] : name; }
  // Live per-session cwd (active pane's current path) — one tmux call for all.
  function cwdMap() {
    const m = {};
    try {
      for (const line of execSync(`tmux list-sessions -F '#{session_name}\t#{pane_current_path}'`, RD).trim().split('\n')) {
        const [name, p] = line.split('\t'); if (name) m[name] = p || '';
      }
    } catch {}
    return m;
  }
  function sessionList() { const cw = cwdMap(); return discover().map((s) => ({ session: s, title: s, group: groupOf(s), cwd: cw[s] || '' })); }

  // sessions created from the UI bypass the filter so they show up immediately
  const created = new Set();

  function activePane(session) {
    if (!validName(session)) throw new Error(`invalid session name: ${JSON.stringify(session)}`);
    const l = execSync(`tmux list-panes -t ${session} -F '#{pane_active} #{pane_id} #{pane_width} #{pane_height}'`, RD)
      .trim().split('\n');
    const a = (l.find((x) => x.startsWith('1 ')) || l[0]).split(' ');
    return { id: a[1], cols: +a[2], rows: +a[3] };
  }

  const attached = new Map(); // session -> { ctl, pane, term, lastKeys, timer }
  const subs = new Map();     // ws -> session

  function unescape(s) {
    const out = [];
    for (let i = 0; i < s.length; i++) {
      if (s[i] === '\\') { if (s[i + 1] === '\\') { out.push(0x5c); i += 1; } else { out.push(parseInt(s.substr(i + 1, 3), 8)); i += 3; } }
      else out.push(s.charCodeAt(i));
    }
    return Buffer.from(out);
  }

  function rowsOf(term) {
    const b = term.buffer.active; const out = [];
    for (let y = 0; y < b.length; y++) { const l = b.getLine(y); out.push(l ? lineToSpans(l) : []); }
    return out;
  }

  function sendTo(ws, type, payload) { if (ws.readyState === 1) ws.send(JSON.stringify({ plugin: 'terminal', type, payload })); }

  // Build a fresh terminal seeded from the pane. `-J` joins wrapped lines into
  // logical lines so the new terminal re-wraps them cleanly at its width — this
  // is why we REBUILD on resize instead of term.resize() (xterm's in-place
  // reflow mangles wrapped-line boundaries: short padded rows mid-paragraph).
  // write() parses async, so `ready` resolves only after the seed is parsed.
  function seedTerm(paneId, cols, rows) {
    const term = new Terminal({ cols, rows, scrollback: SCROLLBACK, allowProposedApi: true });
    let resolveReady; const ready = new Promise((r) => { resolveReady = r; });
    try {
      const seed = execSync(`tmux capture-pane -p -e -J -S -${SCROLLBACK} -t ${paneId}`, { ...RD, maxBuffer: 64 * 1024 * 1024 });
      term.write(seed.replace(/\n/g, '\r\n'), resolveReady);
    } catch (e) { ctx.log('seed failed', e.message); resolveReady(); }
    return { term, ready };
  }

  function pushDelta(session) {
    const a = attached.get(session); if (!a) return;
    const rows = rowsOf(a.term);
    const keys = rows.map((r) => JSON.stringify(r));
    let pre = 0; const n = Math.min(keys.length, a.lastKeys.length);
    while (pre < n && keys[pre] === a.lastKeys[pre]) pre++;
    a.lastKeys = keys;
    const tail = rows.slice(pre);
    for (const [ws, sess] of subs) if (sess === session && ws.readyState === 1) sendTo(ws, 'update', { session, pre, rows: tail });
  }

  // Re-seed + snapshot when the window size changed (any client resized it).
  //
  // The capture MUST go through the control channel, not a separate
  // `execSync capture-pane`: an out-of-band capture snapshots the pane while
  // our ctl pipe still holds a backlog of %output events from BEFORE the
  // snapshot — those then get applied on top of the seed (double-painted
  // bytes), baking mangled ghost rows into an idle screen (seen live: Codex's
  // sign-in menu with stray glyphs and missing labels that never healed).
  // Sending `capture-pane` down ctl.stdin serializes everything in one FIFO:
  // lines before the reply block painted the old term, the block is the seed,
  // and the swap happens synchronously at %end — output after it lands on the
  // new term in order. No drops, no double-apply.
  function resyncToPane(session, pane) {
    const a = attached.get(session); if (!a) return;
    a.pane = pane;
    if (a.ctl && a.ctl.stdin.writable) {
      a.cmdQ.push({ type: 'capture', done: (lines) => {   // called synchronously at %end
        if (attached.get(session) !== a) return;
        let p = pane;
        try { p = activePane(session); } catch {}         // dims may have changed since scheduling
        a.pane = p;
        const term = new Terminal({ cols: p.cols, rows: p.rows, scrollback: SCROLLBACK, allowProposedApi: true });
        const old = a.term;
        a.term = term;                                    // swap NOW — later lines in this same read hit the new term
        try { old && old.dispose(); } catch {}            // xterm holds a 10k-row buffer; leaks on every resize otherwise
        // The ctl stream is decoded as latin1 ('binary'); hand xterm the raw
        // bytes so IT does the UTF-8 decode (else ✨ renders as â¨â).
        term.write(Buffer.from(lines.join('\r\n'), 'binary'), () => {
          if (attached.get(session) !== a || a.term !== term) return;
          const rows = rowsOf(term);
          a.lastKeys = rows.map((r) => JSON.stringify(r));
          for (const [ws, sess] of subs) if (sess === session && ws.readyState === 1) sendTo(ws, 'snapshot', { session, cols: term.cols, rows });
        });
      } });
      try { a.ctl.stdin.write(`capture-pane -p -e -J -S -${SCROLLBACK} -t ${pane.id}\n`); return; }
      catch { a.cmdQ.pop(); /* fall through to the out-of-band path */ }
    }
    const old = a.term;
    const { term, ready } = seedTerm(pane.id, pane.cols, pane.rows);
    a.term = term; a.ready = ready;
    try { old && old.dispose(); } catch {}
    ready.then(() => {
      const rows = rowsOf(a.term);
      a.lastKeys = rows.map((r) => JSON.stringify(r));
      for (const [ws, sess] of subs) if (sess === session && ws.readyState === 1) sendTo(ws, 'snapshot', { session, cols: a.term.cols, rows });
    });
  }

  function ensure(session) {
    if (attached.has(session)) return attached.get(session);
    let pane; try { pane = activePane(session); } catch (e) { ctx.log('no pane for', session, e.message); return null; }
    const { term, ready } = seedTerm(pane.id, pane.cols, pane.rows);
    // cmdQ pairs every command we write to ctl.stdin with its %begin/%end reply
    // block, in order. inBlock is the block currently being collected.
    const a = { ctl: null, pane, term, lastKeys: [], timer: null, ready, size: null, resyncT: null, cmdQ: [], inBlock: null };
    attached.set(session, a);
    // Settle re-seeds: full-screen TUIs (Codex's ratatui) repaint heavily
    // around attach/resize, and a capture taken mid-paint leaves ghost rows
    // and half-drawn labels that never clear on an idle screen (seen live:
    // duplicated welcome block, menu labels missing). tmux's own capture is
    // clean once painting settles — re-seed from it a couple of times.
    //
    // History-junk purge: the first client's width claim resizes the pane and
    // inline TUIs (Codex) repaint — the pre-resize paint scrolls into tmux
    // HISTORY as permanent garbage (duplicate welcome block, half-drawn menu
    // rows; verified against `capture-pane` ground truth, which was clean on
    // the visible screen but polluted in scrollback). When the pane had ZERO
    // history at attach (fresh boot, nothing real to lose), everything in
    // history by the settle point is provably resize junk — clear it once,
    // then re-seed. Panes with real history are never touched.
    let hist0 = 1;
    try { hist0 = parseInt(execSync(`tmux display -p -t ${pane.id} '#{history_size}'`, RD).trim(), 10); } catch {}
    for (const delay of [3000, 9000]) {
      setTimeout(() => {
        try {
          if (attached.get(session) !== a) return;
          if (delay === 9000 && hist0 === 0) { try { execSync(`tmux clear-history -t ${a.pane.id}`, RD); } catch {} }
          resyncToPane(session, activePane(session));
        } catch { /* session may be gone */ }
      }, delay);
    }
    // NOT -r: a read-only client gets 'ignore-size', so tmux won't let it drive
    // the window size. As a sized client we use tmux's NATIVE window-size=latest
    // handoff (same as tmux-web/mobile-cc) instead of manual resize-window.
    const ctl = spawn('tmux', ['-C', 'attach', '-t', session]);
    a.ctl = ctl;
    let buf = '';
    ctl.stdout.on('data', (chunk) => {
      buf += chunk.toString('binary');
      let nl;
      while ((nl = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, nl); buf = buf.slice(nl + 1);
        // Command-reply blocks: tmux writes each %begin..%end/%error block
        // contiguously (notifications are never interleaved inside), so plain
        // line collection is safe. Blocks arrive in the order commands were
        // written; unexpected blocks (e.g. the attach ack) fall to 'ignore'.
        if (a.inBlock) {
          if (line.startsWith('%end') || line.startsWith('%error')) {
            const blk = a.inBlock; a.inBlock = null;
            // on %error keep the old term — an empty "seed" would blank the view
            if (blk.exp && blk.exp.type === 'capture' && line.startsWith('%end')) { try { blk.exp.done(blk.lines); } catch (e) { ctx.log('capture-resync failed', session, e.message); } }
          } else a.inBlock.lines.push(line);
          continue;
        }
        if (line.startsWith('%begin')) { a.inBlock = { exp: a.cmdQ.shift() || { type: 'ignore' }, lines: [] }; continue; }
        if (line.startsWith('%output ')) {
          const rest = line.slice(8); const sp = rest.indexOf(' ');
          if (rest.slice(0, sp) === a.pane.id) { a.term.write(unescape(rest.slice(sp + 1))); if (!a.timer) a.timer = setTimeout(() => { a.timer = null; pushDelta(session); }, 40); }
        } else if (line.startsWith('%layout-change') || line.startsWith('%window-pane-changed')) {
          // window size or active pane changed (by us or another client) -> resync
          try {
            const p = activePane(session);
            if (p.id !== a.pane.id || p.cols !== a.pane.cols || p.rows !== a.pane.rows) {
              clearTimeout(a.resyncT);
              a.resyncT = setTimeout(() => { try { resyncToPane(session, activePane(session)); } catch {} }, 120);
            }
          } catch {}
        }
      }
    });
    ctl.on('exit', (c) => { ctx.log('control exited', session, c); try { a.term && a.term.dispose(); } catch {} attached.delete(session); });
    ctx.log('attached', session, a.pane.id);
    return a;
  }

  // declare THIS client's size to tmux; with window-size=latest the window adopts
  // it (and re-claims it when the phone comes back to the foreground).
  function claimSize(a, cols, rows) {
    if (!a || !a.ctl || !a.ctl.stdin.writable) return;
    a.size = { cols, rows };
    a.cmdQ.push({ type: 'ignore' });                      // pair with the refresh-client reply block
    try { a.ctl.stdin.write(`refresh-client -C ${cols}x${rows}\n`); } catch { a.cmdQ.pop(); }
  }

  // --- routes ---------------------------------------------------------------
  ctx.route('sessions', (req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ sessions: sessionList() }));
  });

  // Latest per-session states over HTTP (same payload the WS broadcasts).
  // Hosts poll this to know whether the agent is mid-task — e.g. OpenDev's
  // keep-awake alarm extends the machine's life while any session is active.
  ctx.route('states', (req, res) => {
    const busy = Object.values(lastStates).some((s) => s.state === 'active');
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ states: lastStates, busy }));
  });

  // Host-driven prompt injection (OpenDev Bots): the platform worker POSTs a
  // message for the agent without any browser attached. Reaches tmux directly
  // (activePane), so it works on a machine nobody is watching. The
  // send-then-settle-then-Enter shape is the tmux-TUI rule (Enter must land
  // after the TUI processed the literal).
  // Submit through the SAME verified path the UI uses: type the literal, then
  // Enter only once the TUI has rendered it, retrying until the input box
  // actually empties. A naive send-then-400ms-Enter left the prompt sitting
  // unsent at the ❯ line (found live — the bot looked like it hung while
  // Claude Code had simply never received a Return).
  function injectPrompt(session, text) {
    if (!validName(session) || typeof text !== 'string' || !text.trim()) {
      return Promise.reject(new Error('bad request'));
    }
    const pane = activePane(session);
    lastLiteral.set(session, { ts: Date.now(), frag: fragOf(text) });
    spawn('tmux', ['send-keys', '-t', pane.id, '-l', '--', text]);
    return verifiedEnter(session, { pane });
  }

  ctx.route('prompt', (req, res) => {
    if (req.method !== 'POST') { res.writeHead(405); return res.end(); }
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 65536) req.destroy(); });
    req.on('end', () => {
      let p;
      try { const { session, text } = JSON.parse(body || '{}'); p = injectPrompt(session, text); }
      catch (e) { res.writeHead(500); return res.end(String(e.message || e)); }
      p.then(() => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ ok: true })); })
        .catch((e) => { res.writeHead(e.message === 'bad request' ? 400 : 500); res.end(String(e.message || e)); });
    });
  });

  // In-process prompt injection for sibling plugins (the router dispatches work
  // to sessions the browser isn't even looking at). Same verified path as the
  // route — terminal stays the ONLY writer to a pane, so the submit dance lives
  // in exactly one place.
  ctx.onEvent('agent.prompt', (p) => {
    const { session, text, ref } = p || {};
    injectPrompt(session, text)
      .then(() => ctx.emit('agent.prompt.result', { ref, session, ok: true }))
      .catch((e) => ctx.emit('agent.prompt.result', { ref, session, ok: false, error: String((e && e.message) || e) }));
  });
  // Plain-text pane tail — the worker captures this as the bot's reply after
  // the turn settles. Ground truth from tmux, not our renderer.
  ctx.route('text', (req, res, url) => {
    try {
      const session = url.searchParams.get('session');
      const lines = Math.max(1, Math.min(parseInt(url.searchParams.get('lines'), 10) || 60, 400));
      if (!validName(session)) { res.writeHead(400); return res.end('bad session'); }
      const pane = activePane(session);
      const out = execSync(`tmux capture-pane -p -t ${pane.id} -S -${lines}`, { ...RD, maxBuffer: 8 * 1024 * 1024 });
      res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' });
      res.end(out);
    } catch (e) { res.writeHead(500); res.end(String(e.message || e)); }
  });

  // --- ws -------------------------------------------------------------------
  ctx.on('list', (_p, client) => client.send('sessions', { sessions: sessionList() }));

  // --- per-session status (for tab dots) ------------------------------------
  // prompt = CC waiting for you (amber); active = recent output (blue);
  // finished = produced output since you last viewed, now idle (orange).
  const states = {}; // session -> { viewed, lastCap, lastChange }
  let lastStates = {}; // latest poll() output, served by the 'states' route
  // Also covers Claude Code's OPTION PICKER ("1. …  2. …  Enter to select"),
  // which is just as much "the agent is blocked on you" as a permission
  // prompt — before this it read as plain output, so the tab dot stayed calm
  // and the router happily called the turn finished on a question.
  const PROMPT_RE = /(do you want to proceed|❯\s*1\.\s*yes|❯\s*yes|\(y\/n\)|\[y\/n\]|press enter to continue|allow this|approve this|waiting for your|enter to select\b|↑\/↓ to navigate)/i;
  // Claude Code prints a DIMMED suggested next prompt on the ❯ line when it is
  // idle ("❯ Yes, fix both"). Nothing is waiting on you — but it reads exactly
  // like the confirm prompt, so the tab went amber and a web push fired every
  // time the agent FINISHED. Capture with -e and drop the dim-wrapped spans:
  // a real prompt is never dim, and a suggestion always is.
  const ANSI = /\x1b\[[0-9;]*[A-Za-z]/g;
  const DIM_SPAN = /\x1b\[2m[\s\S]*?\x1b\[(?:0|22)m/g;
  const clean = (raw) => raw.replace(ANSI, '');
  const attention = (raw) => raw.replace(DIM_SPAN, '').replace(ANSI, '');
  function poll() {
    const now = Date.now();
    const cw = cwdMap();
    const viewedSet = new Set(subs.values());
    const out = {};
    for (const s of discover()) {
      const st = states[s] || (states[s] = { viewed: 0, lastCap: '', lastChange: 0 });
      let raw = '';
      try { raw = execSync(`tmux capture-pane -p -e -t ${s} -S -30`, { encoding: 'utf8' }); } catch { out[s] = { state: 'idle', last: '' }; continue; }
      const cap = clean(raw);
      if (cap !== st.lastCap) { st.lastChange = now; st.lastCap = cap; } // content changed => activity
      const idleMs = now - st.lastChange;
      const prompt = PROMPT_RE.test(attention(raw));
      if (prompt && !st.wasPrompt) ctx.emit('session.prompt', { session: s }); // rising edge -> web push
      st.wasPrompt = prompt;
      let state = 'idle';
      if (prompt) state = 'prompt';
      else if (idleMs < 3000) state = 'active';                                  // changed within last poll
      else if (st.lastChange > st.viewed && idleMs < 300000) state = 'finished'; // produced output since viewed, now idle
      const last = (cap.split('\n').filter((l) => l.trim()).pop() || '').trim().slice(0, 80); // last non-empty line
      out[s] = { state, last, cwd: cw[s] || '' };
    }
    lastStates = out;
    ctx.broadcast('states', { states: out });
    ctx.emit('session.states', { states: out });   // sibling backends (router) track turns
  }
  const pollTimer = setInterval(poll, 2000);
  setTimeout(poll, 500);

  ctx.on('sub', (p, client) => {
    const session = p && p.session; if (!session) return;
    // NOTE: do NOT release the previous session here. Releasing on every switch
    // caused the window to oscillate (restore->resize) and CC to redraw at mixed
    // widths into scrollback. A session stays pinned at the phone width until the
    // phone DISCONNECTS — stable width => clean, consistent history.
    const a = ensure(session); if (!a) return;
    subs.set(client.raw, session);
    (states[session] || (states[session] = { viewed: 0, lastCap: '', lastChange: 0 })).viewed = Date.now(); // viewing clears 'finished'
    a.ready.then(() => {
      const rows = rowsOf(a.term);
      a.lastKeys = rows.map((r) => JSON.stringify(r));
      client.send('snapshot', { session, cols: a.term.cols, rows });
    });
  });

  // --- session management ---------------------------------------------------
  const SAFE = (n) => (n || '').replace(/[^a-zA-Z0-9_-]/g, '');
  function detach(session) { const a = attached.get(session); if (a) { try { a.ctl && a.ctl.kill(); } catch {} try { a.term && a.term.dispose(); } catch {} attached.delete(session); } delete states[session]; }
  function broadcastSessions() { ctx.broadcast('sessions', { sessions: sessionList() }); }
  ctx.on('create', (p) => {
    const name = SAFE(p && p.name); if (!name) return;
    // Working dir resolution: relative input ("myproj") is resolved under the
    // configured defaultCwd and CREATED if missing — on a phone, typing a bare
    // project name should just work. Absolute paths are used as-is when they
    // exist. Sessions always get an explicit -c: without it, tmux falls back
    // to whatever cwd the server happened to start with (which, after a
    // daemon-restarted server, was the daemon's own cwd — sessions landed in
    // surprise directories like /workspace).
    const defaultCwd = cfg.defaultCwd || process.env.HOME || '/';
    let cwd = defaultCwd;
    const want = p && typeof p.cwd === 'string' ? p.cwd.trim() : '';
    if (want) {
      const resolved = path.isAbsolute(want) ? want : path.join(defaultCwd, want);
      try {
        if (!fs.existsSync(resolved)) fs.mkdirSync(resolved, { recursive: true });
        cwd = resolved;
      } catch (e) { ctx.log('cwd create failed, using default', e.message); }
    }
    // Claude permission mode for cc sessions: 'auto' (default) or 'bypass'.
    const mode = p && p.mode === 'bypass' ? 'bypass' : 'auto';
    const ccCmd = mode === 'bypass'
      ? 'claude --dangerously-skip-permissions'
      : 'claude --permission-mode auto';
    try {
      // argv form (execFileSync/spawn) — never a shell string — so a cwd that
      // contains shell metacharacters can't inject (name is already SAFE()d).
      //
      // Ask TMUX whether the session exists — never the `created` memo. That set
      // only records names this process has minted; it says nothing about what is
      // alive now. Treating it as truth meant that once a name had been created,
      // re-creating it after the session died (killed elsewhere, tmux server
      // restarted, machine rebooted) silently did nothing: no session, no error,
      // just a tab that never appears.
      const exists = (() => { try { execFileSync('tmux', ['has-session', '-t', name], { stdio: 'ignore' }); return true; } catch { return false; } })();
      if (!exists) {
        created.delete(name);           // drop the stale memo before re-minting
        execFileSync('tmux', ['new-session', '-d', '-s', name, '-x', '100', '-y', '30', '-c', cwd]);
        if (p.cc) spawn('tmux', ['send-keys', '-t', name, ccCmd, 'Enter']);
      }
      created.add(name);
    } catch (e) { ctx.log('create failed', e.message); }
    broadcastSessions();
  });
  ctx.on('rename', (p) => {
    const from = SAFE(p && p.session); const to = SAFE(p && p.to); if (!from || !to) return;
    try { execSync(`tmux rename-session -t ${from} ${to}`); detach(from); if (created.delete(from)) created.add(to); else created.add(to); } catch (e) { ctx.log('rename failed', e.message); }
    broadcastSessions();
  });
  ctx.on('kill', (p) => {
    const s = SAFE(p && p.session); if (!s) return;
    try { execSync(`tmux kill-session -t ${s}`); } catch (e) { ctx.log('kill failed', e.message); }
    detach(s); created.delete(s);
    broadcastSessions();
  });

  // Window sizing uses tmux's NATIVE window-size=latest handoff. the app declares
  // its control client's size; when the phone is the active client the window
  // adopts it, and tmux hands the size back to mobile-cc / tmux-web / a desktop
  // terminal when THEY become active — exactly how those apps coexist. No manual
  // resize-window / pin / restore, so no extra redraws polluting shared history.
  // --- multi-client width arbitration: SMALLEST claim wins -------------------
  // With several clients on one session, last-claimer-wins meant a desktop
  // opening later forced 191 cols onto a phone (tiny font). Instead: each
  // client's desired size is recorded, and the applied size is the MIN over
  // live viewers — the phone stays readable, the desktop shows a narrow
  // column, and when the phone leaves the desktop widens back automatically.
  const sizeClaims = new Map(); // ws -> { session, cols, rows }
  function arbitrate(session) {
    const a = attached.get(session); if (!a) return;
    let cols = Infinity, rows = Infinity;
    for (const [ws, claim] of sizeClaims) {
      if (claim.session !== session) continue;
      if (ws.readyState !== 1 || subs.get(ws) !== session) { sizeClaims.delete(ws); continue; }
      cols = Math.min(cols, claim.cols);
      rows = Math.min(rows, claim.rows);
    }
    if (!isFinite(cols)) return;
    if (a.pane && a.pane.cols === cols && a.pane.rows === rows) return; // already there
    diag('arbitrated_size', { session, cols, rows, claims: [...sizeClaims.values()].filter((c) => c.session === session).map((c) => c.cols) });
    claimSize(a, cols, rows);
  }
  ctx.on('resize', (p, client) => {
    if (client.raw._readonly) return;   // viewers observe; they never drive the width
    const session = subs.get(client.raw); if (!session) return;
    const a = attached.get(session); if (!a) return;
    const cols = Math.max(20, Math.min(parseInt(p && p.cols, 10) || 0, 400));
    const rows = Math.max(5, Math.min(parseInt(p && p.rows, 10) || 40, 200));
    if (!cols) return;
    diag('claim_size', { session, cols, rows });
    sizeClaims.set(client.raw, { session, cols, rows });
    arbitrate(session);
  });

  ctx.onDisconnect((ws) => {
    const session = subs.get(ws);
    subs.delete(ws);
    sizeClaims.delete(ws);
    if (session) arbitrate(session); // a departed small client releases its width
  });

  // Verified prompt submit. Claude Code coalesces rapid input as a paste
  // (window extends up to ~500ms while chunks arrive) and an Enter landing
  // inside that window is swallowed as a pasted newline — a fixed delay is a
  // bet against the scheduler (a 220ms gap still lost a prompt under load).
  // So: evidence on both edges instead of timers.
  //   text → wait until the pane PROVABLY shows it in the input box
  //   Enter → wait until the input box PROVABLY cleared; one retry if not
  // Bare Enter with no recent literal (menu confirms, quick keys) is sent
  // immediately — the dance only applies to typed prompts.
  const lastLiteral = new Map(); // session -> { ts, frag }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const fragOf = (text) => {
    const t = String(text).trim();
    const n = t.replace(/\s+/g, ' ');
    return n.length <= 14 ? n : n.slice(-14);
  };
  const capTail = (paneId) => {
    try { return execSync(`tmux capture-pane -p -t ${paneId} | tail -15`, RD); } catch { return ''; }
  };
  // The input box wraps at pane width, splitting any fragment across lines —
  // matching must collapse whitespace/newlines on BOTH sides (found live: the
  // visibility check timed out on a 150-char prompt and degraded to a fixed
  // delay).
  const norm = (t) => String(t).replace(/\s+/g, ' ');
  // The input box = lines from the LAST '❯' to the end of the capture (wrapped
  // input continues on indented lines below it; after submit the echoed prompt
  // lives ABOVE the ❯, so this region empties out).
  const inputRegion = (paneId) => {
    const lines = capTail(paneId).split('\n');
    let idx = -1;
    for (let i = 0; i < lines.length; i++) if (/^\s*❯/.test(lines[i])) idx = i;
    return idx < 0 ? '' : lines.slice(idx).join('\n');
  };
  async function verifiedEnter(session, a) {
    const paneId = a.pane.id;
    const rec = lastLiteral.get(session);
    const fresh = rec && Date.now() - rec.ts < 3000 && rec.frag;
    if (!fresh) { spawn('tmux', ['send-keys', '-t', paneId, 'Enter']); return; }
    const frag = rec.frag;
    // 1. wait for the text to be visible in the pane (paste window closed +
    //    rendered). '[Pasted text' covers CC's placeholder for big pastes.
    const t0 = Date.now();
    let seen = false;
    while (Date.now() - t0 < 2000) {
      const tail = norm(capTail(paneId));
      if (tail.includes(frag) || tail.includes('[Pasted text')) { seen = true; break; }
      await sleep(60);
    }
    diag('submit_visible', { session, seen, waitedMs: Date.now() - t0 });
    // 2. Enter, then confirm the input box actually emptied; one retry.
    for (let attempt = 1; attempt <= 2; attempt++) {
      spawn('tmux', ['send-keys', '-t', paneId, 'Enter']);
      const t1 = Date.now();
      while (Date.now() - t1 < 900) {
        await sleep(80);
        const region = norm(inputRegion(paneId));
        if (!region.includes(frag) && !region.includes('[Pasted text')) {
          diag('submit_ok', { session, attempt, ms: Date.now() - t0 });
          return;
        }
      }
      diag('submit_retry', { session, attempt });
    }
    diag('submit_gave_up', { session });
  }
  // Typing attribution for the presence indicator: throttled per-client
  // broadcast of WHO is sending input (identity injected by the host proxy).
  const lastTypingAt = new WeakMap();
  ctx.on('input', (p, client) => {
    if (client.raw._readonly) return;   // defense in depth — kernel whitelist already drops this
    const session = subs.get(client.raw); if (!session) return;
    const a = attached.get(session); if (!a) return;
    const now = Date.now();
    if ((lastTypingAt.get(client.raw) || 0) < now - 1500) {
      lastTypingAt.set(client.raw, now);
      ctx.broadcast('typing', { user: client.raw._user || 'someone', session });
    }
    if (p && p.key) { spawn('tmux', ['send-keys', '-t', a.pane.id, p.key]); return; } // tmux key-name (C-c, Escape, Up…)
    const data = p && p.data;
    if (data === '\r' || data === '\n') {
      verifiedEnter(session, a).catch((e) => ctx.log('verifiedEnter failed', e.message));
    } else if (data != null) {
      lastLiteral.set(session, { ts: Date.now(), frag: fragOf(data) });
      spawn('tmux', ['send-keys', '-t', a.pane.id, '-l', '--', data]);
    }
  });

  return () => {
    clearInterval(pollTimer);
    // detaching our control clients hands the size back to other clients natively
    for (const a of attached.values()) { try { a.ctl && a.ctl.kill(); } catch {} try { a.term && a.term.dispose(); } catch {} }
  };
};
