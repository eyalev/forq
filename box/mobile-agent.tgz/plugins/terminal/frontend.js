// Terminal plugin — frontend. Native-scrollable DOM rows (smooth scroll), now
// with colored spans + multi-session switching driven by the cross-plugin bus.
//   bus 'terminal.switch' {session}  : switch the visible session
//   bus 'terminal.input'  {data}     : inject keys (from quick-keys etc.)
//   bus 'terminal.sessions' [list]   : published for the tabs plugin
//   bus 'terminal.active' {session}  : current session (tabs highlights it)
export default function init(host) {
  const screen = document.createElement('div');
  screen.style.cssText = [
    'flex:1 1 auto', 'overflow-y:auto', 'overflow-x:hidden', '-webkit-overflow-scrolling:touch',
    'overscroll-behavior:contain', 'overflow-anchor:none', 'padding:4px 6px', 'line-height:1.25',
  ].join(';');
  // Input row metrics mirror tmux-web's #chat-input-area exactly
  // (6/12 padding, 8px gap, 36px controls, system-ui 14px) so the two apps
  // feel identical at the thumb line.
  const bar = document.createElement('div');
  bar.style.cssText = 'flex:0 0 auto;display:flex;gap:8px;padding:6px 12px;background:var(--chrome);border-top:1px solid var(--border)';
  const input = document.createElement('input');
  input.id = 'term-input';   // stable id so plugins (e.g. voice dictation) can drive the box
  input.placeholder = 'type → Enter sends to the pane'; input.autocomplete = 'off';
  // Terminal-appropriate soft keyboard: no autocorrect/spellcheck ever, and
  // no auto-capitalized first letter by default (commands are case-sensitive
  // — `Pwd` is not `pwd`). Capitalization is a user setting: the Settings
  // sheet broadcasts `ui.autocapitalize` over the bus; we re-request on init
  // so plugin load order doesn't matter.
  input.setAttribute('autocapitalize', 'none');
  input.setAttribute('autocorrect', 'off');
  input.spellcheck = false;
  host.bus.on('ui.autocapitalize', (p) => input.setAttribute('autocapitalize', p && p.on ? 'sentences' : 'none'));
  host.bus.emit('ui.autocapitalize.request', {});
  input.style.cssText = 'flex:1;min-width:0;height:36px;background:var(--card);color:var(--fg);border:1px solid #444;border-radius:8px;padding:0 12px;font:14px system-ui,sans-serif';
  const send = document.createElement('button');
  send.id = 'term-send';
  send.textContent = '⏎'; send.style.cssText = 'height:36px;background:var(--accent);color:var(--accent-fg);border:0;border-radius:8px;padding:0 10px;font:14px system-ui,sans-serif;display:flex;align-items:center';
  bar.append(input, send);
  host.mount('main', screen);   // scroll area
  host.mount('footer', bar);    // input rides at the very bottom (thumb reach)
  // Read-only viewer (?view= share link): the full UI stays VISIBLE so a
  // visitor sees the real product (owner request: no forced Zen, no hiding —
  // hiding after first paint also flashed). The composer is disabled with an
  // explanatory placeholder; everything else looks normal and is inert
  // server-side (kernel whitelists terminal list/sub only). Width claims are
  // skipped so a viewer can never resize the owner's pane.
  const READONLY = new URLSearchParams(location.search).has('view');
  if (READONLY) {
    input.disabled = true;
    input.placeholder = 'read-only view — watching live';
    send.disabled = true;
    send.style.opacity = '0.5';
    const st = document.createElement('style');
    st.textContent = '[data-plugin="images"] { pointer-events: none; opacity: .55 }';
    document.head.appendChild(st);
  }

  let current = null;
  let pendingSwitch = null;
  let cols = 0;
  const rows = [];
  const atBottom = () => screen.scrollHeight - screen.scrollTop - screen.clientHeight < 40;

  // Base font size = the density control. Smaller font => more columns fit (the
  // window is claimed at that column count). Persisted per device; A-/A+ adjust
  // it. Default 11px ≈ ~55 cols on a phone (matching mobile-cc/tmux-web density).
  const DEFAULT_FONT = 11;
  let base = Math.max(6, Math.min(host.storage.get('fontPx') || DEFAULT_FONT, 24));
  screen.style.fontSize = base + 'px';
  function charWidthAtBase() {
    const probe = document.createElement('span');
    probe.style.cssText = `position:absolute;visibility:hidden;white-space:pre;font-size:${base}px`;
    probe.textContent = 'M'.repeat(40);
    screen.appendChild(probe);
    const w = probe.getBoundingClientRect().width / 40;
    probe.remove();
    return w || base * 0.6;
  }
  function desiredCols() {
    if (!screen.clientWidth) return 0;
    const cs = getComputedStyle(screen);
    const avail = screen.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    return Math.max(20, Math.floor(avail / charWidthAtBase()));
  }
  // Rows are kept STABLE (computed once / on rotation) — NOT tied to live
  // viewport height, so opening the keyboard doesn't churn the window height
  // (the rows-war). Height is handled client-side by scrolling.
  let stableRows = 0;
  function computeRows() {
    if (!screen.clientHeight) return 40;
    const lh = parseFloat(getComputedStyle(screen).lineHeight) || base * 1.25;
    return Math.max(12, Math.min(Math.floor(screen.clientHeight / lh), 60));
  }
  // Claim our client size from tmux (native window-size=latest). Only while the
  // phone is the foreground client, so tmux hands the size to mobile-cc/desktop
  // when they're active. refresh-client is idempotent: same size => tmux no-op,
  // no redraw — so firing on every (debounced) viewport change is cheap.
  let sentRows = 0;
  function requestFit() {
    if (READONLY) return;
    if (!current || document.visibilityState !== 'visible') return;
    const c = desiredCols(); if (!c) return;
    if (!stableRows) stableRows = computeRows();
    // Skip when the pane is already at our width: with TWO clients open at
    // different widths, unconditional claims made every update re-trigger the
    // other client's refit — tmux oscillated between the two sizes and the
    // view "jumped without stop" (user report; leftover emulator tab + phone).
    // Rows changes (layout switch grew/shrank the terminal area) must still go
    // through even at an unchanged width.
    if (c === cols && stableRows === sentRows) return;
    sentRows = stableRows;
    host.send('resize', { cols: c, rows: stableRows });
  }

  // Font-shrink safety net for when the window is genuinely WIDER than the phone
  // (e.g. another client holds the size). NOT triggered by box-drawing/❯ glyphs,
  // which render ~10-15% wider than normal chars per cell — shrinking for those
  // makes normal text under-fill (the right-margin bug). So we tolerate minor
  // overflow (keep the readable base font; the rare wide-glyph line clips a few
  // px) and only shrink on a real width mismatch (>1.3x).
  function fit() {
    if (!screen.clientWidth || !rows.length) return;
    const cs = getComputedStyle(screen);
    const cur = parseFloat(cs.fontSize) || base;
    const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
    const content = screen.scrollWidth - padX; // widest line at current font
    const avail = screen.clientWidth - padX;
    if (content <= avail * 1.3 || content <= 0) return;   // tolerate wide-glyph overflow
    const size = Math.max(5, cur * avail / content);
    screen.style.fontSize = size.toFixed(2) + 'px';
  }
  // Auto-fit on EVERY viewport change: rotation, app-chrome / split-screen,
  // keyboard dismiss (visualViewport), and returning to the app (visibilitychange).
  // Measured after a rAF so layout/fonts are settled. The guards in requestFit()
  // make this safe to fire liberally.
  let fitTimer = null;
  const refit = () => { clearTimeout(fitTimer); fitTimer = setTimeout(() => requestAnimationFrame(() => { requestFit(); fit(); }), 120); };
  window.addEventListener('resize', refit);
  window.addEventListener('orientationchange', () => { stableRows = 0; refit(); }); // recompute rows on rotation
  // Layout switches (layouts plugin) change the terminal's height budget —
  // recompute rows after the new CSS has settled.
  host.bus.on('ui.layout', () => { stableRows = 0; refit(); });
  if (window.visualViewport) window.visualViewport.addEventListener('resize', refit);

  // --- A- / A+ font-size (== column density) control (in the toolbar) ---------
  const mkBtn = (t) => { const b = document.createElement('button'); b.textContent = t; b.tabIndex = -1; b.style.cssText = 'flex:0 0 auto;font:inherit;font-size:12px;min-width:30px;height:26px;padding:0 5px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer'; b.addEventListener('mousedown', (e) => e.preventDefault()); return b; };
  const aMinus = mkBtn('A−'); const aReset = mkBtn('A↺'); const aPlus = mkBtn('A+');
  aReset.title = 'default size';
  const colsLabel = document.createElement('span'); colsLabel.style.cssText = 'flex:0 0 auto;font-size:10px;color:var(--fg);opacity:.6;min-width:36px;text-align:center';
  function setFont(px) {
    base = Math.max(6, Math.min(px, 24));
    host.storage.set('fontPx', base);
    screen.style.fontSize = base + 'px';
    stableRows = 0;                 // rows depend on font height
    colsLabel.textContent = `${desiredCols()} cols`;
    requestFit();                   // claim the new column count (tmux re-wraps)
  }
  aMinus.addEventListener('pointerup', (e) => { e.preventDefault(); setFont(base - 1); }); // smaller font = MORE cols
  aReset.addEventListener('pointerup', (e) => { e.preventDefault(); setFont(DEFAULT_FONT); }); // back to default
  aPlus.addEventListener('pointerup', (e) => { e.preventDefault(); setFont(base + 1); });
  host.mount('toolbar', aMinus); host.mount('toolbar', colsLabel); host.mount('toolbar', aReset); host.mount('toolbar', aPlus);

  // toggle to collapse/show the chips+quick-keys bar (slot-accessory), persisted
  const accToggle = mkBtn('⌨'); accToggle.title = 'show/hide keys & chips';
  function applyAcc() { const hidden = host.storage.get('accHidden'); const el = document.getElementById('slot-accessory'); if (el) el.style.display = hidden ? 'none' : ''; accToggle.style.opacity = hidden ? '0.4' : '1'; }
  accToggle.addEventListener('pointerup', (e) => { e.preventDefault(); host.storage.set('accHidden', !host.storage.get('accHidden')); applyAcc(); });
  host.mount('toolbar', accToggle);
  applyAcc();
  // Returning to the foreground re-claims our size (tmux hands it back from
  // mobile-cc/desktop). Backgrounding does nothing — we simply stop claiming, so
  // whichever client the user switches to becomes active and tmux adopts ITS size.
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') refit(); });
  // re-subscribe + re-fit after a WS reconnect (the backend lost our subscription)
  host.bus.on('shell.connected', () => { if (current) { host.send('sub', { session: current }); refit(); } });

  // generic row-decorator hook: other plugins (e.g. download/linkify) register a
  // fn(rowDiv) run after each row renders. Terminal stays unaware of what they do.
  const decorators = [];
  const decorate = (div) => { for (const d of decorators) { try { d(div); } catch {} } };
  host.bus.on('terminal.addRowDecorator', (fn) => { if (typeof fn === 'function') { decorators.push(fn); rows.forEach(decorate); } });

  // Light theme: ANSI/256 colors in pane content are tuned for dark
  // backgrounds. Port of tmux-web's hue-preserving lightness clamp:
  // foregrounds darkened to L<=.42 (yellows to .28 — pure yellow is ~2.4:1
  // on white even at .36), dark backgrounds lifted to L>=.88.
  let lightMode = false;
  host.bus.on('ui.theme', (p) => {
    const was = lightMode;
    lightMode = !!(p && p.light);
    if (was !== lightMode && current) host.send('sub', { session: current }); // fresh snapshot re-renders
  });
  host.bus.emit('ui.theme.request', {});
  function lightAdjust(css, isBg) {
    const m = /^#([0-9a-f]{6})$/i.exec(css || '');
    if (!m) return css;
    const r = parseInt(m[1].slice(0, 2), 16) / 255, g = parseInt(m[1].slice(2, 4), 16) / 255, b = parseInt(m[1].slice(4, 6), 16) / 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2, d = max - min;
    let h = 0, sN = 0;
    if (d !== 0) {
      sN = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
      else if (max === g) h = ((b - r) / d + 2) / 6;
      else h = ((r - g) / d + 4) / 6;
    }
    let nl = l;
    if (!isBg && l > 0.42) nl = (h > 0.10 && h < 0.22) ? 0.28 : 0.36;
    else if (isBg && l < 0.75) nl = 0.88;
    if (nl === l) return css;
    const hue2 = (pq, qq, t) => {
      if (t < 0) t += 1; if (t > 1) t -= 1;
      if (t < 1 / 6) return pq + (qq - pq) * 6 * t;
      if (t < 1 / 2) return qq;
      if (t < 2 / 3) return pq + (qq - pq) * (2 / 3 - t) * 6;
      return pq;
    };
    let R, G, B;
    if (sN === 0) { R = G = B = nl; }
    else {
      const q = nl < 0.5 ? nl * (1 + sN) : nl + sN - nl * sN;
      const pp = 2 * nl - q;
      R = hue2(pp, q, h + 1 / 3); G = hue2(pp, q, h); B = hue2(pp, q, h - 1 / 3);
    }
    const to = (v) => Math.round(v * 255).toString(16).padStart(2, '0');
    return '#' + to(R) + to(G) + to(B);
  }
  // Symbol glyphs (spinner ✻✽✢, arrows, geometric shapes, dingbats) render at
  // font-dependent widths that rarely equal one monospace cell — Claude Code's
  // thinking spinner cycles through them, shifting the whole status line left/
  // right every frame (user report; tmux-web fixed the same bug by pinning
  // such glyphs to 1ch inline-blocks). Pin them to the cell grid. BMP-only
  // ranges — emoji (surrogate pairs, cell-width 2) are deliberately untouched.
  const GLYPH_RE = /[–-⯿]/;
  const glyphStyle = document.createElement('style');
  glyphStyle.textContent = '.tg1{display:inline-block;width:1ch;overflow:hidden;vertical-align:bottom}';
  document.head.appendChild(glyphStyle);
  function appendText(el, text) {
    if (!GLYPH_RE.test(text)) { el.appendChild(document.createTextNode(text)); return; }
    let plain = '';
    for (const ch of text) {
      if (GLYPH_RE.test(ch)) {
        if (plain) { el.appendChild(document.createTextNode(plain)); plain = ''; }
        const g = document.createElement('span');
        g.className = 'tg1';
        g.textContent = ch;
        el.appendChild(g);
      } else plain += ch;
    }
    if (plain) el.appendChild(document.createTextNode(plain));
  }
  function renderRow(div, spans) {
    div.textContent = '';
    if (!spans || !spans.length) { div.appendChild(document.createTextNode('')); return; }
    for (const s of spans) {
      const el = document.createElement('span');
      appendText(el, s.t);
      let fg = s.f || null, bg = s.b || null;
      if (lightMode) { if (fg) fg = lightAdjust(fg, false); if (bg) bg = lightAdjust(bg, true); }
      if (s.o & 2) { const nf = bg || 'var(--bg)'; const nb = fg || 'var(--fg)'; fg = nf; bg = nb; } // inverse
      if (fg) el.style.color = fg;
      if (bg) el.style.background = bg;
      if (s.o & 1) el.style.fontWeight = 'bold';
      if (s.o & 4) el.style.textDecoration = 'underline';
      if (s.o & 8) el.style.opacity = '0.6';
      div.appendChild(el);
    }
  }
  function setRow(i, spans) {
    if (i < rows.length) { renderRow(rows[i], spans); decorate(rows[i]); }
    else { const d = document.createElement('div'); d.style.whiteSpace = 'pre'; d.style.minHeight = '1em'; renderRow(d, spans); screen.appendChild(d); rows.push(d); decorate(d); }
  }
  function applyFrom(pre, newRows) {
    const follow = atBottom();
    for (let i = 0; i < newRows.length; i++) setRow(pre + i, newRows[i]);
    const total = pre + newRows.length;
    while (rows.length > total) rows.pop().remove();
    if (follow) screen.scrollTop = screen.scrollHeight;
  }

  // Presence: surface who's typing to other plugins (header shows it).
  host.on('typing', (p) => host.bus.emit('terminal.typing', p));

  host.on('snapshot', (p) => {
    if (p.session !== current) return;
    cols = p.cols || cols;
    colsLabel.textContent = `${cols} cols`;
    screen.style.fontSize = base + 'px';   // reset so a narrower session enlarges
    rows.splice(0).forEach((r) => r.remove());
    applyFrom(0, p.rows);
    fit();                                  // then shrink to fit the widest line
    screen.scrollTop = screen.scrollHeight;
  });
  host.on('update', (p) => { if (p.session === current) { applyFrom(p.pre, p.rows); fit(); } });
  host.on('sessions', (p) => host.bus.emit('terminal.sessions', p.sessions));
  host.on('states', (p) => host.bus.emit('terminal.states', p.states));

  function switchTo(session) {
    if (session === current) return;
    current = session;
    rows.splice(0).forEach((r) => r.remove());
    host.send('sub', { session });
    requestFit();                            // fit-resize the window to the phone width
    host.storage.set('active', session);
    host.bus.emit('terminal.active', { session });
  }
  host.bus.on('terminal.switch', ({ session }) => switchTo(session));
  host.bus.on('terminal.input', (payload) => host.send('input', payload)); // {data} or {key}
  host.bus.on('terminal.insertText', ({ text }) => { input.value += text; input.focus(); });
  host.bus.on('terminal.requestSessions', () => host.send('list', {}));
  host.bus.on('terminal.createSession', (p) => host.send('create', p));
  host.bus.on('terminal.renameSession', (p) => host.send('rename', p));
  host.bus.on('terminal.killSession', (p) => host.send('kill', p));
  // switch to a freshly created session when the list refreshes to include it
  host.bus.on('terminal.switchWhenReady', ({ session }) => { pendingSwitch = session; });

  // --- omni (ask) integration: advertise actions the omnibox can invoke -------
  // Closures capture live state; re-announced on omni.collect so the registry is
  // always fresh (survives hot-reload). The terminal is the natural owner of
  // session/agent navigation + the density control.
  const omniActions = [
    { id: 'terminal.switch', title: 'Switch to a session/agent', hint: 'jump to a tab by name', args: [{ name: 'session', desc: 'session name' }], mutates: false, run: (a) => switchTo(a.session) },
    { id: 'terminal.send', title: 'Send a line to the active agent', hint: 'types text + Enter into the current agent', args: [{ name: 'text' }], mutates: false, run: (a) => { host.send('input', { data: String(a.text || '') }); host.send('input', { data: '\r' }); } },
    { id: 'terminal.insert', title: 'Put text in the input box (not sent)', args: [{ name: 'text' }], mutates: false, run: (a) => { input.value += String(a.text || ''); input.focus(); } },
    { id: 'terminal.new', title: 'Start a new agent/session', hint: 'creates a tmux session (Claude by default)', args: [{ name: 'name' }, { name: 'cc', desc: 'true=Claude, false=plain shell' }, { name: 'cwd', desc: 'optional working dir' }], mutates: true, run: (a) => { host.send('create', { name: a.name, cc: a.cc !== false, cwd: a.cwd }); pendingSwitch = a.name; } },
    { id: 'terminal.font', title: 'Change font size / column density', hint: 'delta:+/-N, or reset:true, or px:N', args: [{ name: 'delta' }, { name: 'reset' }, { name: 'px' }], mutates: false, run: (a) => { if (a.reset) setFont(DEFAULT_FONT); else if (a.px) setFont(Number(a.px)); else setFont(base + (Number(a.delta) || 0)); } },
    { id: 'terminal.kill', title: 'Kill a session', args: [{ name: 'session' }], mutates: true, run: (a) => host.send('kill', { session: a.session }) },
    { id: 'terminal.rename', title: 'Rename a session', args: [{ name: 'session' }, { name: 'name' }], mutates: true, run: (a) => host.send('rename', { session: a.session, name: a.name }) },
  ];
  const announceOmni = () => omniActions.forEach((x) => host.bus.emit('omni.action', x));
  host.bus.on('omni.collect', announceOmni);
  announceOmni();

  function doSend() {
    if (input.value) { host.send('input', { data: input.value }); host.send('input', { data: '\r' }); input.value = ''; }
    else host.send('input', { data: '\r' });
  }
  send.onclick = doSend;
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); doSend(); } });

  // boot: get the session list, open the last-active (or first) one
  // deep link from a push notification tap: ?session=NAME wins on first load
  const deepLink = new URLSearchParams(location.search).get('session');
  if (deepLink) pendingSwitch = deepLink;

  host.send('list', {});
  host.on('sessions', (p) => {
    if (pendingSwitch && p.sessions.some((s) => s.session === pendingSwitch)) { const t = pendingSwitch; pendingSwitch = null; switchTo(t); return; }
    // The viewed session can DIE under us (e.g. the process a tmux session was
    // created around exits). Without this, the view froze on the last frame
    // and input went to a dead pane (user report: Ctrl-C'd out of claude,
    // session ended, nothing submitted). Jump to a surviving session.
    if (current && p.sessions.length && !p.sessions.some((s) => s.session === current)) {
      const gone = current; current = null;
      switchTo(p.sessions[0].session);
      host.bus.emit('toast', { text: `session '${gone}' ended` });
      return;
    }
    if (current || !p.sessions.length) return;
    const saved = host.storage.get('active');
    const pick = p.sessions.find((s) => s.session === saved) || p.sessions[0];
    switchTo(pick.session);
  });
}
