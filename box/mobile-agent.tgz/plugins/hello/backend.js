// Smallest possible full-stack plugin: proves route + ws handler + broadcast.
module.exports = function setup(ctx) {
  let count = ctx.storage.get('count') || 0;
  ctx.route('count', (req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ count }));
  });
  ctx.on('ping', (payload, client) => {
    count += 1;
    ctx.storage.set('count', count);
    ctx.broadcast('pong', { count, echo: payload });
  });
  ctx.log('HOT-RELOADED, count=', count);
};
