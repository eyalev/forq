export default function init(host) {
  const el = document.createElement('div');
  el.style.cssText = 'padding:8px;font-size:13px;border-bottom:1px solid var(--border)';
  const btn = document.createElement('button');
  btn.textContent = 'ping';
  const out = document.createElement('span');
  out.style.marginLeft = '8px';
  el.append(btn, out);
  host.mount('header', el);
  host.on('pong', (p) => { out.textContent = `pong #${p.count}`; });
  btn.onclick = () => host.send('ping', { at: Date.now() });
  host.api('count').then((r) => r.json()).then((d) => { out.textContent = `count ${d.count}`; });
}
