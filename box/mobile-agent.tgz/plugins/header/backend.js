// Header plugin — backend. Just hands the frontend its config (app name +
// optional home URL); everything visual lives client-side.
module.exports = function setup(ctx) {
  const cfg = ctx.config || {};
  ctx.route('config', (req, res) => {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ name: cfg.name || 'mobile-agent', homeUrl: cfg.homeUrl || '', switcherUrl: cfg.switcherUrl || '' }));
  });
  return () => {};
};
