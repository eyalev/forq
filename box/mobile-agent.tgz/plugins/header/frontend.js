// Header — one slim row of orientation: [⌂ home] name › active-session,
// connection dot (live/reconnecting), and 🔗 copy-deep-link for the active
// session. Phone-first: 34px tall, never wraps.
export default function init(host) {
  const bar = document.createElement('div');
  bar.style.cssText = 'display:flex;align-items:center;gap:8px;height:34px;padding:0 10px;background:var(--chrome);border-bottom:1px solid var(--border);font:13px system-ui,sans-serif;color:var(--fg)';

  const home = document.createElement('a');
  home.textContent = '⌂';
  home.style.cssText = 'display:none;flex:0 0 auto;font-size:16px;color:var(--muted);text-decoration:none;padding:2px 4px';
  home.title = 'dashboard';

  const title = document.createElement('div');
  title.style.cssText = 'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:flex;align-items:baseline;gap:6px';
  const name = document.createElement('span');
  name.style.cssText = 'font-weight:600';
  const sess = document.createElement('span');
  sess.style.cssText = 'color:var(--muted);font-size:12px';
  // Infra chip: which infrastructure runs this computer (matches the
  // dashboard's pill language — bolt/db/server glyphs, provider colors).
  const infra = document.createElement('span');
  infra.style.cssText = 'display:none;flex:0 0 auto;align-items:center;gap:3px;font-size:9.5px;letter-spacing:.2px;padding:1px 6px;border-radius:8px;border:1px solid var(--border);color:var(--muted);align-self:center';
  title.append(name, infra, sess);

  const INFRA = {
    cfbox: ['#f6821f', '<path d="M13 3 5.5 13.5H11L10 21l7.5-10.5H12L13 3z"/>', 'CF sandbox'],
    computer: ['#e3b341', '<ellipse cx="12" cy="6" rx="7" ry="2.6"/><path d="M5 6v12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V6"/><path d="M5 12c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6"/>', 'CF computer'],
    gcp: ['#8ab4f8', '<rect x="4" y="4" width="16" height="7" rx="1.6"/><rect x="4" y="13" width="16" height="7" rx="1.6"/><path d="M7.4 7.5h.01M7.4 16.5h.01"/>', 'GCP VM'],
  };
  const glyph = (t, size) => {
    const m = INFRA[t];
    return m ? `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${m[0]}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-1.5px">${m[1]}</svg>` : '';
  };
  const showInfra = (t) => {
    const m = INFRA[t];
    if (!m) return;
    infra.innerHTML = `${glyph(t, 10)}<span style="color:${m[0]}">${m[2]}</span>`;
    infra.style.display = 'inline-flex';
  };

  // Presence: viewer count when >1 (tap/hover for names) + a transient
  // "<name> is typing" hint when ANOTHER client sends input.
  const who = document.createElement('span');
  who.style.cssText = 'display:none;flex:0 0 auto;align-items:center;gap:3px;font-size:10.5px;color:#7ee787;border:1px solid #2a4a35;border-radius:9px;padding:1px 7px';
  const typing = document.createElement('span');
  typing.style.cssText = 'display:none;flex:0 0 auto;font-size:10.5px;color:var(--muted);font-style:italic;max-width:32vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
  const shortName = (u) => (u || 'someone').split('@')[0];
  // Read-only viewers never see presence or typing attribution — a shared
  // demo link should feel like a private window into the session, not a
  // crowded room (and viewer counts would leak how many people opened it).
  const RO = new URLSearchParams(location.search).has('view');
  host.bus.on('shell.presence', (p) => {
    const n = (p && p.count) || 0;
    if (!RO && n > 1) {
      who.innerHTML = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="8.5" cy="8" r="3"/><circle cx="16" cy="9.5" r="2.4"/><path d="M3 19c.7-3 2.6-4.5 5.5-4.5S13.3 16 14 19"/><path d="M15.5 14.8c2.3.2 3.9 1.5 4.5 4.2"/></svg>${n}`;
      who.title = 'Connected: ' + (p.users || []).map(shortName).join(', ');
      who.style.display = 'inline-flex';
    } else {
      who.style.display = 'none';
    }
  });
  let typingTimer = null;
  host.bus.on('terminal.typing', (p) => {
    if (RO) return;
    const u = p && p.user;
    if (!u || (window.__ME && u === window.__ME)) return; // own keystrokes aren't news
    typing.textContent = shortName(u) + ' is typing…';
    typing.style.display = 'inline';
    clearTimeout(typingTimer);
    typingTimer = setTimeout(() => { typing.style.display = 'none'; }, 2500);
  });

  const dot = document.createElement('span');
  dot.style.cssText = 'flex:0 0 auto;width:8px;height:8px;border-radius:50%;background:#666';
  dot.title = 'connecting…';

  const link = document.createElement('button');
  link.textContent = '🔗';
  link.title = 'copy link to this session';
  link.tabIndex = -1;
  link.style.cssText = 'flex:0 0 auto;background:transparent;border:0;font-size:13px;cursor:pointer;padding:2px 4px;opacity:.7';

  bar.append(home, title, typing, who, dot, link);
  host.mount('header', bar);

  // Switch-computer strip: when the host app provides a switcher endpoint
  // (JSON [{name, url}], same-origin), render one row of chips under the
  // header. Generic — the endpoint shape is the whole contract.
  const strip = document.createElement('div');
  strip.style.cssText = 'display:none;gap:6px;align-items:center;padding:5px 10px 7px;background:var(--chrome);border-bottom:1px solid var(--border);overflow-x:auto;scrollbar-width:none';
  host.mount('header', strip);
  // Same-origin nav history (sessionStorage survives across terminal pages):
  // lets A↔B switches go through history.back() so bfcache can restore the
  // previous computer instantly instead of a cold reload. Graceful — a
  // bfcache miss just loads normally.
  const NAVKEY = 'compNavStack';
  try {
    const st = JSON.parse(sessionStorage.getItem(NAVKEY) || '[]');
    if (st[st.length - 1] !== location.pathname) st.push(location.pathname);
    sessionStorage.setItem(NAVKEY, JSON.stringify(st.slice(-10)));
  } catch { /* private mode */ }

  async function loadSwitcher(url) {
    try {
      const list = await (await fetch(url)).json();
      if (!Array.isArray(list) || !list.length) return;
      strip.style.display = 'flex';
      strip.textContent = '';
      for (const c of list) {
        const b = document.createElement('button');
        // `starred` is an optional display hint from the host endpoint: the
        // list already arrives favourites-first, the star just says why.
        const fav = c.starred
          ? '<svg viewBox="0 0 24 24" width="10" height="10" fill="#f0c040" stroke="none" style="vertical-align:-1px"><path d="M12 3.6l2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8L3.5 9.8l5.9-.9L12 3.6z"/></svg> '
          : '';
        b.innerHTML = fav + (c.type ? glyph(c.type, 11) + ' ' : '') + c.name;
        // Exact match for the root computer: EVERY pathname startsWith('/'), so
        // a prefix test marked the laptop chip "current" on every remote page —
        // which also made it non-clickable, stranding you on the cloud computer
        // with no chip back home.
        const cur = c.url === '/' ? location.pathname === '/' : location.pathname.startsWith(c.url);
        if (cur && c.type) showInfra(c.type);
        b.style.cssText = `flex:0 0 auto;font:12.5px system-ui;padding:4px 12px;border-radius:6px;cursor:pointer;white-space:nowrap;border:1px solid ${cur ? 'var(--accent)' : 'var(--border)'};background:${cur ? 'var(--bg)' : 'transparent'};color:${cur ? 'var(--accent)' : 'var(--muted)'}`;
        if (!cur) b.onclick = () => {
          let prev = null;
          try { const st = JSON.parse(sessionStorage.getItem(NAVKEY) || '[]'); prev = st[st.length - 2]; } catch {}
          if (prev && prev.startsWith(c.url)) {
            try { const st = JSON.parse(sessionStorage.getItem(NAVKEY) || '[]'); st.pop(); sessionStorage.setItem(NAVKEY, JSON.stringify(st)); } catch {}
            history.back();
          } else {
            location.href = c.url;
          }
        };
        strip.appendChild(b);
      }
    } catch { /* endpoint absent (e.g. served from the raw preview host) — no strip */ }
  }

  let active = '';
  host.api('config').then((r) => r.json()).then((c) => {
    name.textContent = c.name || 'mobile-agent';
    if (c.homeUrl) { home.href = c.homeUrl; home.style.display = 'block'; }
    if (c.switcherUrl) loadSwitcher(c.switcherUrl);
  }).catch(() => { name.textContent = 'mobile-agent'; });

  host.bus.on('terminal.active', ({ session }) => { active = session || ''; sess.textContent = active ? '› ' + active : ''; });
  // terminal.states flows every ~2s while the WS is up — liveness signal that
  // also covers the case where shell.connected fired before this plugin loaded.
  const live = () => { dot.style.background = 'var(--ok, #4ade80)'; dot.title = 'live'; };
  host.bus.on('shell.connected', live);
  host.bus.on('terminal.states', live);
  host.bus.on('shell.disconnected', () => { dot.style.background = '#f87171'; dot.title = 'reconnecting…'; });

  link.onclick = () => {
    const base = (window.__APP_BASE && window.__APP_BASE !== '/') ? window.__APP_BASE : '/';
    const url = location.origin + base + (active ? '?session=' + encodeURIComponent(active) : '');
    navigator.clipboard.writeText(url).then(() => { link.textContent = '✓'; setTimeout(() => (link.textContent = '🔗'), 1200); })
      .catch(() => prompt('Session link', url));
  };
}
