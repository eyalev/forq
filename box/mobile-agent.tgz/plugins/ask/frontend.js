// Omni (ask / do anything) — one input that routes to: an app ACTION, the active
// agent, a "build a plugin" agent hand-off, or an answer. The action menu is
// collected LIVE from every plugin over the bus (omni.action), so the box is
// self-describing: add a plugin that announces actions and it's instantly
// reachable by language. Multiple router PROFILES can be kept and compared.
//
//  Tier 0  local match (regex/fuzzy)  -> instant, free
//  Tier 1  LLM router (active profile) -> picks a lane
//  Balanced autonomy: nav/agent/appearance run instantly; structural changes
//  (build a plugin, toggle/kill/revert) show a confirm card + checkpoint first.
export default function init(host) {
  // ---- live action registry (collected from plugins via the bus) ------------
  let registry = new Map();                 // id -> {id,title,hint,args,mutates,run}
  host.bus.on('omni.action', (a) => { if (a && a.id) registry.set(a.id, a); });
  function collect() { registry = new Map(); host.bus.emit('omni.collect'); return registry; }

  // ---- ambient context: sessions + active session (for switch/send targets) --
  let sessions = [];                        // [{session,...}]
  let current = null;
  host.bus.on('terminal.sessions', (list) => { sessions = list || []; });
  host.bus.on('terminal.active', ({ session }) => { current = session; });
  host.bus.emit('terminal.requestSessions');

  const post = (sub, b) => host.api(sub, { method: 'POST', body: JSON.stringify(b || {}), headers: { 'content-type': 'application/json' } }).then((r) => r.json());
  const get = (sub) => host.api(sub).then((r) => r.json());
  const MUT = new Set();                    // action ids that need confirm (computed per-open)

  // ---- recents (per-origin; most-recent-first, deduped, capped) --------------
  const recentsGet = () => { const r = host.storage.get('recents'); return Array.isArray(r) ? r : []; };
  const recentsAdd = (t) => { let r = recentsGet().filter((x) => x !== t); r.unshift(t); host.storage.set('recents', r.slice(0, 12)); };

  // ---- interaction logging (JSONL on the daemon; harness/evals read it) ------
  const newId = () => 'o' + Date.now().toString(36) + Math.floor(performance.now() * 1000 % 1e6).toString(36);
  const logEvent = (rec) => { try { host.api('log', { method: 'POST', body: JSON.stringify(rec), headers: { 'content-type': 'application/json' } }); } catch (_) {} };

  // ---- toolbar button --------------------------------------------------------
  const btn = document.createElement('button');
  btn.textContent = '✦'; btn.title = 'ask / do anything';
  btn.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer';
  btn.tabIndex = -1;
  host.mount('toolbar', btn);
  btn.onclick = () => openSheet();

  // ---- small UI helpers ------------------------------------------------------
  const el = (tag, css, txt) => { const e = document.createElement(tag); if (css) e.style.cssText = css; if (txt != null) e.textContent = txt; return e; };
  const mkBtn = (t, primary) => el('button', `font:inherit;font-size:11px;padding:3px 8px;border-radius:4px;cursor:pointer;border:1px solid ${primary ? 'var(--accent)' : 'var(--border)'};background:${primary ? 'var(--accent)' : 'transparent'};color:${primary ? 'var(--accent-fg)' : 'var(--fg)'}`, t);
  // Bottom sheet — leaves the terminal/toolbar visible above so theme/font/toggle
  // effects are seen live while you command the app (and no dead whitespace).
  function sheet(title) {
    const back = el('div', 'position:fixed;inset:0;z-index:320;background:rgba(0,0,0,.35);display:flex;flex-direction:column;justify-content:flex-end');
    const panel = el('div', 'background:var(--chrome);border-top:1px solid var(--border);border-radius:16px 16px 0 0;display:flex;flex-direction:column;max-height:74vh;box-shadow:0 -8px 28px rgba(0,0,0,.45)');
    const head = el('div', 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;border-bottom:1px solid var(--border);flex:0 0 auto');
    const h = el('div', 'font-size:15px;font-weight:bold;color:var(--fg)', title);
    const x = el('button', 'font-size:13px;width:28px;height:28px;border-radius:4px;border:1px solid var(--border);background:transparent;color:var(--fg)', '✕');
    x.onclick = () => back.remove();
    head.append(h, x);
    const bodyEl = el('div', 'overflow-y:auto;padding:14px 16px 22px;display:flex;flex-direction:column;gap:14px');
    panel.append(head, bodyEl); back.append(panel);
    back.onclick = (e) => { if (e.target === back) back.remove(); };   // tap the dimmed area to dismiss
    document.body.appendChild(back);
    return { back, bodyEl, head };
  }

  // ---- Tier 0: instant local matcher (returns a decision or null) ------------
  function localMatch(text) {
    const t = text.trim().toLowerCase();
    let m;
    if ((m = t.match(/^(?:use |switch to |set )?(dark|light)(?: theme| mode)?$/))) return { kind: 'action', action: 'theme.set', args: { name: m[1] }, say: `Switch to ${m[1]} theme` };
    if (/\b(bigger|larger|increase).*(font|text|size)|\b(font|text).*(bigger|larger)|zoom in\b/.test(t)) return { kind: 'action', action: 'terminal.font', args: { delta: 2 }, say: 'Increase font size' };
    if (/\b(smaller|decrease|reduce).*(font|text|size)|\b(font|text).*(smaller)|zoom out\b/.test(t)) return { kind: 'action', action: 'terminal.font', args: { delta: -2 }, say: 'Decrease font size' };
    if (/\b(reset|default).*(font|size|text)|\bfont.*(reset|default)/.test(t)) return { kind: 'action', action: 'terminal.font', args: { reset: true }, say: 'Reset font size' };
    if (/^(open )?(customize|studio|settings panel)$/.test(t)) return { kind: 'action', action: 'studio.open', args: {}, say: 'Open the Customize panel' };
    if (/^(checkpoint|save state|save checkpoint)( now)?$/.test(t)) return { kind: 'action', action: 'studio.checkpoint', args: {}, say: 'Save a checkpoint' };
    if ((m = t.match(/^(?:go to|switch to|open|show)\s+(.+)$/))) {
      const hit = sessions.find((s) => s.session.toLowerCase() === m[1]) || sessions.find((s) => s.session.toLowerCase().includes(m[1]));
      if (hit) return { kind: 'action', action: 'terminal.switch', args: { session: hit.session }, say: `Switch to ${hit.session}` };
    }
    if ((m = t.match(/^new (?:agent|session|claude)(?:\s+(?:called|named)?\s*([\w-]+))?$/))) return { kind: 'action', action: 'terminal.new', args: { name: m[1] || 'agent', cc: true }, say: `Start a new agent${m[1] ? ' "' + m[1] + '"' : ''}` };
    return null;
  }

  // ---- the unified executor (same path for Tier-0 and LLM decisions) ---------
  function isMutation(dec) {
    if (dec.kind === 'build') return true;
    if (dec.kind === 'action') { const a = registry.get(dec.action); return a ? !!a.mutates : MUT.has(dec.action); }
    return false;
  }
  // 👍/👎/✎ on a result — labels whether the omnibox did the right thing. These
  // become eval cases (the harness mines ev:'feedback' from the log).
  function feedbackRow(box, dec) {
    const row = el('div', 'display:flex;gap:6px;align-items:center;margin-top:6px;flex-wrap:wrap');
    row.append(el('div', 'font-size:11px;color:#777', 'right?'));
    const fbCss = 'font:inherit;font-size:13px;width:34px;height:28px;border-radius:7px;border:1px solid var(--border);background:transparent;color:var(--fg);cursor:pointer';
    const base = () => ({ id: dec._id, input: dec._input, tier: dec._tier, kind: dec.kind, action: dec.action, args: dec.args });
    const done = (msg) => { row.innerHTML = ''; row.append(el('div', 'font-size:11px;color:var(--accent)', msg)); };
    const up = el('button', fbCss, '👍'); up.onclick = () => { logEvent(Object.assign({ ev: 'feedback', verdict: 'up' }, base())); done('thanks ✓'); };
    const down = el('button', fbCss, '👎'); down.onclick = () => { logEvent(Object.assign({ ev: 'feedback', verdict: 'down' }, base())); done('logged ✓ — helps the evals'); };
    const fix = el('button', fbCss + ';width:auto;padding:0 10px', '✎ fix'); fix.onclick = () => {
      row.innerHTML = '';
      const inp = el('input', 'flex:1;min-width:140px;font:inherit;font-size:12px;padding:6px 8px;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg)');
      inp.placeholder = 'what should it have done?';
      const sv = el('button', fbCss + ';width:auto;padding:0 10px', 'save');
      sv.onclick = () => { logEvent(Object.assign({ ev: 'feedback', verdict: 'down', expected: inp.value.trim() }, base())); done('logged ✓'); };
      row.append(inp, sv); inp.focus();
    };
    row.append(up, down, fix); box.append(row);
  }
  async function execute(dec, resultBox) {
    const show = (msg, color, fb) => { resultBox.innerHTML = ''; resultBox.append(el('div', `font-size:13px;color:${color || 'var(--fg)'}`, msg)); if (fb && dec._id) feedbackRow(resultBox, dec); };
    const logApplied = (outcome, extra) => logEvent(Object.assign({ ev: 'applied', id: dec._id, input: dec._input, kind: dec.kind, action: dec.action, outcome }, extra || {}));
    if (dec.kind === 'error') {
      const rl = /\b429\b|rate limit/i.test(dec.error || '');
      show(rl ? 'Rate-limited by the provider — try again or switch profile.' : (dec.say || dec.error || 'error'), '#e57373');
      if (dec.error === 'no_key') { const b = mkBtn('Set up a profile', true); b.style.marginTop = '8px'; b.onclick = () => manageProfiles(); resultBox.append(b); }
      return;
    }
    if (dec.kind === 'answer') { logApplied('ok'); return show(dec.text || dec.say || '(no answer)', null, true); }
    if (dec.kind === 'clarify') { logApplied('clarify'); return show('❓ ' + (dec.text || dec.say || 'Can you clarify?'), '#e6b450', true); }
    if (dec.kind === 'agent') { host.bus.emit('terminal.input', { data: String(dec.text || '') }); host.bus.emit('terminal.input', { data: '\r' }); logApplied('ok'); return show(`➤ sent to ${current || 'the active agent'}: “${dec.text}”`, 'var(--accent)', true); }
    if (dec.kind === 'build') return show('(build handled via confirm)');
    if (dec.kind === 'action') {
      const a = registry.get(dec.action);
      if (!a) { logApplied('error', { error: 'unknown_action' }); return show(`Unknown action: ${dec.action}`, '#e57373', true); }
      try { await a.run(dec.args || {}); logApplied('ok'); show(`✓ ${dec.say || a.title}`, 'var(--accent)', true); }
      catch (e) { logApplied('error', { error: e.message }); show(`Action failed: ${e.message}`, '#e57373', true); }
    }
  }
  // confirm card for structural changes; checkpoints first (studio listens)
  function confirmThen(dec, resultBox, run) {
    resultBox.innerHTML = '';
    const card = el('div', 'border:1px solid var(--accent);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:10px');
    card.append(el('div', 'font-size:11px;text-transform:uppercase;letter-spacing:.05em;color:#888', 'about to'));
    card.append(el('div', 'font-size:14px;color:var(--fg)', dec.say || 'apply change'));
    if (dec.kind === 'build') card.append(el('div', 'font-size:12px;color:#999;white-space:pre-wrap;max-height:120px;overflow:auto;border-left:2px solid var(--border);padding-left:8px', dec.text || ''));
    const row = el('div', 'display:flex;gap:8px');
    const ok = mkBtn('Do it', true); const no = mkBtn('Cancel');
    no.onclick = () => { logEvent({ ev: 'cancelled', id: dec._id, input: dec._input, kind: dec.kind, action: dec.action }); resultBox.innerHTML = ''; };
    ok.onclick = async () => {
      logEvent({ ev: 'confirm', id: dec._id, input: dec._input, kind: dec.kind, action: dec.action });
      host.send('checkpoint', { label: dec.say || 'omni change' });    // snapshot first
      resultBox.innerHTML = ''; resultBox.append(el('div', 'font-size:12px;color:#888', '✓ checkpoint saved · applying…'));
      await run();
    };
    row.append(ok, no); card.append(el('div', 'font-size:11px;color:#777', '✓ a checkpoint is saved first — revert from 🛠 if needed'), row);
    resultBox.append(card);
  }
  const hostCheckpoint = (label) => host.send('checkpoint', { label: label || 'omni change' });
  function buildRun(dec, resultBox) {
    return async () => {
      const { userPlugins } = await get('info');
      host.bus.emit('terminal.createSession', { name: 'app-studio', cc: true, cwd: userPlugins });
      host.bus.emit('terminal.switchWhenReady', { session: 'app-studio' });
      host.bus.emit('terminal.insertText', { text: dec.text || '' });
      resultBox.innerHTML = '';
      resultBox.append(el('div', 'font-size:13px;color:var(--accent)', '🤖 opened the app-studio agent with your spec — review it in that tab and press ⏎ to send. The new plugin hot-loads when it writes.'));
    };
  }
  // Autonomy decides how much to confirm. Comes from the routing profile (LLM
  // lanes) or the active profile (Tier-0). balanced=confirm structural changes;
  // auto=just do it (still checkpoints mutations); plan=confirm everything.
  async function handle(dec, resultBox, autonomy) {
    autonomy = autonomy || (dec.profile && dec.profile.autonomy) || 'balanced';
    if (dec.kind === 'build') {
      const run = buildRun(dec, resultBox);
      if (autonomy === 'auto') { hostCheckpoint(dec.say); return run(); }
      return confirmThen(dec, resultBox, run);
    }
    if (dec.kind === 'action') {
      const mut = isMutation(dec);
      const run = () => execute(dec, resultBox);
      if (autonomy === 'plan') return confirmThen(dec, resultBox, run);
      if (autonomy === 'auto') { if (mut) hostCheckpoint(dec.say); return run(); }
      if (mut) return confirmThen(dec, resultBox, run);   // balanced
      return run();
    }
    if (dec.kind === 'agent') {
      if (autonomy === 'plan') return confirmThen(dec, resultBox, () => execute(dec, resultBox));
      return execute(dec, resultBox);
    }
    return execute(dec, resultBox);   // answer / clarify / error
  }

  // ---- the main sheet --------------------------------------------------------
  async function openSheet() {
    collect();                                                   // refresh action menu (fresh closures)
    for (const a of registry.values()) if (a.mutates) MUT.add(a.id);
    const { back, bodyEl } = sheet('Ask / do anything');
    const inst = await (await fetch((window.__APP_BASE === '/' ? '' : window.__APP_BASE.slice(0, -1)) + '/api/instance')).json();
    const pluginIds = (inst.plugins || []).map((p) => p.id);

    // profile bar
    const profBar = el('div', 'display:flex;align-items:center;gap:8px;flex-wrap:wrap');
    const sel = el('select', 'flex:1;min-width:140px;font:inherit;font-size:13px;padding:7px 8px;border-radius:8px;border:1px solid var(--border);background:var(--chrome);color:var(--fg)');
    const gear = mkBtn('⚙'); gear.title = 'manage profiles'; gear.style.width = '40px';
    const cmpWrap = el('label', 'display:flex;align-items:center;gap:5px;font-size:12px;color:#999');
    const cmp = el('input'); cmp.type = 'checkbox';
    cmpWrap.append(cmp, document.createTextNode('compare'));
    const AUT = { balanced: '⚖ balanced', auto: '⚡ auto', plan: '📋 plan' };
    const autBtn = mkBtn('⚖ balanced'); autBtn.title = 'autonomy for this profile (tap to cycle: balanced → auto → plan)'; autBtn.style.fontSize = '11px';
    profBar.append(sel, cmpWrap, autBtn, gear);
    let profiles = { profiles: [], activeId: null };
    const activeProfile = () => (profiles.profiles || []).find((p) => p.id === sel.value) || (profiles.profiles || [])[0] || {};
    const activeAutonomy = () => activeProfile().autonomy || 'balanced';
    const refreshAut = () => { autBtn.textContent = AUT[activeAutonomy()] || ('⚖ ' + activeAutonomy()); };
    autBtn.onclick = async () => {
      const order = ['balanced', 'auto', 'plan']; const p = activeProfile(); if (!p.id) return;
      const next = order[(order.indexOf(activeAutonomy()) + 1) % order.length];
      p.autonomy = next; refreshAut();
      await post('setautonomy', { id: p.id, autonomy: next });
    };
    async function loadProfiles() {
      profiles = await get('profiles');
      sel.innerHTML = '';
      for (const p of profiles.profiles) { const o = el('option'); o.value = p.id; o.textContent = p.name + (p.hasKey ? '' : ' (no key)'); if (p.id === profiles.activeId) o.selected = true; sel.appendChild(o); }
      refreshAut();
    }
    sel.onchange = () => { post('setactive', { id: sel.value }); refreshAut(); };
    gear.onclick = () => manageProfiles(loadProfiles);
    await loadProfiles();

    // input
    const ta = el('textarea', 'width:100%;box-sizing:border-box;min-height:64px;font:inherit;font-size:15px;padding:11px;border-radius:10px;border:1px solid var(--accent);background:var(--bg);color:var(--fg);resize:vertical');
    ta.placeholder = 'e.g. "switch to claude2" · "run the tests" · "add a deploy button" · "light theme"';
    const goRow = el('div', 'display:flex;gap:8px;align-items:center');
    const go = mkBtn('Go ▸', true); go.style.flex = '0 0 auto';
    const status = el('div', 'font-size:11px;color:#888;flex:1');
    // voice dictation into the box (Web Speech; absent on browsers without it)
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    let mic = null;
    if (SR) {
      mic = mkBtn('🎤'); mic.title = 'dictate'; mic.style.flex = '0 0 auto'; mic.style.width = '44px';
      let rec = null, listening = false, baseText = '';
      const stopMic = () => { if (rec) { try { rec.stop(); } catch {} } listening = false; mic.textContent = '🎤'; mic.style.background = 'transparent'; mic.style.color = 'var(--fg)'; };
      const startMic = () => {
        rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.interimResults = true; rec.continuous = false;
        baseText = ta.value ? ta.value.trim() + ' ' : ''; let finalText = '';
        rec.onresult = (e) => { let interim = ''; for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) finalText += t; else interim += t; } ta.value = baseText + finalText + interim; };
        rec.onerror = () => stopMic();
        rec.onend = () => { ta.value = (baseText + finalText).trim(); ta.focus(); stopMic(); };
        listening = true; mic.textContent = '🔴'; mic.style.background = '#c0392b'; mic.style.color = '#fff';
        try { rec.start(); } catch { stopMic(); }
      };
      mic.addEventListener('mousedown', (e) => e.preventDefault());
      mic.onclick = () => (listening ? stopMic() : startMic());
    }
    goRow.append(go); if (mic) goRow.append(mic); goRow.append(status);
    const resultBox = el('div', 'display:flex;flex-direction:column;gap:8px');

    // recents row (rebuilt after each submit)
    const recentsWrap = el('div', 'display:flex;flex-direction:column;gap:6px');
    function renderRecents() {
      recentsWrap.innerHTML = '';
      const r = recentsGet(); if (!r.length) return;
      const head = el('div', 'display:flex;align-items:center;justify-content:space-between');
      head.append(el('div', 'font-size:11px;color:#777', 'Recent'));
      const clr = el('button', 'font:inherit;font-size:11px;color:#777;background:transparent;border:0;cursor:pointer', 'clear'); clr.onclick = () => { host.storage.set('recents', []); renderRecents(); };
      head.append(clr);
      const row = el('div', 'display:flex;flex-wrap:wrap;gap:6px');
      for (const s of r.slice(0, 8)) { const c = el('button', 'font:inherit;font-size:11px;padding:3px 8px;border-radius:4px;border:1px solid var(--card-border);background:var(--card);color:var(--card-fg);cursor:pointer;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap', s); c.onclick = () => { ta.value = s; run(); }; row.appendChild(c); }
      recentsWrap.append(head, row);
    }

    async function run() {
      const text = ta.value.trim(); if (!text) return;
      recentsAdd(text); renderRecents();
      resultBox.innerHTML = ''; status.textContent = '';
      const id = newId();
      // Tier 0
      const local = localMatch(text);
      if (local && !cmp.checked) {
        local._id = id; local._input = text; local._tier = 'local';
        logEvent({ ev: 'submit', id, input: text, tier: 'local', autonomy: activeAutonomy(), kind: local.kind, action: local.action, args: local.args, say: local.say });
        status.textContent = 'matched locally · free';
        return handle(local, resultBox, activeAutonomy());
      }
      // Tier 1 (single or compare)
      const ctxBody = { text, source: 'ui', actions: [...registry.values()].map((a) => ({ id: a.id, title: a.title, hint: a.hint, args: a.args })), sessions: sessions.map((s) => s.session), plugins: pluginIds, current, appName: inst.appName };
      if (cmp.checked) return runCompare(ctxBody, resultBox, status);
      status.textContent = 'routing…';
      let dec;
      try { dec = await post('route', ctxBody); }
      catch (e) { logEvent({ ev: 'submit', id, input: text, tier: 'llm', outcome: 'error', error: e && e.message }); status.textContent = 'route error'; resultBox.append(el('div', 'font-size:13px;color:#e57373', 'Route error: ' + (e && e.message))); return; }
      dec._id = id; dec._input = text; dec._tier = 'llm';
      logEvent({ ev: 'submit', id, input: text, tier: 'llm', autonomy: dec.profile && dec.profile.autonomy, profile: dec.profile && dec.profile.id, model: dec.profile && dec.profile.model, kind: dec.kind, action: dec.action, args: dec.args, say: dec.say, route_ms: dec.route_ms, error: dec.error });
      status.textContent = dec.profile ? `${dec.profile.name} → ${dec.kind}${dec.route_ms ? ' · ' + dec.route_ms + 'ms' : ''}` : dec.kind || '';
      handle(dec, resultBox);
    }
    go.onclick = run;
    ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); run(); } });

    // suggestion chips
    const sugRow = el('div', 'display:flex;flex-wrap:wrap;gap:6px');
    const SUGS = ['light theme', 'bigger font', current ? `tell ${current} to run the tests` : 'run the tests', 'new agent called scratch', 'add a deploy button', 'open customize'];
    for (const s of SUGS) { const c = el('button', 'font:inherit;font-size:11px;padding:3px 8px;border-radius:4px;border:1px solid var(--card-border);background:var(--card);color:var(--card-fg);cursor:pointer', s); c.onclick = () => { ta.value = s; run(); }; sugRow.appendChild(c); }

    bodyEl.append(profBar, ta, goRow, resultBox, recentsWrap, el('div', 'font-size:11px;color:#777', 'Try:'), sugRow);
    renderRecents();
    setTimeout(() => ta.focus(), 50);
  }

  // ---- compare: run the prompt through every keyed profile side by side ------
  async function runCompare(ctxBody, resultBox, status) {
    resultBox.innerHTML = ''; status.textContent = 'comparing profiles…';
    const { profiles } = await get('profiles');
    const keyed = profiles.filter((p) => p.hasKey);
    if (!keyed.length) { resultBox.append(el('div', 'font-size:13px;color:#e57373', 'No profiles have an API key.')); return; }
    await Promise.all(keyed.map(async (p) => {
      const col = el('div', 'border:1px solid var(--border);border-radius:10px;padding:10px;display:flex;flex-direction:column;gap:6px');
      col.append(el('div', 'font-size:12px;font-weight:bold;color:var(--accent)', p.name));
      const slot = el('div', 'font-size:12px;color:#999', 'routing…');
      col.append(slot); resultBox.appendChild(col);
      try {
        const dec = await post('route', { ...ctxBody, profileId: p.id });
        slot.innerHTML = '';
        slot.append(el('div', 'font-size:13px;color:var(--fg)', `${dec.kind}${dec.action ? ' · ' + dec.action : ''}`));
        slot.append(el('div', 'font-size:12px;color:#aaa', dec.say || dec.text || ''));
        const runIt = mkBtn('apply this', true); runIt.style.alignSelf = 'flex-start';
        runIt.onclick = () => { dec._id = newId(); dec._input = ctxBody.text; dec._tier = 'llm'; logEvent({ ev: 'submit', id: dec._id, input: ctxBody.text, tier: 'llm', source: 'compare', profile: p.id, model: p.model, kind: dec.kind, action: dec.action, args: dec.args, say: dec.say, route_ms: dec.route_ms }); const rb = el('div', 'margin-top:6px'); col.appendChild(rb); handle(dec, rb); };
        slot.append(runIt);
      } catch (e) { slot.textContent = 'error: ' + e.message; }
    }));
    status.textContent = 'compared ' + keyed.length + ' profiles';
  }

  // ---- profile manager -------------------------------------------------------
  async function manageProfiles(onClose) {
    const { back, bodyEl } = sheet('Router profiles');
    async function render() {
      bodyEl.innerHTML = '';
      const { profiles, activeId } = await get('profiles');
      for (const p of profiles) {
        const card = el('div', 'border:1px solid var(--border);border-radius:10px;padding:12px;display:flex;flex-direction:column;gap:8px');
        const top = el('div', 'display:flex;align-items:center;gap:8px');
        top.append(el('div', `flex:1;font-size:14px;font-weight:bold;color:${p.id === activeId ? 'var(--accent)' : 'var(--fg)'}`, p.name + (p.id === activeId ? ' · active' : '')));
        const use = mkBtn(p.id === activeId ? 'active' : 'use', p.id === activeId); if (p.id !== activeId) use.onclick = async () => { await post('setactive', { id: p.id }); render(); };
        top.append(use);
        card.append(top);
        const fields = {};
        const addF = (label, key, val, ph) => { const w = el('label', 'display:flex;flex-direction:column;gap:3px;font-size:11px;color:#888'); w.append(document.createTextNode(label)); const inp = el('input', 'font:inherit;font-size:13px;padding:7px;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg)'); inp.value = val || ''; if (ph) inp.placeholder = ph; w.append(inp); fields[key] = inp; card.append(w); };
        addF('Name', 'name', p.name);
        addF('Base URL', 'baseURL', p.baseURL, 'https://api.openai.com/v1');
        addF('Model', 'model', p.model);
        addF('API key', 'apiKey', '', p.hasKey ? '•••• set (leave blank to keep)' : 'paste key');
        addF('Custom router prompt (optional)', 'prompt', p.prompt);
        // autonomy select
        const autW = el('label', 'display:flex;flex-direction:column;gap:3px;font-size:11px;color:#888'); autW.append(document.createTextNode('Autonomy (confirm level)'));
        const autSel = el('select', 'font:inherit;font-size:13px;padding:7px;border-radius:7px;border:1px solid var(--border);background:var(--bg);color:var(--fg)');
        for (const a of [['balanced', 'balanced — confirm structural changes'], ['auto', 'auto — just do it (still checkpoints)'], ['plan', 'plan — confirm everything first']]) { const o = el('option'); o.value = a[0]; o.textContent = a[1]; if ((p.autonomy || 'balanced') === a[0]) o.selected = true; autSel.appendChild(o); }
        autW.append(autSel); card.append(autW);
        const btns = el('div', 'display:flex;gap:8px;flex-wrap:wrap');
        const save = mkBtn('Save', true); save.onclick = async () => { await post('saveprofile', { id: p.id, name: fields.name.value, baseURL: fields.baseURL.value, model: fields.model.value, apiKey: fields.apiKey.value, prompt: fields.prompt.value, autonomy: autSel.value }); render(); };
        const dup = mkBtn('Duplicate'); dup.onclick = async () => { await post('saveprofile', { name: p.name + ' copy', baseURL: fields.baseURL.value, model: fields.model.value, apiKey: fields.apiKey.value, prompt: fields.prompt.value, autonomy: autSel.value }); render(); };
        const del = mkBtn('Delete'); del.onclick = async () => { await post('deleteprofile', { id: p.id }); render(); };
        btns.append(save, dup, del); card.append(btns);
        bodyEl.appendChild(card);
      }
      const add = mkBtn('+ New profile', true); add.onclick = async () => { await post('saveprofile', { name: 'New profile', baseURL: 'https://api.openai.com/v1', model: 'gpt-4o-mini' }); render(); };
      bodyEl.appendChild(add);
    }
    await render();
    back.addEventListener('remove', () => onClose && onClose());
    // (sheet has its own ✕; refresh the caller's profile list when it closes)
    const obs = new MutationObserver(() => { if (!document.body.contains(back)) { obs.disconnect(); onClose && onClose(); } });
    obs.observe(document.body, { childList: true });
  }
}
