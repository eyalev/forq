// Omni backend — the LLM intent router + profile store.
//
// A "profile" is a named router config (provider base URL, model, key, autonomy,
// optional custom router prompt) so the user can keep several and A/B them. Keys
// live in ask-profiles.json (git-ignored — never checkpointed) and are NEVER sent
// back to the browser; the frontend only learns whether a key is set (hasKey).
//
// The frontend collects the live ACTION registry (from every plugin via the bus)
// and the session/plugin lists, posts them here with the user's text, and we ask
// the model to pick exactly one lane: action | agent | build | answer | clarify.
const fs = require('fs');
const path = require('path');

const DEFAULTS = () => ({
  activeId: 'openai',
  profiles: [
    { id: 'openai', name: 'OpenAI · gpt-4o-mini', baseURL: 'https://api.openai.com/v1', model: 'gpt-4o-mini', apiKey: process.env.OPENAI_API_KEY || '', autonomy: 'balanced', temperature: 0, prompt: '' },
    { id: 'groq', name: 'Groq · gpt-oss-120b', baseURL: 'https://api.groq.com/openai/v1', model: 'openai/gpt-oss-120b', apiKey: process.env.GROQ_API_KEY || '', autonomy: 'balanced', temperature: 0, prompt: '' },
  ],
});

module.exports = function setup(ctx) {
  const file = path.join(ctx.configDir, 'ask-profiles.json');

  // keep keys + logs out of any git checkpoint (studio makes configDir a repo)
  try {
    const gi = path.join(ctx.configDir, '.gitignore');
    if (fs.existsSync(path.join(ctx.configDir, '.git'))) {
      let cur = ''; try { cur = fs.readFileSync(gi, 'utf8'); } catch {}
      const lines = cur.split('\n');
      let add = '';
      for (const f of ['ask-profiles.json', 'ask-log.jsonl']) if (!lines.includes(f)) add += f + '\n';
      if (add) fs.writeFileSync(gi, cur + (cur && !cur.endsWith('\n') ? '\n' : '') + add);
    }
  } catch (e) { ctx.log('gitignore ensure failed:', e.message); }

  // ---- interaction log (JSONL; the eval/improve harness reads this) ----------
  const logFile = path.join(ctx.configDir, 'ask-log.jsonl');
  const appendLog = (rec) => { try { fs.appendFileSync(logFile, JSON.stringify(rec) + '\n'); } catch (e) { ctx.log('log append failed:', e.message); } };

  const load = () => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return DEFAULTS(); } };
  const save = (s) => fs.writeFileSync(file, JSON.stringify(s, null, 2));
  if (!fs.existsSync(file)) save(DEFAULTS());

  const userPlugins = path.join(ctx.configDir, 'plugins');
  const safe = (p) => ({ id: p.id, name: p.name, baseURL: p.baseURL, model: p.model, autonomy: p.autonomy || 'balanced', temperature: p.temperature || 0, prompt: p.prompt || '', hasKey: !!p.apiKey });
  const body = (req) => new Promise((r) => { const c = []; req.on('data', (x) => c.push(x)); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString())); } catch { r({}); } }); });
  const json = (res, o) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };

  ctx.route('info', (req, res) => json(res, { userPlugins }));

  ctx.route('profiles', (req, res) => { const s = load(); json(res, { activeId: s.activeId, profiles: s.profiles.map(safe) }); });

  ctx.route('saveprofile', async (req, res) => {
    const b = await body(req); const s = load();
    const id = b.id || ('p' + s.profiles.length + '_' + b.name.toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 6));
    const existing = s.profiles.find((p) => p.id === id);
    const next = { id, name: b.name || id, baseURL: b.baseURL || 'https://api.openai.com/v1', model: b.model || 'gpt-4o-mini', autonomy: b.autonomy || 'balanced', temperature: Number(b.temperature) || 0, prompt: b.prompt || '' };
    // only overwrite the key when a non-empty one is provided (so editing other fields keeps it)
    next.apiKey = (b.apiKey != null && b.apiKey !== '') ? b.apiKey : (existing ? existing.apiKey : '');
    if (existing) Object.assign(existing, next); else s.profiles.push(next);
    if (b.makeActive) s.activeId = id;
    save(s); json(res, { ok: true, id });
  });

  ctx.route('deleteprofile', async (req, res) => {
    const b = await body(req); const s = load();
    s.profiles = s.profiles.filter((p) => p.id !== b.id);
    if (s.activeId === b.id) s.activeId = s.profiles[0] && s.profiles[0].id;
    save(s); json(res, { ok: true });
  });

  ctx.route('setactive', async (req, res) => { const b = await body(req); const s = load(); s.activeId = b.id; save(s); json(res, { ok: true }); });

  // lightweight per-profile autonomy update (balanced | auto | plan)
  ctx.route('setautonomy', async (req, res) => { const b = await body(req); const s = load(); const p = s.profiles.find((x) => x.id === b.id); if (p) { p.autonomy = b.autonomy; save(s); } json(res, { ok: !!p }); });

  // the router: { text, actions, sessions, plugins, current, profileId? } -> decision
  ctx.route('route', async (req, res) => {
    const b = await body(req); const s = load();
    const prof = s.profiles.find((p) => p.id === (b.profileId || s.activeId)) || s.profiles[0];
    if (!prof) return json(res, { kind: 'error', error: 'no_profile', say: 'No router profile configured.' });
    if (!prof.apiKey) return json(res, { kind: 'error', error: 'no_key', say: `No API key set for "${prof.name}". Add one in Profiles.`, profile: safe(prof) });
    const t0 = Date.now();
    try {
      const decision = await callLLM(prof, b);
      const ms = Date.now() - t0;
      appendLog({ ts: new Date().toISOString(), ev: 'route', source: b.source || 'server', input: b.text, profileId: prof.id, model: prof.model, kind: decision.kind, action: decision.action, args: decision.args, say: decision.say, route_ms: ms });
      json(res, { ...decision, route_ms: ms, profile: { id: prof.id, name: prof.name, model: prof.model, autonomy: prof.autonomy } });
    } catch (e) {
      const ms = Date.now() - t0;
      ctx.log('route failed:', e.message);
      appendLog({ ts: new Date().toISOString(), ev: 'route', source: b.source || 'server', input: b.text, profileId: prof.id, error: e.message, route_ms: ms });
      json(res, { kind: 'error', error: e.message, say: 'Router call failed: ' + e.message, profile: { id: prof.id, name: prof.name } });
    }
  });

  // client posts full-lifecycle interaction events (Tier-0 matches, confirm/
  // cancel, applied outcome, 👍/👎 feedback) — the harness mines these.
  ctx.route('log', async (req, res) => { const b = await body(req); appendLog(Object.assign({ ts: new Date().toISOString() }, b)); json(res, { ok: true }); });
  ctx.route('logs', (req, res, url) => {
    const n = Math.min(Number(url.searchParams.get('n')) || 200, 5000);
    let lines = []; try { lines = fs.readFileSync(logFile, 'utf8').trim().split('\n').filter(Boolean); } catch {}
    const items = lines.slice(-n).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
    json(res, { items });
  });

  // checkpoint hook: frontend asks for a snapshot before a confirmed mutation;
  // studio (if installed) listens for app.checkpoint and commits.
  ctx.on('checkpoint', (p) => ctx.emit('app.checkpoint', p || {}));

  ctx.log('ready');
};

function sysPrompt(b) {
  const actions = (b.actions || []).map((a) => `- ${a.id}: ${a.title}.${a.hint ? ' ' + a.hint + '.' : ''} args: ${(a.args || []).map((x) => x.name + (x.desc ? `(${x.desc})` : '')).join(', ') || 'none'}`).join('\n');
  return `You are the intent router for "${b.appName || 'mobile-agent'}", a phone app for driving AI coding agents (Claude Code) running in tmux sessions. The user typed one natural-language command. Decide what to do and reply with ONLY a JSON object — no prose, no markdown.

Pick exactly one "kind":
- "action": invoke one registered ACTION (navigation, send text to the active agent, theme/font, create/kill/rename a session, toggle or revert an app plugin, open the customize panel). Set "action" to its id and "args" to an object matching its args.
- "agent": the user is instructing the CURRENTLY ACTIVE agent in free text (e.g. "run the tests", "fix the build"). Put the full message in "text".
- "build": the user wants to CHANGE THE APP ITSELF by writing/modifying a plugin (e.g. "add a deploy button", "make a clock widget", "move voice to the header"). Put a clear, self-contained spec for a coding agent in "text".
- "answer": a question you can answer from the context. Put the answer in "text".
- "clarify": ambiguous — put a short clarifying question in "text".

Always include "say": a short human-readable summary of the chosen action.

ACTIONS:
${actions || '(none registered)'}

Available sessions (targets for terminal.switch / terminal.send): ${(b.sessions || []).join(', ') || '(none)'}
Installed app plugin ids (targets for toggling/reverting): ${(b.plugins || []).join(', ') || '(none)'}
Currently active session: ${b.current || '(none)'}

Reply shape: {"kind":"action|agent|build|answer|clarify","action":"<id if action>","args":{...},"text":"<if agent/build/answer/clarify>","say":"<summary>"}`;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// Resilience: retry transient failures (429 rate-limit, 5xx) with backoff,
// honoring Retry-After. Persistent failures still surface so the user can
// switch profiles. (429s were the #1 source of omnibox errors — see ask-log.)
async function callLLM(prof, b) {
  const url = prof.baseURL.replace(/\/$/, '') + '/chat/completions';
  const messages = [
    { role: 'system', content: (prof.prompt ? prof.prompt + '\n\n' : '') + sysPrompt(b) },
    { role: 'user', content: String(b.text || '') },
  ];
  const payload = JSON.stringify({ model: prof.model, temperature: prof.temperature || 0, messages, response_format: { type: 'json_object' } });
  let lastErr;
  for (let attempt = 0; attempt < 3; attempt++) {
    let r;
    try { r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', authorization: `Bearer ${prof.apiKey}` }, body: payload }); }
    catch (e) { lastErr = e; if (attempt < 2) { await sleep(400 * Math.pow(2, attempt)); continue; } throw e; }
    if (r.ok) {
      const data = await r.json();
      const content = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
      if (!content) throw new Error('empty response');
      let d; try { d = JSON.parse(content); } catch { throw new Error('model did not return JSON'); }
      if (attempt > 0) d._retries = attempt;
      return d;
    }
    const status = r.status;
    const txt = (await r.text().catch(() => '')).slice(0, 200);
    lastErr = new Error(`${status} ${txt}`);
    if ((status === 429 || status >= 500) && attempt < 2) {
      const ra = Number(r.headers.get('retry-after'));
      await sleep(Math.min(ra ? ra * 1000 : 400 * Math.pow(2, attempt), 4000));
      continue;
    }
    throw lastErr;
  }
  throw lastErr || new Error('route failed');
}
