// Minimal layout — the look of mobile-agent's ?ui=minimal mode: the terminal,
// ONE row of keys and the input, nothing else. Made for embedding (forq's agent
// sheet), where the host page owns navigation, sessions and chat.
//
// Policy lives here, not in the shell (kernel stays neutral): the kernel's
// uiModes decides WHICH frontends load; this decides how those few look. It is
// inert outside ?ui=minimal, because the full app loads it too.
export default function init(host) {
  if (document.documentElement.dataset.ui !== 'minimal') return;
  const st = document.createElement('style');
  st.id = 'minimal-layout';
  st.textContent = `
    /* The terminal plugin still mounts its font/density buttons into the
       toolbar; minimal shows none of that chrome. */
    #slot-header, #slot-toolbar { display:none !important; }
    #slot-main { flex:1 1 auto !important; }
    /* One keys row: same height, radius and type as the input line, 44px
       touch targets, evenly spread when they fit and scrolling when not. */
    #slot-accessory > div { gap:6px !important; padding:6px 8px !important; border-top:1px solid var(--border) !important; }
    #slot-accessory button { flex:1 0 auto !important; min-width:44px !important; height:40px !important; padding:0 10px !important;
      border-radius:8px !important; font:500 15px system-ui, sans-serif !important; }
    #slot-footer > div { padding:6px 8px calc(6px + env(safe-area-inset-bottom)) !important; gap:6px !important; }
    /* Six keys fit a phone width without scrolling: Esc, Tab, ^C, Up, Down,
       Enter. quickkeys' order is Esc Tab ^C ^D ^R ↑ ↓ ← → ⏎, so hide ^D ^R ← →
       by position (quickkeys gives its buttons no names). */
    #slot-accessory > div > button:nth-child(4), #slot-accessory > div > button:nth-child(5),
    #slot-accessory > div > button:nth-child(8), #slot-accessory > div > button:nth-child(9) { display:none !important; }
    #slot-accessory > div { overflow-x:hidden !important; }
    #slot-accessory > div > button { flex:1 1 0 !important; min-width:0 !important; }
    #term-input { height:44px !important; font-size:16px !important; border-color:var(--border) !important; }
    #term-send { height:44px !important; min-width:52px !important; justify-content:center; font-size:16px !important; }
    input:focus { outline:none !important; border-color:var(--accent) !important; }
    body { overflow:hidden; -webkit-tap-highlight-color:transparent; }`;
  document.head.appendChild(st);
  const input = document.getElementById('term-input');
  if (input) input.placeholder = 'Type to the agent, Enter sends';
  host.log && host.log('minimal layout on');
}
