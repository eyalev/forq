// Usage telemetry (frontend half). Records WHICH control was used — never what
// was typed. Batched, fire-and-forget, and silent: it must never be able to
// break the app it is measuring.
export default function init(host) {
  const B = (window.__APP_BASE && window.__APP_BASE !== '/') ? window.__APP_BASE.replace(/\/$/, '') : '';
  const url = `${B}/api/p/${host.id}/log`;
  let queue = [];
  let timer = null;

  function flush(useBeacon) {
    if (!queue.length) return;
    const body = JSON.stringify(queue);
    queue = [];
    try {
      if (useBeacon && navigator.sendBeacon) {
        navigator.sendBeacon(url, new Blob([body], { type: 'application/json' }));
      } else {
        fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body, keepalive: true }).catch(() => {});
      }
    } catch { /* never surface telemetry failures */ }
  }
  function rec(ev, id, el) {
    if (!id) return;
    const node = el && el.closest ? el : null;
    queue.push({
      ev, id: String(id).slice(0, 60),
      plugin: (node && node.closest('[data-plugin]') || {}).dataset?.plugin || '',
      slot: ((node && node.closest('[id^="slot-"]') || {}).id || '').replace('slot-', ''),
    });
    if (queue.length >= 20) flush(false);
    else if (!timer) timer = setTimeout(() => { timer = null; flush(false); }, 5000);
  }

  // A control's identity, in order of how stable it is across releases.
  const identify = (el) => {
    const b = el.closest('button, [role="button"], a, select, .card, .sheet-menu-item, .chip');
    if (!b) return null;
    return b.id || b.getAttribute('aria-label') || b.getAttribute('title')
      || (b.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 40) || b.tagName.toLowerCase();
  };
  addEventListener('click', (e) => {
    const el = e.target && e.target.closest ? e.target : null;
    if (!el) return;
    const id = identify(el);
    if (id) rec('click', id, el);
  }, true);

  // Swipes: direction + which region they started in — tells us whether a
  // gesture could replace a button that people are hunting for.
  let sx = 0, sy = 0, st = 0, sslot = '';
  addEventListener('touchstart', (e) => {
    const t = e.touches && e.touches[0]; if (!t) return;
    sx = t.clientX; sy = t.clientY; st = Date.now();
    const el = e.target && e.target.closest ? e.target.closest('[id^="slot-"]') : null;
    sslot = (el && el.id || '').replace('slot-', '');
  }, { passive: true, capture: true });
  addEventListener('touchend', (e) => {
    const t = e.changedTouches && e.changedTouches[0]; if (!t || !st) return;
    const dx = t.clientX - sx, dy = t.clientY - sy, dt = Date.now() - st;
    st = 0;
    if (dt > 800 || (Math.abs(dx) < 45 && Math.abs(dy) < 45)) return;
    const dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
    queue.push({ ev: 'swipe', id: dir, plugin: '', slot: sslot });
  }, { passive: true, capture: true });

  // Cross-plugin signals that aren't clicks (a tab can change from the bus).
  host.bus.on('terminal.active', (p) => rec('switch', 'session:' + ((p && p.session) || '?'), null));
  host.bus.on('ui.layout', (p) => rec('layout', (p && p.layout) || '?', null));

  rec('open', 'app:' + (location.pathname.split('/')[1] || 'root'), null);
  addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(true); });
  addEventListener('pagehide', () => flush(true));
}
