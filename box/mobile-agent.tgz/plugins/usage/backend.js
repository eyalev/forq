// Usage telemetry — local only. Answers "which parts of this UI do I actually
// touch?" so the layout can be earned rather than guessed: rarely-used
// controls can move to a menu, hot ones to the thumb line.
//
// Privacy contract (deliberate, and the reason this can exist at all):
//  - control IDENTITY only — never typed text, never terminal content, never
//    file paths. A click logs "which button", not "what you did with it".
//  - stays on the machine it happened on (JSONL beside the app's own state);
//    nothing is sent anywhere. The report route is read locally.
const fs = require('fs');
const path = require('path');

const MAX_BYTES = 5 * 1024 * 1024;

module.exports = function setup(ctx) {
  // Prefer the durable workspace on cloud boxes so history survives a
  // container recycle; fall back to the app's config dir (laptop).
  const durable = '/workspace/.diag';
  const dir = fs.existsSync(durable) ? durable : ctx.configDir;
  const file = path.join(dir, 'usage.jsonl');

  function append(rows) {
    try {
      const st = fs.existsSync(file) ? fs.statSync(file) : null;
      if (st && st.size > MAX_BYTES) fs.renameSync(file, file + '.1');
      fs.appendFileSync(file, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
    } catch (e) { ctx.log('usage append failed', e.message); }
  }

  ctx.route('log', (req, res) => {
    if (req.method !== 'POST') { res.writeHead(405); return res.end(); }
    let body = '';
    req.on('data', (c) => { body += c; if (body.length > 262144) req.destroy(); });
    req.on('end', () => {
      let rows = [];
      try { rows = JSON.parse(body || '[]'); } catch { res.writeHead(400); return res.end('bad json'); }
      if (!Array.isArray(rows)) { res.writeHead(400); return res.end('want array'); }
      const now = new Date().toISOString();
      append(rows.slice(0, 500).map((r) => ({
        t: now,
        app: ctx.config.appName || '',
        ev: String(r.ev || '').slice(0, 24),         // click | swipe | switch | layout | scroll | open
        id: String(r.id || '').slice(0, 60),         // control identity (id / aria-label / short text)
        plugin: String(r.plugin || '').slice(0, 30), // which plugin owns it
        slot: String(r.slot || '').slice(0, 20),     // header/main/toolbar/accessory/footer
        n: Math.max(1, Math.min(parseInt(r.n, 10) || 1, 1000)),
      })));
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end('{"ok":true}');
    });
  });

  // Aggregated view — what gets used, what never does, and how that moves over
  // time. Read it directly (curl) or from the Studio panel.
  ctx.route('report', (req, res, url) => {
    const days = Math.max(1, Math.min(parseInt(url.searchParams.get('days'), 10) || 30, 365));
    const since = Date.now() - days * 86400_000;
    const controls = new Map();   // "ev|plugin|id" -> {ev,plugin,slot,id,n,first,last}
    const byDay = new Map();
    let total = 0;
    for (const f of [file + '.1', file]) {
      let raw = '';
      try { raw = fs.readFileSync(f, 'utf8'); } catch { continue; }
      for (const line of raw.split('\n')) {
        if (!line.trim()) continue;
        let r; try { r = JSON.parse(line); } catch { continue; }
        const ts = Date.parse(r.t || '');
        if (!ts || ts < since) continue;
        const n = r.n || 1;
        total += n;
        const day = r.t.slice(0, 10);
        byDay.set(day, (byDay.get(day) || 0) + n);
        const key = `${r.ev}|${r.plugin}|${r.id}`;
        const cur = controls.get(key) || { ev: r.ev, plugin: r.plugin, slot: r.slot, id: r.id, n: 0, first: r.t, last: r.t };
        cur.n += n; cur.last = r.t;
        controls.set(key, cur);
      }
    }
    const list = [...controls.values()].sort((a, b) => b.n - a.n);
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({
      days, total, events: list.length,
      byDay: [...byDay.entries()].sort().map(([d, n]) => ({ d, n })),
      top: list.slice(0, 40),
      rare: list.filter((c) => c.n <= 2).slice(0, 40),   // candidates to demote
      file,
    }, null, 2));
  });
};
