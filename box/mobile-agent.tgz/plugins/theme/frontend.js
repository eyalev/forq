// Settings (currently: theme). A ⚙ toolbar button opens a sheet. Themes set
// CSS vars on :root; the whole app reacts because everything reads var(--fg) etc.
// Token set mirrors tmux-web's design language (teal accent, flat dark chrome,
// card-style tabs): --card/--card-border/--card-fg = session-tab cards,
// --btn/--btn-border = flat key/toolbar buttons, --accent-fg = text on
// accent-filled surfaces (tmux-web uses black-on-teal), --muted = secondary text.
const THEMES = {
  dark:  { '--bg': '#1e1e1e', '--fg': '#ccc', '--accent': '#4ec9b0', '--accent-fg': '#000', '--chrome': '#111', '--border': '#333',
           '--card': '#252525', '--card-border': '#383838', '--card-fg': '#aaa', '--btn': '#2a2a2a', '--btn-border': '#444',
           '--muted': '#888', '--tab-active-fg': '#fff' },
  light: { '--bg': '#ffffff', '--fg': '#1e1e1e', '--accent': '#0d8a75', '--accent-fg': '#fff', '--chrome': '#f0f0f0', '--border': '#ccc',
           '--card': '#f7f7f7', '--card-border': '#ddd', '--card-fg': '#555', '--btn': '#ececec', '--btn-border': '#bbb',
           '--muted': '#666', '--tab-active-fg': '#000' },
};

export default function init(host) {
  function apply(name) {
    const vars = THEMES[name] || THEMES.dark;
    for (const [k, v] of Object.entries(vars)) document.documentElement.style.setProperty(k, v);
    host.storage.set('name', name);
    // terminal (and anyone else) adapts content colors to the theme
    host.bus.emit('ui.theme', { name, light: name === 'light' });
  }
  host.bus.on('ui.theme.request', () => host.bus.emit('ui.theme', { name: current, light: current === 'light' }));
  // Coerce any retired/unknown theme (e.g. the removed 'green') to dark, so a
  // device that previously stored it doesn't get stuck on a fallback.
  let current = host.storage.get('name');
  if (!THEMES[current]) current = 'dark';
  apply(current);

  // Layout policy (mobile-agent's choice — the core shell stays neutral): the
  // terminal (main slot) is a CONSTANT height and everything below lives in a
  // scrolling footer drawer with the input pinned. Injected here so the kernel
  // keeps no terminal/layout assumptions. Terminal height is per-device
  // (localStorage) — a phone and a desktop want very different heights.
  if (!document.getElementById('mobile-agent-layout')) {
    const ls = document.createElement('style'); ls.id = 'mobile-agent-layout';
    ls.textContent = `
      body { overflow:hidden; }
      #slot-main   { flex:0 0 var(--term-h, 46vh) !important; }
      #slot-footer { flex:1 1 auto !important; min-height:0; display:flex; flex-direction:column; }
      /* tmux-web-style focus: quiet teal border, no UA focus ring (the
         mobile-browser default ring rendered orange on the dark theme). */
      input:focus, textarea:focus { outline: none !important; border-color: var(--accent) !important; }`;
    document.head.appendChild(ls);
  }
  const TH_KEY = 'termH', TH_MIN = 28, TH_MAX = 82, TH_DEF = 46;
  const clampTH = (v) => Math.max(TH_MIN, Math.min(TH_MAX, v));
  const applyTermH = (vh) => document.documentElement.style.setProperty('--term-h', vh + 'vh');
  let termH = clampTH(Number(host.storage.get(TH_KEY)) || TH_DEF);
  applyTermH(termH);

  // Auto-capitalize first letter of the message input — OFF by default
  // (terminal commands are case-sensitive). Owned here (the settings sheet),
  // applied by the terminal plugin via the bus; we answer late-loading
  // plugins' `.request` so init order doesn't matter.
  const capOn = () => host.storage.get('autocap') === 'on';
  const broadcastCap = () => host.bus.emit('ui.autocapitalize', { on: capOn() });
  host.bus.on('ui.autocapitalize.request', broadcastCap);
  broadcastCap();

  // Screenshot Bridge is strictly OPT-IN per device: probing localhost:8377
  // from an HTTPS page makes Android Chrome show a scary "wants to access
  // other apps and services" permission prompt to EVERY visitor (seen live on
  // the read-only share link). Off by default; the owner flips it once on the
  // phone that actually runs the companion app.
  const bridgeOn = () => host.storage.get('bridge') === 'on';
  const broadcastBridge = () => host.bus.emit('ui.bridge', { on: bridgeOn() });
  host.bus.on('ui.bridge.request', broadcastBridge);
  broadcastBridge();

  const gear = document.createElement('button');
  gear.textContent = '⚙'; gear.title = 'settings';
  gear.style.cssText = 'flex:0 0 auto;font-size:13px;min-width:30px;height:26px;padding:0 6px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer';
  gear.tabIndex = -1;
  host.mount('toolbar', gear);

  function openSheet() {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:300;background:rgba(0,0,0,.5);display:flex;align-items:flex-end';
    const sheet = document.createElement('div');
    sheet.style.cssText = 'width:100%;background:var(--chrome);border-top:1px solid var(--border);border-radius:14px 14px 0 0;padding:16px 18px 28px;display:flex;flex-direction:column;gap:14px';
    const title = document.createElement('div'); title.textContent = 'Settings'; title.style.cssText = 'font-size:16px;font-weight:bold;color:var(--fg)';
    const themeLbl = document.createElement('div'); themeLbl.textContent = 'Theme'; themeLbl.style.cssText = 'font-size:12px;color:#888';
    const row = document.createElement('div'); row.style.cssText = 'display:flex;gap:8px';
    for (const name of Object.keys(THEMES)) {
      const b = document.createElement('button');
      b.textContent = name; const on = name === current;
      b.style.cssText = `flex:1;font:inherit;font-size:13px;padding:7px;border-radius:4px;cursor:pointer;text-transform:capitalize;border:1px solid ${on ? 'var(--accent)' : 'var(--border)'};background:${on ? 'var(--accent)' : 'transparent'};color:${on ? 'var(--accent-fg)' : 'var(--fg)'}`;
      b.onclick = () => { current = name; apply(name); back.remove(); };
      row.appendChild(b);
    }
    // Layout: terminal height
    const layLbl = document.createElement('div'); layLbl.textContent = 'Terminal height'; layLbl.style.cssText = 'font-size:12px;color:#888';
    const layRow = document.createElement('div'); layRow.style.cssText = 'display:flex;gap:8px;align-items:center';
    const stepBtn = (t) => { const b = document.createElement('button'); b.textContent = t; b.style.cssText = 'font:inherit;font-size:14px;width:34px;height:30px;border-radius:4px;border:1px solid var(--btn-border);background:var(--btn);color:var(--fg);cursor:pointer'; return b; };
    const minus = stepBtn('−'), plus = stepBtn('+'), reset = stepBtn('↺');
    const readout = document.createElement('div'); readout.style.cssText = 'flex:1;text-align:center;font-size:13px;color:var(--fg)';
    const showTH = () => { readout.textContent = termH + '% of screen'; };
    const setTH = (v) => { termH = clampTH(v); host.storage.set(TH_KEY, termH); applyTermH(termH); showTH(); };
    minus.onclick = () => setTH(termH - 4); plus.onclick = () => setTH(termH + 4); reset.onclick = () => setTH(TH_DEF);
    showTH();
    layRow.append(minus, readout, plus, reset);
    const layHint = document.createElement('div'); layHint.textContent = 'The terminal stays this tall; tabs & keys scroll in the drawer below it.'; layHint.style.cssText = 'font-size:11px;color:#777';
    // Input: auto-capitalize toggle
    const capLbl = document.createElement('div'); capLbl.textContent = 'Input'; capLbl.style.cssText = 'font-size:12px;color:#888';
    const capBtn = document.createElement('button');
    const paintCap = () => {
      const on = capOn();
      capBtn.textContent = 'Auto-capitalize first letter: ' + (on ? 'On' : 'Off');
      capBtn.style.cssText = `font:inherit;font-size:13px;padding:7px;border-radius:4px;cursor:pointer;border:1px solid ${on ? 'var(--accent)' : 'var(--border)'};background:${on ? 'var(--accent)' : 'transparent'};color:${on ? 'var(--accent-fg)' : 'var(--fg)'}`;
    };
    capBtn.onclick = () => { host.storage.set('autocap', capOn() ? 'off' : 'on'); paintCap(); broadcastCap(); };
    paintCap();

    const brBtn = document.createElement('button');
    const paintBr = () => {
      const on = bridgeOn();
      brBtn.textContent = 'Screenshot Bridge (Android app): ' + (on ? 'On' : 'Off');
      brBtn.style.cssText = `font:inherit;font-size:13px;padding:7px;border-radius:4px;cursor:pointer;border:1px solid ${on ? 'var(--accent)' : 'var(--border)'};background:${on ? 'var(--accent)' : 'transparent'};color:${on ? 'var(--accent-fg)' : 'var(--fg)'}`;
    };
    brBtn.onclick = () => { host.storage.set('bridge', bridgeOn() ? 'off' : 'on'); paintBr(); broadcastBridge(); };
    paintBr();

    const hint = document.createElement('div');
    hint.textContent = 'Notifications & voice are in the toolbar (🔔 / 🎤); A−/A+ set column density.';
    hint.style.cssText = 'font-size:11px;color:#777';
    sheet.append(title, themeLbl, row, layLbl, layRow, layHint, capLbl, capBtn, brBtn, hint);
    back.appendChild(sheet);
    back.onclick = (e) => { if (e.target === back) back.remove(); };
    document.body.appendChild(back);
  }
  gear.onclick = () => openSheet();   // click (not pointerup) — avoids trailing-click closing the sheet

  // omni (ask) integration: let the omnibox switch themes by name
  const announceOmni = () => host.bus.emit('omni.action', {
    id: 'theme.set', title: 'Switch color theme', hint: 'dark | light',
    args: [{ name: 'name', desc: 'one of: ' + Object.keys(THEMES).join(', ') }], mutates: false,
    run: (a) => { if (THEMES[a.name]) { current = a.name; apply(a.name); } },
  });
  host.bus.on('omni.collect', announceOmni);
  announceOmni();
}
