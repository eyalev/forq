// Tabs backend — server-synced tab state so phone + desktop share the same
// pinned layout / recents / collapsed groups (single-user; like voice/ask).
// Stored in tabs.json (git-ignored — usage state, churns with recents).
const fs = require('fs');
const path = require('path');

module.exports = function setup(ctx) {
  const file = path.join(ctx.configDir, 'tabs.json');
  try {
    if (fs.existsSync(path.join(ctx.configDir, '.git'))) {
      const gi = path.join(ctx.configDir, '.gitignore');
      let cur = ''; try { cur = fs.readFileSync(gi, 'utf8'); } catch {}
      if (!cur.split('\n').includes('tabs.json')) fs.writeFileSync(gi, cur + (cur && !cur.endsWith('\n') ? '\n' : '') + 'tabs.json\n');
    }
  } catch (e) { ctx.log('gitignore ensure failed:', e.message); }

  const DEFAULTS = { pins: [], recents: [], collapsed: [] };
  const load = () => { let s = {}; try { s = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {} return Object.assign({}, DEFAULTS, s); };
  const save = (s) => fs.writeFileSync(file, JSON.stringify(s, null, 2));
  // capped (see voice): tab state JSON is small; don't buffer a runaway POST.
  const body = (req) => new Promise((r) => { const c = []; let n = 0; req.on('data', (x) => { n += x.length; if (n > 1 << 20) { req.destroy(); return r({}); } c.push(x); }); req.on('end', () => { try { r(JSON.parse(Buffer.concat(c).toString())); } catch { r({}); } }); });
  const json = (res, o) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };

  ctx.route('get', (req, res) => json(res, load()));
  ctx.route('set', async (req, res) => { const b = await body(req); save(Object.assign(load(), b)); json(res, { ok: true }); });

  ctx.log('ready');
};
