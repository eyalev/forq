// Tabs plugin — the mobile-cc/tmux-web "core" tab experience:
//   • bottom placement (footer, above the message box, thumb-reachable)
//   • a RECENT (MRU) row — one tap back to where you just were
//   • sessions grouped into collapsible "projects" in one area
//   • a utility RAIL on the right: ▦ all sessions · 🕘 recent · 📌 pin-mode
//   • PINS — curate which sessions show (pinned mode); 📌 lit → tap to pin/unpin
//   • polished status dots: amber-pulse=permission prompt, blue=recent output,
//     orange=finished-since-viewed
// Pins / recents / collapsed are SERVER-SYNCED (tabs backend) so phone+desktop
// share one layout. Pure glue otherwise: renders what the terminal publishes.
export default function init(host) {
  // ---- server-synced state --------------------------------------------------
  let pins = new Set(), recents = [], collapsed = new Set();
  let dirty = null;
  const get = (sub) => host.api(sub).then((r) => r.json());
  function persist(partial) { clearTimeout(dirty); dirty = setTimeout(() => host.api('set', { method: 'POST', body: JSON.stringify(partial), headers: { 'content-type': 'application/json' } }), 250); }
  const savePins = () => persist({ pins: [...pins] });
  const saveCollapsed = () => persist({ collapsed: [...collapsed] });
  const saveRecents = () => persist({ recents });

  // ---- ambient ---------------------------------------------------------------
  let active = null, sessions = [], states = {}, mode = 'pinned', pinMode = false;
  const stateOf = (s) => (states[s] && states[s].state) || 'idle';

  // ---- layout: a column [ recentRow, [ tabArea | rail ] ] in the footer ------
  const wrap = document.createElement('div');
  // fills the footer drawer and scrolls internally (terminal height is constant)
  wrap.style.cssText = 'flex:1 1 auto;min-height:0;display:flex;flex-direction:column;background:var(--chrome);border-top:1px solid var(--border)';
  const recentRow = document.createElement('div');
  recentRow.style.cssText = 'display:flex;gap:4px;align-items:center;overflow-x:auto;padding:4px 6px;scrollbar-width:none;border-bottom:2px solid var(--btn-border)';
  const body = document.createElement('div');
  body.style.cssText = 'flex:1 1 auto;min-height:0;display:flex;align-items:stretch';
  const tabArea = document.createElement('div');
  tabArea.style.cssText = 'flex:1 1 auto;display:flex;flex-direction:column;gap:3px;overflow-y:auto;overflow-x:hidden;padding:4px;min-width:0';
  const rail = document.createElement('div');
  rail.style.cssText = 'flex:0 0 auto;display:flex;flex-direction:column;gap:3px;padding:4px 3px;border-left:1px solid var(--border)';
  body.append(tabArea, rail);
  wrap.append(recentRow, body);
  host.mount('footer', wrap);

  if (!document.getElementById('tabs-kf')) { const st = document.createElement('style'); st.id = 'tabs-kf'; st.textContent = '@keyframes tabs-pulse{0%,100%{opacity:1}50%{opacity:.3}}'; document.head.appendChild(st); }

  const DOT = { prompt: '#f0c040', active: '#4a9eff', finished: '#e8a828' };
  const RANK = { prompt: 3, finished: 2, active: 1, idle: 0 };
  function addDot(btn, state) {
    if (!state || !DOT[state]) return;
    const d = document.createElement('span');
    d.style.cssText = `display:inline-block;width:7px;height:7px;border-radius:50%;margin-left:6px;background:${DOT[state]};vertical-align:middle`;
    if (state === 'prompt' || state === 'active') d.style.animation = 'tabs-pulse 1s infinite';
    btn.appendChild(d);
  }
  function groupState(list) { let best = 'idle'; for (const s of list) if ((RANK[stateOf(s.session)] || 0) > (RANK[best] || 0)) best = stateOf(s.session); return best; }

  // (Long-press session menu removed: it kept popping mid-scroll. Rename/Kill
  // will come back as part of the tabs-area redesign, not via long-press.)

  // tmux-web ".pinned-tab" card: flat rect, subtle border, active = teal border
  // on the page background (never a filled pill); pinned = teal label text.
  const cwdTail = (p) => { if (!p) return ''; const seg = p.replace(/\/+$/, '').split('/'); return seg[seg.length - 1] || '/'; };
  function chip(label, { on = false, accent = false, pinned = false, cwd = '' } = {}) {
    const b = document.createElement('button');
    b.textContent = label;
    // Orientation sub-label — only when it adds information: a tab named like
    // its directory ("api" in .../api) would just repeat itself.
    if (cwd && cwdTail(cwd).toLowerCase() !== String(label).toLowerCase()) {
      const d = document.createElement('div');
      d.textContent = cwdTail(cwd);
      d.style.cssText = 'font-size:9px;opacity:.55;font-weight:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none';
      b.appendChild(d);
      b.title = cwd;
    }
    b.style.cssText = [
      'flex:0 0 auto', 'font:inherit', 'font-size:12px', 'padding:3px 4px', 'border-radius:4px', 'white-space:nowrap', 'cursor:pointer',
      'min-width:0', 'overflow:hidden', 'text-overflow:ellipsis', 'text-align:center',
      `border:1px solid ${on ? 'var(--accent)' : 'var(--card-border)'}`,
      `background:${on ? 'var(--bg)' : 'var(--card)'}`,
      `color:${on ? 'var(--tab-active-fg)' : accent || pinned ? 'var(--accent)' : 'var(--card-fg)'}`,
    ].join(';');
    return b;
  }
  function railBtn(glyph, lit, title) {
    const b = document.createElement('button'); b.textContent = glyph; b.title = title; b.tabIndex = -1;
    b.style.cssText = `flex:0 0 auto;font-size:12px;width:26px;height:24px;border-radius:4px;cursor:pointer;border:1px solid ${lit ? 'var(--accent)' : 'var(--btn-border)'};background:${lit ? 'var(--btn)' : 'transparent'};color:${lit ? 'var(--accent)' : 'var(--muted)'}`;
    return b;
  }
  // tmux-web ".pinned-row": equal-width cards flowing in a grid
  function grid(indent = 0) {
    const g = document.createElement('div');
    g.style.cssText = `display:grid;grid-template-columns:repeat(auto-fill,minmax(84px,1fr));gap:3px${indent ? `;padding-left:${indent}px` : ''}`;
    return g;
  }

  const groupsOf = (list) => { const m = new Map(); for (const s of list) { const g = s.group || s.session; if (!m.has(g)) m.set(g, []); m.get(g).push(s); } return m; };

  function onTabTap(name) {
    if (pinMode) { if (pins.has(name)) pins.delete(name); else pins.add(name); savePins(); render(); return; }
    host.bus.emit('terminal.switch', { session: name });
  }

  function renderRecent() {
    recentRow.textContent = '';
    const live = recents.filter((n) => sessions.some((s) => s.session === n)).slice(0, 12);
    if (!live.length) { recentRow.style.display = 'none'; return; }
    recentRow.style.display = 'flex';
    recentRow.appendChild(Object.assign(document.createElement('span'), { textContent: '🕘' })).style.cssText = 'flex:0 0 auto;font-size:11px;opacity:.6';
    for (const n of live) { const t = chip(n, { on: n === active }); t.dataset.tab = n; addDot(t, stateOf(n)); t.onclick = () => onTabTap(n); recentRow.appendChild(t); }
  }

  function render() {
    renderRecent();
    tabArea.textContent = '';
    // which sessions to show
    let shown = sessions;
    if (mode === 'pinned' && pins.size) shown = sessions.filter((s) => pins.has(s.session));
    // data-tab: a tab is addressable by session name (same reason the terminal
    // exposes #term-input) — the chip's text is a title, which may differ.
    const tabFor = (s) => { const t = chip(s.title || s.session, { on: s.session === active, pinned: pins.has(s.session), cwd: (states[s.session] || {}).cwd || s.cwd || '' }); t.dataset.tab = s.session; addDot(t, stateOf(s.session)); t.onclick = () => onTabTap(s.session); return t; };
    if (mode === 'recent') {
      const ordered = recents.filter((n) => sessions.some((s) => s.session === n));
      for (const s of sessions) if (!ordered.includes(s.session)) ordered.push(s.session);
      const g = grid();
      for (const n of ordered) { const s = sessions.find((x) => x.session === n); if (!s) continue; g.appendChild(tabFor(s)); }
      tabArea.appendChild(g);
    } else {
      if (mode === 'pinned' && !pins.size) { const hint = document.createElement('div'); hint.textContent = 'No pins yet — tap 📌 then a tab to pin. Showing all:'; hint.style.cssText = 'font-size:11px;color:var(--muted);padding:2px 2px 4px'; tabArea.appendChild(hint); }
      // consecutive single-session groups flow together in ONE grid (tmux-web rows)
      let singles = null;
      for (const [group, list] of groupsOf(shown)) {
        if (list.length === 1 && list[0].session === group) {
          if (!singles) { singles = grid(); tabArea.appendChild(singles); }
          singles.appendChild(tabFor(list[0])); continue;
        }
        singles = null;
        const isC = collapsed.has(group);
        // flat section header (muted text, no card) — groups read as labeled rows
        const head = document.createElement('button');
        head.textContent = `${isC ? '▸' : '▾'} ${group}${isC ? ` (${list.length})` : ''}`;
        head.style.cssText = 'font:inherit;font-size:11px;text-align:left;padding:3px 2px 1px;border:0;background:transparent;color:var(--muted);cursor:pointer;width:100%';
        if (isC) addDot(head, groupState(list));
        head.onclick = () => { if (isC) collapsed.delete(group); else collapsed.add(group); saveCollapsed(); render(); };
        tabArea.appendChild(head);
        if (isC) continue;
        const trow = grid(6);
        for (const s of list) trow.appendChild(tabFor(s));
        tabArea.appendChild(trow);
      }
    }
    // rail
    rail.textContent = '';
    const add = railBtn('➕', false, 'new session'); add.style.color = 'var(--accent)'; add.style.borderColor = 'var(--accent)';
    add.onclick = () => host.bus.emit('sessions.openCreate', {});
    const all = railBtn('▦', mode === 'all', 'all sessions'); all.onclick = () => { mode = mode === 'all' ? 'pinned' : 'all'; render(); };
    const rec = railBtn('🕘', mode === 'recent', 'recent'); rec.onclick = () => { mode = mode === 'recent' ? 'pinned' : 'recent'; render(); };
    const pin = railBtn('📌', pinMode, 'pin mode — tap tabs to pin/unpin'); pin.onclick = () => { pinMode = !pinMode; render(); };
    rail.append(add, all, rec, pin);
  }

  function bumpRecent(name) {
    if (!name) return;
    recents = [name, ...recents.filter((n) => n !== name)].slice(0, 30);
    saveRecents();
  }

  host.bus.on('terminal.sessions', (list) => { sessions = list || []; render(); });
  host.bus.on('terminal.active', ({ session }) => { active = session; bumpRecent(session); render(); });
  host.bus.on('terminal.states', (s) => { states = s || {}; render(); });

  get('get').then((s) => {
    pins = new Set(s.pins || []); recents = s.recents || []; collapsed = new Set(s.collapsed || []);
    render(); host.bus.emit('terminal.requestSessions');
  }).catch(() => { render(); host.bus.emit('terminal.requestSessions'); });
}
