// Download backend — GET /api/p/download/file?path=<abs-or-~>. Streams the file
// as an attachment. Security: $HOME allowlist after realpath (rejects ../ and
// symlink escape; component-wise, so /home/aliceous is not inside /home/alice),
// 256 MiB cap. Justified by the single-user threat model (UI reach already
// implies a shell in the pane) — same stance as mobile-cc's download.rs.
const fs = require('fs');
const path = require('path');
const os = require('os');

module.exports = function setup(ctx) {
  ctx.route('file', (req, res, url) => {
    let p = url.searchParams.get('path');
    if (!p) { res.writeHead(400); return res.end('no path'); }
    if (p === '~' || p.startsWith('~/')) p = path.join(os.homedir(), p.slice(1));
    let real, home;
    try { home = fs.realpathSync(os.homedir()); } catch { res.writeHead(500); return res.end(); }
    try { real = fs.realpathSync(p); } catch { res.writeHead(404); return res.end('not found'); }
    if (real !== home && !real.startsWith(home + path.sep)) { res.writeHead(403); return res.end('forbidden'); }
    let st;
    try { st = fs.statSync(real); } catch { res.writeHead(404); return res.end('not found'); }
    if (!st.isFile()) { res.writeHead(404); return res.end('not a file'); }
    if (st.size > 256 * 1024 * 1024) { res.writeHead(413); return res.end('too large'); }
    res.writeHead(200, {
      'content-type': 'application/octet-stream',
      'content-disposition': `attachment; filename="${path.basename(real).replace(/["\r\n]/g, '')}"`,
      'content-length': st.size,
    });
    fs.createReadStream(real).pipe(res);
  });
  ctx.log('ready');
};
