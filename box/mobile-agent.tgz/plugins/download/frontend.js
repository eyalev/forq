// Download & links — registers a row decorator with the terminal that detects
// absolute/~ paths and URLs in a row. Tapping a row with links opens a popover
// listing them with Download / Open / Copy. (Row-level, not inline-wrapping, so
// it never fights the terminal's span-diff rendering and stays thumb-friendly.)
const PATH_RE = /(?:~|\/)[A-Za-z0-9._\-/]+[A-Za-z0-9._\-]/g;
const URL_RE = /https?:\/\/[^\s)<>"']+/g;

function scan(text) {
  const links = [];
  for (const m of text.matchAll(URL_RE)) links.push({ kind: 'url', value: m[0] });
  for (const m of text.matchAll(PATH_RE)) { if (m[0].length > 3 && /\.[A-Za-z0-9]+$|\//.test(m[0])) links.push({ kind: 'path', value: m[0] }); }
  // de-dup, drop paths that are substrings of a url
  const seen = new Set();
  return links.filter((l) => { if (seen.has(l.value)) return false; seen.add(l.value); return true; });
}

export default function init(host) {
  function popover(links) {
    const back = document.createElement('div');
    back.style.cssText = 'position:fixed;inset:0;z-index:200;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center';
    const box = document.createElement('div');
    box.style.cssText = 'background:var(--chrome);border:1px solid var(--border);border-radius:12px;padding:12px;max-width:88vw;max-height:70vh;overflow:auto;display:flex;flex-direction:column;gap:10px';
    for (const l of links) {
      const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-direction:column;gap:4px';
      const label = document.createElement('div'); label.textContent = l.value;
      label.style.cssText = `font-size:11px;word-break:break-all;color:${l.kind === 'url' ? 'var(--accent)' : 'var(--fg)'}`;
      const actions = document.createElement('div'); actions.style.cssText = 'display:flex;gap:6px';
      const mk = (txt, fn) => { const b = document.createElement('button'); b.textContent = txt; b.style.cssText = 'font:inherit;font-size:12px;padding:5px 10px;border-radius:6px;border:1px solid var(--accent);background:transparent;color:var(--accent);cursor:pointer'; b.onclick = () => { fn(); back.remove(); }; return b; };
      if (l.kind === 'path') actions.appendChild(mk('Download', () => { window.location = `/api/p/download/file?path=${encodeURIComponent(l.value)}`; }));
      if (l.kind === 'url') actions.appendChild(mk('Open', () => window.open(l.value, '_blank')));
      actions.appendChild(mk('Copy', () => navigator.clipboard && navigator.clipboard.writeText(l.value)));
      wrap.append(label, actions); box.appendChild(wrap);
    }
    back.appendChild(box);
    back.onclick = (e) => { if (e.target === back) back.remove(); };
    document.body.appendChild(back);
  }

  host.bus.emit('terminal.addRowDecorator', (div) => {
    if (div._dlScanned === div.textContent) return; // avoid rework on identical re-render
    div._dlScanned = div.textContent;
    const links = scan(div.textContent || '');
    if (!links.length) { div.style.textDecoration = ''; div.style.cursor = ''; div.onclick = null; return; }
    div.style.cursor = 'pointer';
    div.style.textDecorationColor = 'var(--accent)';
    div.onclick = () => popover(links);
  });
}
