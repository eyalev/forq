// Image upload backend.
//   POST /api/p/images/upload?name=<orig> (raw image body) -> { path, name }
//     Saves to <configDir>/uploads; the frontend sends the path to the pane as
//     `[image: /abs/path]` so CC can read it. 32 MiB cap.
//   POST /api/p/images/rm?name=<basename> — remove a staged upload the user
//     discarded before sending (basename-only, uploads dir only).
const fs = require('fs');
const path = require('path');

module.exports = function setup(ctx) {
  const dir = path.join(ctx.configDir, 'uploads');
  fs.mkdirSync(dir, { recursive: true });
  let counter = 0;

  ctx.route('upload', (req, res, url) => {
    if (req.method !== 'POST') { res.writeHead(405); return res.end('POST only'); }
    const chunks = []; let size = 0; let aborted = false;
    req.on('data', (c) => { size += c.length; if (size > 32 * 1024 * 1024) { aborted = true; req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (aborted) { res.writeHead(413); return res.end('too large'); }
      // extension: original filename if provided, else content-type subtype
      const orig = (url && url.searchParams.get('name')) || '';
      const ct = req.headers['content-type'] || 'image/png';
      const ext = (path.extname(orig).slice(1) || ct.split('/')[1] || 'png')
        .replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'png';
      const name = `img-${Date.now()}-${counter++}.${ext}`;
      const fp = path.join(dir, name);
      try { fs.writeFileSync(fp, Buffer.concat(chunks)); } catch (e) { res.writeHead(500); return res.end(e.message); }
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ path: fp, name }));
    });
  });

  ctx.route('rm', (req, res, url) => {
    if (req.method !== 'POST' && req.method !== 'DELETE') { res.writeHead(405); return res.end('POST/DELETE only'); }
    const name = (url && url.searchParams.get('name')) || '';
    // strict shape: only files we minted, no separators/traversal
    if (!/^img-\d+-\d+\.[a-z0-9]{1,5}$/i.test(name)) { res.writeHead(400); return res.end('bad name'); }
    try { fs.unlinkSync(path.join(dir, name)); } catch {}
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end('{"ok":true}');
  });

  ctx.log('uploads ->', dir);
};
