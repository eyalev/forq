// Image attach — mcc/tmux-web-style staged queue. Three entry paths (📷 picker
// for mobile, clipboard paste + drag-drop for desktop) feed a per-session queue
// of thumbnails above the input row; each image eager-uploads (progress bar,
// × remove). Send is intercepted (capture phase on #term-send / Enter in
// #term-input): the message goes to the pane as `<caption> [image: /abs/path]`
// — the same format mcc's daemon pastes — so CC can read the file.
export default function init(host) {
  // hot-reload: the shell removes mounted nodes but not document listeners;
  // tear down the previous instance's globals before wiring new ones.
  if (window.__imagesTeardown) { try { window.__imagesTeardown(); } catch {} }

  const MAX_LONG_EDGE = 2048;
  const DOWNSCALE_MIN_BYTES = 600 * 1024;
  const UPLOAD_WAIT_MS = 15000;

  // per-session queue. entry: {uid, name, thumbUrl, status, progress, path, error, xhr}
  // status ∈ 'preparing' | 'uploading' | 'done' | 'error' | 'aborted'
  const queues = new Map();
  let active = null;
  const q = (s) => { if (!queues.has(s)) queues.set(s, []); return queues.get(s); };
  const genUid = () => 'u' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);

  // --- styles + preview strip -------------------------------------------------
  const style = document.createElement('style');
  style.id = 'images-styles';
  style.textContent = `
    #img-preview { display:none; flex-wrap:wrap; gap:6px; padding:6px 8px;
      background:var(--chrome); border-top:1px solid var(--border); }
    .img-thumb { position:relative; width:56px; height:56px; border-radius:6px;
      overflow:hidden; background:#000; flex:0 0 auto; }
    .img-thumb img { width:100%; height:100%; object-fit:cover; opacity:.6; transition:opacity .15s; }
    .img-thumb.is-done img { opacity:1; }
    .img-thumb.is-error img { opacity:.3; filter:grayscale(1); }
    .img-thumb .img-rm { position:absolute; top:2px; right:2px; width:18px; height:18px;
      border-radius:50%; background:rgba(0,0,0,.7); color:#fff; border:none;
      font-size:13px; line-height:1; padding:0; cursor:pointer; }
    .img-thumb .img-bar { position:absolute; left:0; bottom:0; right:0; height:3px; background:rgba(0,0,0,.5); }
    .img-thumb .img-bar-fill { height:100%; background:var(--accent); transition:width .1s linear; }
    .img-thumb.is-done .img-bar, .img-thumb.is-error .img-bar { display:none; }
    .img-thumb .img-badge { position:absolute; left:2px; bottom:2px; padding:1px 4px;
      border-radius:3px; background:rgba(0,0,0,.7); color:#fff; font-size:10px; }
    #img-drop-overlay { position:fixed; inset:0; display:none; align-items:center;
      justify-content:center; background:rgba(0,0,0,.55); color:var(--accent);
      font:600 20px system-ui,sans-serif; pointer-events:none; z-index:9999;
      border:3px dashed var(--accent); }
    .img-toast { position:fixed; left:50%; bottom:110px; transform:translateX(-50%);
      background:var(--chrome); color:var(--fg); padding:8px 14px; border-radius:6px;
      font:13px system-ui,sans-serif; box-shadow:0 4px 14px rgba(0,0,0,.4);
      z-index:9999; max-width:80vw; pointer-events:none; }
    .img-toast.is-error { background:#5a1f1f; color:#f48771; }`;
  document.head.appendChild(style);

  const strip = document.createElement('div');
  strip.id = 'img-preview';
  host.mount('footer', strip);

  const overlay = document.createElement('div');
  overlay.id = 'img-drop-overlay';
  overlay.textContent = 'Drop image to attach';
  document.body.appendChild(overlay);

  function flash(msg, level) {
    document.querySelectorAll('.img-toast').forEach((t) => t.remove());
    const t = document.createElement('div');
    t.className = 'img-toast' + (level === 'error' ? ' is-error' : '');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), level === 'error' ? 3500 : 1800);
  }

  function paint() {
    // keep the strip directly ABOVE the input bar and the button inside it
    // (the terminal may rebuild the bar on hot-reload)
    const bar = document.getElementById('term-input')?.parentElement;
    if (bar && bar.parentElement && strip.nextElementSibling !== bar) {
      bar.parentElement.insertBefore(strip, bar);
    }
    place();
    const list = active ? q(active) : [];
    if (!list.length) { strip.style.display = 'none'; strip.innerHTML = ''; return; }
    strip.style.display = 'flex';
    strip.innerHTML = '';
    for (const e of list) {
      const th = document.createElement('div');
      th.className = 'img-thumb is-' + e.status;
      const img = document.createElement('img');
      if (e.thumbUrl) img.src = e.thumbUrl;
      th.appendChild(img);
      const rm = document.createElement('button');
      rm.className = 'img-rm'; rm.textContent = '×'; rm.title = 'Remove'; rm.tabIndex = -1;
      rm.addEventListener('mousedown', (ev) => ev.preventDefault());
      rm.addEventListener('click', () => remove(e.uid));
      th.appendChild(rm);
      const bar2 = document.createElement('div'); bar2.className = 'img-bar';
      const fill = document.createElement('div'); fill.className = 'img-bar-fill';
      fill.style.width = Math.round((e.progress || 0) * 100) + '%';
      bar2.appendChild(fill); th.appendChild(bar2);
      if (e.status === 'done' || e.status === 'error') {
        const badge = document.createElement('div');
        badge.className = 'img-badge';
        badge.textContent = e.status === 'done' ? '✓' : '⚠';
        if (e.error) badge.title = e.error;
        th.appendChild(badge);
      }
      strip.appendChild(th);
    }
  }

  // --- thumbs + downscale -------------------------------------------------------
  // data-URL thumb (not object URL): Android picker Files are content-provider
  // backed and the read grant can expire → broken <img> long after upload OK.
  async function makeThumb(file) {
    try {
      const bmp = await createImageBitmap(file);
      const scale = Math.min(1, 128 / Math.max(bmp.width, bmp.height));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round(bmp.width * scale));
      c.height = Math.max(1, Math.round(bmp.height * scale));
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      bmp.close();
      return c.toDataURL('image/jpeg', 0.7);
    } catch { return null; }
  }

  // Phone photos are 3–8 MB; a 2048px-long-edge JPEG at q=0.85 lands ~200–500 KB
  // with no visible loss. Skip GIFs (animation) and already-small files.
  async function maybeDownscale(file) {
    try {
      if (!file.type?.startsWith('image/') || file.type === 'image/gif') return file;
      if (file.size < DOWNSCALE_MIN_BYTES) return file;
      const bmp = await createImageBitmap(file);
      const long = Math.max(bmp.width, bmp.height);
      if (long <= MAX_LONG_EDGE) { bmp.close(); return file; }
      const scale = MAX_LONG_EDGE / long;
      const c = document.createElement('canvas');
      c.width = Math.round(bmp.width * scale);
      c.height = Math.round(bmp.height * scale);
      c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
      bmp.close();
      const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.85));
      if (!blob || blob.size >= file.size) return file;
      return new File([blob], (file.name || 'image').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' });
    } catch { return file; }
  }

  // --- upload -------------------------------------------------------------------
  function uploadOne(entry, blob) {
    return new Promise((resolve) => {
      const xhr = new XMLHttpRequest();
      entry.xhr = xhr; entry.status = 'uploading'; paint();
      // Base-aware URL: served under a path prefix (e.g. /c/<id>/agent/), an
      // absolute /api/p/... escapes the app entirely and the upload dies on
      // the host site (found live — the POST never reached the backend).
      const B = (window.__APP_BASE && window.__APP_BASE !== '/') ? window.__APP_BASE.replace(/\/$/, '') : '';
      xhr.open('POST', `${B}/api/p/${host.id}/upload?name=${encodeURIComponent(blob.name || entry.name)}`);
      xhr.setRequestHeader('content-type', blob.type || 'image/png');
      xhr.upload.onprogress = (e) => { if (e.lengthComputable) { entry.progress = e.loaded / e.total; paint(); } };
      xhr.onload = () => {
        entry.xhr = null;
        try {
          const d = JSON.parse(xhr.responseText);
          if (xhr.status < 300 && d.path) { entry.path = d.path; entry.status = 'done'; entry.progress = 1; }
          else { entry.status = 'error'; entry.error = d.error || 'HTTP ' + xhr.status; }
        } catch { entry.status = 'error'; entry.error = 'HTTP ' + xhr.status; }
        paint(); resolve();
      };
      xhr.onerror = () => { entry.xhr = null; if (entry.status !== 'aborted') { entry.status = 'error'; entry.error = 'network error'; paint(); } resolve(); };
      xhr.onabort = () => { entry.xhr = null; entry.status = 'aborted'; resolve(); };
      xhr.send(blob);
    });
  }

  async function attach(file) {
    if (!file || !file.type?.startsWith('image/') || !active) return;
    const entry = { uid: genUid(), name: file.name || 'image', thumbUrl: null, status: 'preparing', progress: 0, path: null, error: null, xhr: null };
    q(active).push(entry);
    paint();
    makeThumb(file).then((url) => { if (url && entry.status !== 'aborted') { entry.thumbUrl = url; paint(); } });
    const blob = await maybeDownscale(file);
    if (entry.status === 'aborted') return;
    await uploadOne(entry, blob);
  }

  function remove(uid) {
    const list = active ? q(active) : [];
    const i = list.findIndex((e) => e.uid === uid);
    if (i < 0) return;
    const e = list[i];
    if (e.xhr) try { e.xhr.abort(); } catch {}
    if (e.path) host.api(`rm?name=${encodeURIComponent(e.path.split('/').pop())}`, { method: 'POST' }).catch(() => {});
    list.splice(i, 1);
    paint();
  }

  // --- send interception ----------------------------------------------------
  // When the active session has staged images, sending composes
  // `<caption> [image: /path]…` and routes it through the terminal bus.
  function pending() { return active ? q(active).filter((e) => e.status !== 'error' && e.status !== 'aborted') : []; }

  async function sendWithImages() {
    const list = q(active);
    const inflight = list.filter((e) => e.status === 'preparing' || e.status === 'uploading');
    if (inflight.length) {
      flash('Waiting for uploads…');
      // bounded wait: a hung upload otherwise blocks Send forever
      await Promise.all(inflight.map((e) => new Promise((res) => {
        const t0 = Date.now();
        const t = setInterval(() => {
          if (e.status !== 'preparing' && e.status !== 'uploading') { clearInterval(t); res(); }
          else if (Date.now() - t0 > UPLOAD_WAIT_MS) {
            clearInterval(t);
            try { e.xhr?.abort(); } catch {}
            e.status = 'error'; e.error = 'upload timed out';
            res();
          }
        }, 100);
      })));
      paint();
    }
    const ready = list.filter((e) => e.status === 'done');
    if (!ready.length) { flash('All uploads failed', 'error'); return; }
    const input = document.getElementById('term-input');
    const caption = input ? input.value.trim() : '';
    const text = (caption ? caption + ' ' : '') + ready.map((e) => `[image: ${e.path}]`).join(' ');
    host.bus.emit('terminal.input', { data: text });
    host.bus.emit('terminal.input', { data: '\r' });
    for (const e of ready) { const i = list.indexOf(e); if (i >= 0) list.splice(i, 1); }
    if (input) input.value = '';
    paint();
  }

  // capture phase on document — runs before the terminal's own target-phase
  // handlers, so we can swallow the plain send when images are staged.
  function onClick(e) {
    if (!pending().length) return;
    if (!e.target.closest || !e.target.closest('#term-send')) return;
    e.stopPropagation(); e.preventDefault();
    sendWithImages();
  }
  function onKeydown(e) {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;
    if (e.target.id !== 'term-input' || !pending().length) return;
    e.stopPropagation(); e.preventDefault();
    sendWithImages();
  }

  // --- paste / drop -----------------------------------------------------------
  function onPaste(e) {
    const items = e.clipboardData?.items || [];
    let got = false;
    for (const it of items) {
      if (it.kind === 'file' && it.type?.startsWith('image/')) { const f = it.getAsFile(); if (f) { attach(f); got = true; } }
    }
    if (got) e.preventDefault();
  }
  function onDragOver(e) {
    if (![...(e.dataTransfer?.types || [])].includes('Files')) return;
    e.preventDefault();
    overlay.style.display = 'flex';
  }
  function onDragLeave(e) { if (e.relatedTarget === null) overlay.style.display = 'none'; }
  function onDrop(e) {
    overlay.style.display = 'none';
    if (!e.dataTransfer?.files) return;
    let got = false;
    for (const f of e.dataTransfer.files) if (f.type?.startsWith('image/')) { attach(f); got = true; }
    if (got) e.preventDefault();
  }

  document.addEventListener('click', onClick, true);
  document.addEventListener('keydown', onKeydown, true);
  document.addEventListener('paste', onPaste);
  document.addEventListener('dragover', onDragOver);
  document.addEventListener('dragleave', onDragLeave);
  document.addEventListener('drop', onDrop);
  window.__imagesTeardown = () => {
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKeydown, true);
    document.removeEventListener('paste', onPaste);
    document.removeEventListener('dragover', onDragOver);
    document.removeEventListener('dragleave', onDragLeave);
    document.removeEventListener('drop', onDrop);
    overlay.remove(); style.remove(); btn.remove(); recentsBtn.remove(); recentsStrip.remove();
    document.querySelectorAll('.img-toast').forEach((t) => t.remove());
  };

  // --- 📷 button — lives IN the input row, left of the text box (the mcc
  // 'input-left' arrangement). The bar is the terminal plugin's; we insert
  // ourselves as its first child and re-insert from place() if the terminal
  // hot-reloads and rebuilds it.
  const btn = document.createElement('button');
  btn.title = 'Attach image (paste or drop also work)';
  btn.tabIndex = -1;
  btn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>';
  btn.style.cssText = 'flex:0 0 auto;height:36px;display:flex;align-items:center;justify-content:center;width:40px;border-radius:8px;border:1px solid var(--btn-border);background:var(--btn);color:var(--accent);cursor:pointer;padding:0';
  btn.addEventListener('mousedown', (e) => e.preventDefault());
  btn.addEventListener('click', () => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = 'image/*'; inp.multiple = true;
    inp.onchange = () => { for (const f of inp.files) attach(f); };
    inp.click();
  });
  // --- 📸 screenshot bridge — one-tap attach of the phone's newest screenshot.
  // Talks to the Screenshot Bridge Android app's loopback HTTP server
  // (dev.eyalev.shotbridge, port 8377). Two hard-won rules from tmux-web:
  // use 'localhost', NOT '127.0.0.1' (Chrome blocks plaintext fetch to the IP
  // literal from HTTPS pages; the hostname is treated as trustworthy), and
  // each tap attaches the newest screenshot NOT already staged, so repeat
  // taps walk backwards through recents. Button self-gates: it only appears
  // when the bridge answers /ping — phones without the app never see it.
  const bridgeUrl = (p) => 'http://localhost:8377' + p;
  const bridgeFetch = async (p, ms) => {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), ms || 8000);
    try {
      const res = await fetch(bridgeUrl(p), { signal: ctrl.signal });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res;
    } finally { clearTimeout(t); }
  };
  const recentsBtn = document.createElement('button');
  recentsBtn.title = 'Attach last screenshot (hold: pick from recent)';
  recentsBtn.tabIndex = -1;
  recentsBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><path d="M18 22H4a2 2 0 0 1-2-2V6"/><path d="m22 13-1.296-1.296a2.41 2.41 0 0 0-3.408 0L11 18"/><circle cx="12" cy="8" r="2"/><rect width="16" height="16" x="6" y="2" rx="2"/></svg>';
  recentsBtn.style.cssText = btn.style.cssText + ';display:none';
  const recentsStrip = document.createElement('div');
  recentsStrip.style.cssText = 'display:none;gap:6px;padding:6px 8px;background:var(--chrome);border-top:1px solid var(--border);overflow-x:auto;scrollbar-width:none';
  host.mount('footer', recentsStrip);
  // Probe ONLY when the device has opted in via Settings — an unconditional
  // load-time probe fired Android Chrome's device-access permission prompt at
  // every visitor (incl. anonymous read-only viewers).
  host.bus.on('ui.bridge', (p) => {
    if (p && p.on) bridgeFetch('/ping', 2500).then(() => { recentsBtn.style.display = 'flex'; }).catch(() => {});
    else recentsBtn.style.display = 'none';
  });
  host.bus.emit('ui.bridge.request', {});

  let bridgeBusy = false;
  async function attachLatestFromBridge() {
    if (bridgeBusy) return;
    bridgeBusy = true;
    try {
      const recent = await (await bridgeFetch('/recent?n=12')).json();
      if (!Array.isArray(recent) || !recent.length) { flash('no screenshots on phone', 'error'); return; }
      const list = active ? q(active) : [];
      const staged = (s) => list.some((e) => e.status !== 'aborted' && e.status !== 'error' && (e.shotId === s.id || e.name === s.name));
      const next = recent.find((s) => !staged(s));
      if (!next) { flash('all ' + recent.length + ' recent screenshots attached'); return; }
      const blob = await (await bridgeFetch('/shot/' + next.id)).blob();
      const f = new File([blob], next.name || 'screenshot.png', { type: blob.type || next.mime || 'image/png' });
      await attachBridge(f, next.id);
    } catch (e) {
      flash('bridge unreachable — is Screenshot Bridge running?', 'error');
    } finally { bridgeBusy = false; }
  }
  // attach() but stamped with the bridge id so the staged-walk can dedupe.
  async function attachBridge(file, shotId) {
    const before = active ? q(active).length : 0;
    await attach(file);
    const list = active ? q(active) : [];
    if (list.length > before) list[list.length - 1].shotId = shotId;
  }
  async function openBridgePicker() {
    if (recentsStrip.style.display === 'flex') { recentsStrip.style.display = 'none'; return; }
    recentsStrip.innerHTML = '<span style="color:var(--muted);font:12px system-ui;align-self:center">loading…</span>';
    recentsStrip.style.display = 'flex';
    try {
      const recent = await (await bridgeFetch('/recent?n=10')).json();
      recentsStrip.innerHTML = '';
      for (const s of recent) {
        const th = document.createElement('img');
        th.src = bridgeUrl('/shot/' + s.id);
        th.loading = 'lazy';
        th.style.cssText = 'width:56px;height:56px;object-fit:cover;border-radius:6px;flex:0 0 auto;cursor:pointer;background:#000';
        th.title = s.name;
        th.onclick = async () => {
          recentsStrip.style.display = 'none';
          try {
            const blob = await (await bridgeFetch('/shot/' + s.id)).blob();
            attachBridge(new File([blob], s.name || 'screenshot.png', { type: blob.type || 'image/png' }), s.id);
          } catch { flash('failed to fetch screenshot', 'error'); }
        };
        recentsStrip.appendChild(th);
      }
      if (!recent.length) recentsStrip.innerHTML = '<span style="color:var(--muted);font:12px system-ui">nothing on the phone</span>';
    } catch {
      recentsStrip.style.display = 'none';
      flash('bridge unreachable', 'error');
    }
  }
  // tap = newest; hold 500ms = picker strip (tmux-web behavior).
  let holdTimer = null, held = false;
  recentsBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    held = false;
    holdTimer = setTimeout(() => { held = true; openBridgePicker(); }, 500);
  });
  recentsBtn.addEventListener('pointercancel', () => clearTimeout(holdTimer));
  recentsBtn.addEventListener('pointerleave', () => clearTimeout(holdTimer));
  recentsBtn.addEventListener('pointerup', (e) => {
    e.preventDefault(); e.stopPropagation();
    clearTimeout(holdTimer);
    if (!held) attachLatestFromBridge();
  });

  function place() {
    const bar = document.getElementById('term-input')?.parentElement;
    if (bar && bar.firstElementChild !== btn) bar.insertBefore(btn, bar.firstElementChild);
    if (bar && btn.nextElementSibling !== recentsBtn) bar.insertBefore(recentsBtn, btn.nextElementSibling);
    const ibar = document.getElementById('term-input')?.parentElement;
    if (ibar && ibar.parentElement && recentsStrip.parentElement !== ibar.parentElement) ibar.parentElement.insertBefore(recentsStrip, ibar);
  }
  place();

  // per-session queue follows the visible session. Seed from the terminal's
  // persisted choice — on hot-reload (or if terminal switched before we loaded)
  // the 'terminal.active' event already fired and we'd otherwise stay null.
  try { active = JSON.parse(localStorage.getItem('terminal:active')); } catch {}
  host.bus.on('terminal.active', ({ session }) => { active = session; paint(); });
}
