// Minimal service worker: required for installability, but deliberately does NO
// caching — a terminal app must never serve a stale shell/transcript. Just
// install + activate + passthrough. (Same stance as mobile-cc's SW.)
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => { /* network passthrough */ });

// Web Push: show a notification; tapping it focuses the app on that session.
self.addEventListener('push', (e) => {
  let d = {}; try { d = e.data.json(); } catch {}
  e.waitUntil(self.registration.showNotification(d.title || 'mobile-agent', {
    body: d.body || '', tag: d.session || 'mobile-agent', data: d, renotify: true,
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  const session = e.notification.data && e.notification.data.session;
  e.waitUntil((async () => {
    const all = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of all) { c.postMessage({ type: 'focus-session', session }); return c.focus(); }
    return self.clients.openWindow('/?session=' + encodeURIComponent(session || ''));
  })());
});
