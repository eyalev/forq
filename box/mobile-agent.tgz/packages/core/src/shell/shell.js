// The shell: connects the WS bus, loads each plugin's frontend module, and hands
// it a scoped `host`. Plugins mount UI into named slots; the kernel never knows
// what they render. Hot-reload: when the kernel says a plugin changed, we tear
// down that plugin's mounted nodes and re-import its module (cache-busted).
let _toastTimer;
const toast = (m) => {
  const el = document.getElementById('toast');
  if (!el) return;
  el.textContent = m;
  el.classList.add('show');
  clearTimeout(_toastTimer);
  _toastTimer = setTimeout(() => { el.classList.remove('show'); el.textContent = ''; }, 2500);
};

// ---- WS bus ----------------------------------------------------------------
let ws;
const sendQ = [];               // outgoing messages buffered until the ws opens
const listeners = new Map(); // `${plugin}:${type}` -> Set(fn)
const coreListeners = new Set();
// Base-path awareness: the shell may be served under a reverse-proxy prefix
// (e.g. opendev.page/t/<id>/ — the proxy strips the prefix before the kernel
// sees the path, so only the FRONTEND needs to prepend it). At root, BASE='/'
// and u() is a no-op.
const BASE = location.pathname.endsWith('/') ? location.pathname : location.pathname.replace(/[^/]*$/, '');
const u = (p) => (BASE === '/' ? p : BASE.slice(0, -1) + p);
window.__APP_BASE = BASE;

function busSend(plugin, type, payload) {
  const msg = JSON.stringify({ plugin, type, payload });
  if (ws && ws.readyState === 1) ws.send(msg);
  else sendQ.push(msg);
}
let wsFails = 0;
// A dead BACKEND (host machine slept/recycled while the tab was backgrounded)
// can't be fixed by WS retries — the page spun "reconnecting…" forever (user
// report, returning to the PWA). After a few straight failures, probe the
// page URL: if the host isn't serving us normally anymore, a full reload
// lands on the platform's boot/starting flow and recovers end-to-end.
async function checkBackendGone() {
  try {
    const r = await fetch(location.href, { cache: 'no-store', headers: { accept: 'text/html' } });
    if (!r.ok) location.reload();
  } catch { location.reload(); }
}
// Returning to a backgrounded PWA with a dead socket: don't wait for the
// retry cadence — probe immediately so recovery starts the moment the user
// looks at the screen.
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible' && (!ws || ws.readyState !== 1)) checkBackendGone();
});
function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}${BASE === '/' ? '' : BASE}`);
  ws.onopen = () => { wsFails = 0; toast('live'); sendQ.splice(0).forEach((m) => ws.send(m)); busEmit('shell.connected'); };
  ws.onclose = () => {
    toast('reconnecting…'); busEmit('shell.disconnected');
    if (++wsFails >= 3 && wsFails % 3 === 0) checkBackendGone();
    setTimeout(connect, Math.min(1000 * wsFails, 5000));
  };
  ws.onmessage = (e) => {
    const m = JSON.parse(e.data);
    if (m.plugin === '$core') {
      if (m.type === 'hello') window.__ME = m.payload && m.payload.you;
      if (m.type === 'presence') busEmit('shell.presence', m.payload);
      coreListeners.forEach((fn) => fn(m));
      return;
    }
    const set = listeners.get(`${m.plugin}:${m.type}`);
    if (set) set.forEach((fn) => fn(m.payload));
  };
}

// ---- client-side cross-plugin bus ------------------------------------------
// Lets plugins talk to each other in the browser (e.g. tabs -> terminal switch)
// without going through a backend. Subscriptions are tracked per-plugin so
// hot-reload can drop the old instance's listeners.
const appBus = new Map();        // topic -> Set(fn)
const busSubs = new Map();       // pluginId -> Set(unsub)
function busEmit(topic, data) { const s = appBus.get(topic); if (s) [...s].forEach((fn) => fn(data)); }
function busOn(id, topic, fn) {
  if (!appBus.has(topic)) appBus.set(topic, new Set());
  appBus.get(topic).add(fn);
  const unsub = () => appBus.get(topic).delete(fn);
  if (!busSubs.has(id)) busSubs.set(id, new Set());
  busSubs.get(id).add(unsub);
  return unsub;
}

// ---- per-plugin host -------------------------------------------------------
const mounted = new Map(); // pluginId -> Set(node)
function makeHost(id) {
  return {
    id,
    // mount an element into a named slot; tracked so hot-reload can remove it
    mount(slotName, el) {
      const slot = document.getElementById(`slot-${slotName}`);
      if (!slot) throw new Error(`no slot '${slotName}'`);
      el.dataset.plugin = id;   // lets layouts target per-plugin contributions
      slot.appendChild(el);
      if (!mounted.has(id)) mounted.set(id, new Set());
      mounted.get(id).add(el);
      return el;
    },
    // ws bus, scoped to this plugin's backend
    send: (type, payload) => busSend(id, type, payload),
    on(type, fn) {
      const key = `${id}:${type}`;
      if (!listeners.has(key)) listeners.set(key, new Set());
      listeners.get(key).add(fn);
    },
    // plugin REST: GET /api/p/<id>/<subpath>
    api: (subpath, init) => fetch(u(`/api/p/${id}/${subpath}`), init),
    // client-side cross-plugin bus
    bus: { emit: busEmit, on: (topic, fn) => busOn(id, topic, fn) },
    // simple scoped client storage (server-sync can come later)
    storage: {
      get: (k) => { try { return JSON.parse(localStorage.getItem(`${id}:${k}`)); } catch { return null; } },
      set: (k, v) => localStorage.setItem(`${id}:${k}`, JSON.stringify(v)),
    },
    log: (...a) => console.log(`[${id}]`, ...a),
  };
}

function unmount(id) {
  const set = mounted.get(id);
  if (set) { set.forEach((n) => n.remove()); set.clear(); }
  // drop this plugin's bus listeners so re-import doesn't double-fire
  for (const key of [...listeners.keys()]) if (key.startsWith(`${id}:`)) listeners.delete(key);
  const bs = busSubs.get(id);
  if (bs) { bs.forEach((unsub) => unsub()); bs.clear(); }
}

// Report client-side failures to the kernel (journald JSONL) — the server
// can't see a fetch we never completed, so it needs our view of it.
// plugins can toast via the bus
busOn('$shell', 'toast', (p) => { if (p && p.text) toast(p.text); });

const clientLog = (rec) => { try { fetch(u('/api/client-log'), { method: 'POST', body: JSON.stringify({ ua: navigator.userAgent.slice(0, 120), ...rec }) }); } catch {} };

async function loadFrontend(id, v) {
  unmount(id);
  // Retry the import: a flaky connection/proxy must not permanently brick the
  // UI (a single failed import() previously meant a black screen until manual
  // reload). Module fetches don't auto-retry the way fetch() does.
  let lastErr = null;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      // Stable version key (frontend mtime from /api/instance) so the browser
      // cache actually works across page loads; Date.now() fallback only for
      // hot-reload pushes where freshness beats cacheability.
      const mod = await import(u(`/plugins/${id}/frontend.js?v=${v || Date.now()}`));
      const init = mod.default || mod;
      await init(makeHost(id));
      if (attempt > 1) clientLog({ ev: 'import-recovered', plugin: id, attempt });
      return;
    } catch (e) {
      lastErr = e;
      clientLog({ ev: 'import-fail', plugin: id, attempt, err: String(e && e.message || e) });
      if (attempt < 3) await new Promise((r) => setTimeout(r, attempt * 700));
    }
  }
  console.error(`[shell] plugin '${id}' frontend failed after retries:`, lastErr);
  toast(`plugin ${id} error`);
}

// ---- boot ------------------------------------------------------------------
const loadedFrontends = new Set();
const SAFE = new URLSearchParams(location.search).get('safe') === '1';
// ?ui=<mode>: the app's named frontend subset (kernel `uiModes`), e.g. minimal.
const UI = new URLSearchParams(location.search).get('ui') || '';
if (UI) document.documentElement.dataset.ui = UI;

// Serialize syncs: two 'plugins-changed' events arriving close together would
// otherwise both observe a plugin as not-yet-loaded and mount it twice (dup UI
// in every slot). Chain each sync after the previous one finishes.
let syncChain = Promise.resolve();
function syncPlugins() {
  syncChain = syncChain.then(_syncPlugins, _syncPlugins);
  return syncChain;
}
async function _syncPlugins() {
  // reconcile loaded frontend plugins with the server's current set (handles
  // enable/disable/add/remove live). Safe mode skips USER frontend plugins.
  const q = new URLSearchParams();
  if (SAFE) q.set('safe', '1');
  if (UI) q.set('ui', UI);
  const qs = q.toString();
  const inst = await (await fetch(u(`/api/instance${qs ? '?' + qs : ''}`))).json();
  document.title = inst.appName;
  const want = new Set(inst.plugins.filter((p) => p.frontend && !(SAFE && p.user)).map((p) => p.id));
  for (const id of [...loadedFrontends]) if (!want.has(id)) { unmount(id); loadedFrontends.delete(id); } // gone/disabled
  for (const p of inst.plugins) if (want.has(p.id) && !loadedFrontends.has(p.id)) { loadedFrontends.add(p.id); await loadFrontend(p.id, p.v); }
  return inst;
}

async function boot() {
  connect();
  if (SAFE) toast('safe mode');
  await syncPlugins();
  coreListeners.add((m) => {
    if (m.type === 'plugin-reloaded') {
      const { id, ok, error, disabled } = m.payload;
      if (disabled) { unmount(id); loadedFrontends.delete(id); return; }
      if (ok === false) { toast(`⚠ ${id}: ${error || 'load error'}`); return; }
      loadFrontend(id); loadedFrontends.add(id); toast(`✓ ${id} reloaded`);
    } else if (m.type === 'plugins-changed') {
      syncPlugins();
    }
  });
}
boot();

// PWA: register the (no-cache) service worker so the app is installable
// Under a proxy prefix the embedding app owns the service-worker scope —
// registering ours there would fight it (and /sw.js wouldn't resolve anyway).
if ('serviceWorker' in navigator && BASE === '/') navigator.serviceWorker.register('/sw.js').catch(() => {});
