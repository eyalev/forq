// appcore kernel — pure mechanism. It hosts plugins; it has no idea what a
// terminal is. A "plugin" is a directory with a plugin.json and an optional
// backend.js (runs here, in node) and/or frontend.js (shipped to the browser).
//
// Design notes (hard-won from the Rust project):
//  - Full-stack plugins: the terminal can't be frontend-only, so backend plugins
//    can register HTTP routes + WS message handlers and broadcast to clients.
//  - Error isolation: a throwing plugin is logged + skipped; the kernel stays up.
//    This is load-bearing for the self-programming story (agent-written plugins
//    will be broken sometimes and must never white-screen the app).
//  - Hot reload: edit a plugin file -> backend re-setup + clients re-import. No
//    rebuild, ever. (Kills the include_bytes!/mcc-build bottleneck.)
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { WebSocketServer } = require('ws');

const SHELL_DIR = path.join(__dirname, 'shell');

// How long a mounted upstream gets to answer. Generous on purpose: a sleeping
// remote computer's cold boot can take a minute, and its host answers that with
// its own styled "starting" page — which must reach the phone VERBATIM. At 30s
// we timed out first and replaced that real state with our own 502. Still
// finite, so an upstream that accepts and then goes silent fails rather than
// hanging a phone forever. Override per mount with `timeoutMs`.
const MOUNT_TIMEOUT_MS = 90_000;

// --- cross-origin defense ---------------------------------------------------
// The daemon binds loopback but is reachable by any WEB PAGE the user visits:
// browsers do NOT apply CORS to WebSockets, so evil.example could open our ws
// and drive the terminal (create/kill sessions, inject keystrokes) — a real
// drive-by RCE, verified with a PoC. HTTP state-changing routes have the same
// CSRF exposure. Defense = same-origin enforcement: a browser stamps every
// cross-origin request/upgrade with an Origin it cannot forge, and we require
// it to match the Host we were reached on. Non-browser clients (curl, the app's
// own server-side calls) send no Origin and are allowed — anything that can
// omit Origin against loopback already has local code execution, which is a
// strictly higher privilege than this guard protects.
function hostOf(v) { try { return new URL(v).host.toLowerCase(); } catch { return null; } }
function originAllowed(origin, hostHeader, extra) {
  if (!origin) return true;                       // no Origin => not a browser cross-origin request
  const oh = hostOf(origin);
  if (!oh) return false;                          // malformed Origin => reject
  if (hostHeader && oh === String(hostHeader).toLowerCase()) return true; // same-origin
  return extra.has(oh);                           // explicit allowlist (APPCORE_ALLOW_ORIGINS)
}

function jsonResp(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'content-type': 'application/json' });
  res.end(body);
}
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
  '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml' };
function serveFile(res, fp) {
  fs.readFile(fp, (err, body) => {
    if (err) { res.writeHead(404); res.end('not found'); return; }
    res.writeHead(200, { 'content-type': MIME[path.extname(fp)] || 'application/octet-stream' });
    res.end(body);
  });
}

class Kernel {
  constructor(opts = {}) {
    this.appName = opts.appName || 'appcore';
    this.bind = opts.bind || '127.0.0.1:7901';
    this.pluginDirs = opts.pluginDirs || [];      // shipped plugin dirs (each a single plugin)
    this.configDir = opts.configDir || path.join(process.env.HOME, '.config', 'appcore');
    this.userPluginsDir = opts.userPluginsDir || path.join(this.configDir, 'plugins'); // user/agent-authored plugins (override shipped by id)
    this.configFile = path.join(this.configDir, 'config.json'); // runtime malleability: { disabled:[], order:[] }
    this.pluginConfig = opts.pluginConfig || {};  // { pluginId: {...} }
    // UI modes: named subsets of FRONTENDS an app offers, picked per page load
    // with ?ui=<mode> (e.g. mobile-agent's `minimal` for embedding in another
    // page). Backends are unaffected — only which frontends the shell loads.
    // Neutral: the kernel knows names and id lists, nothing about what they mean.
    this.uiModes = opts.uiModes || {};  // { mode: [pluginId, ...] }
    // Reverse-proxy mounts: [{prefix, target, headers}]. Generic mechanism —
    // the kernel has no idea WHAT it proxies. A path starting with `prefix` is
    // forwarded (HTTP and WS upgrades alike) to `target` + the original path,
    // with `headers` (typically a server-side session cookie) applied. This is
    // what lets a remote computer's UI live on OUR origin: same-origin means no
    // iframe (Android Chrome's OOPIF renderer hangs on nested app frames), and
    // the credential never reaches the browser.
    this.mounts = (opts.mounts || []).filter((m) => m && m.prefix && m.target)
      .map((m) => ({ ...m, target: String(m.target).replace(/\/+$/, '') }));
    this.proxySockets = new Set();                  // live upgraded proxy sockets, destroyed by stop()
    // Path rewrites: [{from, to}], exact pathname match, applied before local
    // routing. Also mechanism-only. Needed because a page served THROUGH a mount
    // still resolves its own root-relative URLs against OUR origin — so a path
    // the upstream origin used to answer has to be answerable here too.
    this.rewrites = (opts.rewrites || []).filter((r) => r && r.from && r.to);
    this.userDirs = new Map();                      // id -> dir, for plugins discovered under userPluginsDir
    this.plugins = new Map();                       // id -> { dir, manifest, routes, handlers, teardown, user }
    this.clients = new Set();                       // ws connections
    this.events = new Map();                        // backend cross-plugin event bus: name -> Set(fn)
    this.disconnectHandlers = new Set();            // fn(ws) called when a client disconnects
    this.watched = new Set();                        // dirs already being watched
    this.watchers = new Set();                       // FSWatcher handles, closed by stop()
    this.onUserEdit = null;                          // optional hook(id) before a user-plugin reload (auto-checkpoint)
    // extra origins a browser may legitimately connect from (comma-separated
    // host[:port], scheme optional), beyond same-origin. e.g. an emulator's
    // 10.0.2.2 mapping or a reverse proxy that rewrites Host.
    this.allowOrigins = new Set(
      [...(opts.allowOrigins || []), ...String(process.env.APPCORE_ALLOW_ORIGINS || '').split(',')]
        .map((s) => (s || '').trim()).filter(Boolean)
        .map((s) => hostOf(s.includes('://') ? s : `http://${s}`) || s.toLowerCase()));
    fs.mkdirSync(path.join(this.configDir, 'state'), { recursive: true });
    fs.mkdirSync(this.userPluginsDir, { recursive: true });
  }

  // ---- scoped persistent storage (per-key merge, never whole-object clobber) --
  _storage(id) {
    const file = path.join(this.configDir, 'state', `${id}.json`);
    const read = () => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; } };
    const write = (o) => fs.writeFileSync(file, JSON.stringify(o, null, 2));
    return {
      get: (k) => read()[k],
      set: (k, v) => { const o = read(); o[k] = v; write(o); },   // single key only
      all: () => read(),
    };
  }

  // ---- the context handed to each backend plugin's setup() -------------------
  _ctx(id, dir) {
    const p = this.plugins.get(id);
    return {
      id,
      dir,
      config: this.pluginConfig[id] || {},
      configDir: this.configDir,
      log: (...a) => console.log(`[${id}]`, ...a),
      storage: this._storage(id),
      // register a GET route, served at /api/p/<id>/<subpath>
      route: (subpath, handler) => { p.routes.set(subpath.replace(/^\//, ''), handler); },
      // handle ws messages {plugin:id, type}; handler(payload, client)
      on: (type, handler) => { p.handlers.set(type, handler); },
      // push {plugin:id, type, payload} to every connected client
      broadcast: (type, payload) => {
        const msg = JSON.stringify({ plugin: id, type, payload });
        for (const c of this.clients) if (c.readyState === 1) c.send(msg);
      },
      // backend cross-plugin events (e.g. terminal -> push on a CC prompt)
      emit: (name, data) => { const s = this.events.get(name); if (s) for (const fn of s) { try { fn(data); } catch (e) { console.error(`[event ${name}]`, e.message); } } },
      // called with the ws when any client disconnects (for cleanup/restore)
      onDisconnect: (fn) => {
        this.disconnectHandlers.add(fn);
        p.eventUnsubs.push(() => this.disconnectHandlers.delete(fn));
      },
      // register a hook(id) fired just before a USER plugin reloads (auto-checkpoint)
      onUserEdit: (fn) => { this.onUserEdit = fn; },
      // force a re-scan/reload of all plugins (e.g. after a git revert changes files)
      reloadAll: () => { this.loadAll(); this._broadcastCore('plugins-changed', {}); },
      onEvent: (name, fn) => {
        if (!this.events.get(name)) this.events.set(name, new Set());
        this.events.get(name).add(fn);
        p.eventUnsubs.push(() => this.events.get(name).delete(fn));
      },
    };
  }

  // ---- load / unload / reload a single plugin (error-isolated) ---------------
  _unload(id) {
    const p = this.plugins.get(id);
    if (!p) return;
    try { if (typeof p.teardown === 'function') p.teardown(); } catch (e) { console.error(`[${id}] teardown threw`, e.message); }
    for (const u of p.eventUnsubs) { try { u(); } catch {} } // drop this plugin's backend event subs
    this.plugins.delete(id);
  }

  // runtime config: { disabled:[ids], order:[ids] } — the malleability data
  readConfig() {
    try { return JSON.parse(fs.readFileSync(this.configFile, 'utf8')); } catch { return {}; }
  }

  loadPlugin(dir, user = false) {
    let manifest;
    try { manifest = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8')); }
    catch (e) { console.error(`[kernel] bad plugin.json in ${dir}: ${e.message}`); return; }
    const id = manifest.id;
    if (!id) { console.error(`[kernel] plugin.json missing id in ${dir}`); return; }
    if ((this.readConfig().disabled || []).includes(id)) { this._unload(id); return { id, ok: true, disabled: true }; } // disabled via config
    this._unload(id);
    const p = { dir, manifest, routes: new Map(), handlers: new Map(), teardown: null, eventUnsubs: [], user };
    this.plugins.set(id, p);
    if (manifest.backend) {
      const bp = path.join(dir, manifest.backend);
      try {
        // Hot-reload: drop EVERY cached module that lives inside this plugin's
        // dir, not just the entry point. A plugin is allowed to be several
        // files (terminal has serialize.js, router has reply.js) and caching
        // those made edits to them silently no-ops — the reload said "✓
        // reloaded" while the old code kept running, which is worse than no
        // hot-reload at all.
        const inDir = dir.endsWith(path.sep) ? dir : dir + path.sep;
        for (const k of Object.keys(require.cache)) if (k.startsWith(inDir)) delete require.cache[k];
        const mod = require(bp);
        const setup = mod.default || mod;
        const t = setup(this._ctx(id, dir));                  // run plugin's setup
        if (typeof t === 'function') p.teardown = t;
        console.log(`[kernel] loaded ${id} (backend${manifest.frontend ? '+frontend' : ''})`);
      } catch (e) {
        console.error(`[kernel] plugin '${id}' backend failed to load: ${e.message}`);
        return { id, ok: false, error: e.message }; // keep entry so frontend/manifest still serve
      }
    } else {
      console.log(`[kernel] loaded ${id} (frontend only)`);
    }
    return { id, ok: true };
  }

  _idOf(dir) { try { return JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8')).id; } catch { return null; } }

  // Discover all plugins (shipped + user dir; user overrides shipped by id),
  // apply config order, (re)load them. This is the malleability entry point.
  loadAll() {
    const byId = new Map();
    for (const dir of this.pluginDirs) { const id = this._idOf(dir); if (id) byId.set(id, { dir, user: false }); }
    this.userDirs.clear();
    try {
      for (const name of fs.readdirSync(this.userPluginsDir)) {
        const dir = path.join(this.userPluginsDir, name);
        try { if (!fs.statSync(dir).isDirectory()) continue; } catch { continue; }
        const id = this._idOf(dir); if (!id) continue;
        byId.set(id, { dir, user: true });        // user/agent plugin overrides shipped of same id
        this.userDirs.set(id, dir);
      }
    } catch {}
    const order = this.readConfig().order || [];
    const ids = [...byId.keys()].sort((a, b) => {
      const ia = order.indexOf(a), ib = order.indexOf(b);
      if (ia === -1 && ib === -1) return 0;
      if (ia === -1) return 1; if (ib === -1) return -1;
      return ia - ib;
    });
    for (const id of [...this.plugins.keys()]) this._unload(id);
    for (const id of ids) { const { dir, user } = byId.get(id); this.loadPlugin(dir, user); this._ensureWatch(dir, id, user); }
  }

  // every known plugin (shipped + user), incl. disabled, for the Customize panel
  availablePlugins() {
    const cfg = this.readConfig();
    const disabled = new Set(cfg.disabled || []);
    const order = cfg.order || [];
    const byId = new Map();
    const add = (dir, user) => { try { const m = JSON.parse(fs.readFileSync(path.join(dir, 'plugin.json'), 'utf8')); if (m.id) byId.set(m.id, { id: m.id, name: m.name || m.id, user, enabled: !disabled.has(m.id) }); } catch {} };
    for (const dir of this.pluginDirs) add(dir, false);
    try { for (const name of fs.readdirSync(this.userPluginsDir)) { const dir = path.join(this.userPluginsDir, name); try { if (fs.statSync(dir).isDirectory()) add(dir, true); } catch {} } } catch {}
    const arr = [...byId.values()];
    arr.sort((a, b) => { const ia = order.indexOf(a.id), ib = order.indexOf(b.id); if (ia === -1 && ib === -1) return 0; if (ia === -1) return 1; if (ib === -1) return -1; return ia - ib; });
    return arr;
  }

  _broadcastCore(type, payload) {
    const msg = JSON.stringify({ plugin: '$core', type, payload });
    for (const c of this.clients) if (c.readyState === 1) c.send(msg);
  }

  // watch a single plugin dir for edits -> hot-reload that plugin + toast status
  _ensureWatch(dir, id, user = false) {
    if (this.watched.has(dir)) return;
    this.watched.add(dir);
    let timer = null;
    try {
      this.watchers.add(fs.watch(dir, { recursive: true }, () => {
        clearTimeout(timer);
        timer = setTimeout(() => {
          if (this.onUserEdit && user) { try { this.onUserEdit(id); } catch {} } // e.g. auto-checkpoint
          console.log(`[kernel] hot-reload ${id}`);
          const status = this.loadPlugin(dir, user) || { id, ok: true };
          this._broadcastCore('plugin-reloaded', status);
        }, 150);
      }));
    } catch (e) { console.error(`[kernel] watch failed for ${id}: ${e.message}`); }
  }

  // watch the user-plugins container for ADDED/REMOVED plugins -> rediscover
  _watchContainer() {
    let timer = null;
    try {
      this.watchers.add(fs.watch(this.userPluginsDir, () => {
        clearTimeout(timer);
        timer = setTimeout(() => { this.loadAll(); this._broadcastCore('plugins-changed', {}); }, 200);
      }));
    } catch (e) { console.error('[kernel] container watch failed:', e.message); }
  }

  // watch config.json -> re-apply enable/disable/order live
  _watchConfig() {
    let timer = null;
    try {
      this.watchers.add(fs.watch(this.configDir, (_e, f) => {
        if (f !== 'config.json') return;
        clearTimeout(timer);
        timer = setTimeout(() => { this.loadAll(); this._broadcastCore('plugins-changed', {}); }, 150);
      }));
    } catch {}
  }

  // ---- reverse-proxy mounts --------------------------------------------------
  _mountFor(u) { return this.mounts.find((m) => String(u || '').startsWith(m.prefix)); }

  // Build the upstream header set. Three rules here are load-bearing:
  //  - `origin` is REWRITTEN to the target origin. The upstream chain runs the
  //    same same-origin check we do; forwarding our tailnet/loopback Origin
  //    against Host `<target>` would get every WS upgrade and POST rejected.
  //  - `cookie` is REPLACED, never merged: the client's cookies must not reach
  //    upstream, and upstream's credential lives only here on the server.
  //  - `x-opendev-*` are stripped: those are injected by a trusted proxy and
  //    read as identity/read-only flags (_handleWs). A client must not smuggle them.
  _proxyHeaders(mnt, req, isUpgrade) {
    const h = { ...req.headers };
    const t = new URL(mnt.target);
    h.host = t.host;
    if (h.origin) h.origin = t.origin;
    for (const k of Object.keys(h)) if (/^x-opendev-/i.test(k)) delete h[k];
    delete h.cookie;
    delete h['x-forwarded-for']; delete h['x-forwarded-host']; delete h['x-forwarded-proto'];
    if (!isUpgrade) for (const k of ['connection', 'keep-alive', 'transfer-encoding', 'upgrade', 'te', 'trailer', 'proxy-authorization', 'proxy-authenticate']) delete h[k];
    for (const [k, v] of Object.entries(mnt.headers || {})) h[k.toLowerCase()] = v;
    return h;
  }

  _proxyHttp(mnt, req, res) {
    const target = new URL(req.url, mnt.target + '/');
    const mod = target.protocol === 'https:' ? https : http;
    const preq = mod.request(target, { method: req.method, headers: this._proxyHeaders(mnt, req, false), timeout: mnt.timeoutMs || MOUNT_TIMEOUT_MS }, (pres) => {
      const out = { ...pres.headers };
      for (const k of ['connection', 'keep-alive', 'transfer-encoding', 'te', 'trailer', 'upgrade']) delete out[k];
      res.writeHead(pres.statusCode, out);
      pres.pipe(res);
      pres.on('error', () => res.destroy());
    });
    preq.on('timeout', () => preq.destroy(new Error('upstream timeout')));
    preq.on('error', (e) => {
      console.log(JSON.stringify({ ts: new Date().toISOString(), ev: 'mount-http-err', prefix: mnt.prefix, u: req.url, err: String((e && e.message) || e) }));
      if (res.headersSent) return res.destroy();
      res.writeHead(502, { 'content-type': 'application/json' });
      res.end('{"error":"upstream unreachable"}');
    });
    req.pipe(preq);
    req.on('error', () => preq.destroy());
  }

  _proxyUpgrade(mnt, req, socket, head) {
    const target = new URL(req.url, mnt.target + '/');
    const mod = target.protocol === 'https:' ? https : http;
    const kill = () => { try { socket.destroy(); } catch {} };
    const preq = mod.request(target, { method: req.method || 'GET', headers: this._proxyHeaders(mnt, req, true) });
    preq.on('upgrade', (pres, upSocket, upHead) => {
      const lines = [`HTTP/1.1 ${pres.statusCode} ${pres.statusMessage || 'Switching Protocols'}`];
      for (const [k, v] of Object.entries(pres.headers)) {
        if (Array.isArray(v)) v.forEach((x) => lines.push(`${k}: ${x}`));
        else lines.push(`${k}: ${v}`);
      }
      try { socket.write(lines.join('\r\n') + '\r\n\r\n'); } catch { return upSocket.destroy(); }
      if (upHead && upHead.length) socket.write(upHead);
      if (head && head.length) upSocket.write(head);
      socket.setNoDelay(true); upSocket.setNoDelay(true);
      this.proxySockets.add(socket); this.proxySockets.add(upSocket);
      const done = () => { this.proxySockets.delete(socket); this.proxySockets.delete(upSocket); try { socket.destroy(); } catch {} try { upSocket.destroy(); } catch {} };
      upSocket.on('error', done); socket.on('error', done);
      upSocket.on('close', done); socket.on('close', done);
      upSocket.pipe(socket); socket.pipe(upSocket);
    });
    // upstream answered without upgrading (403, 502, cold-boot page): relay it
    // verbatim so the client sees the real reason instead of a bare socket drop.
    preq.on('response', (pres) => {
      const lines = [`HTTP/1.1 ${pres.statusCode} ${pres.statusMessage || ''}`];
      for (const [k, v] of Object.entries(pres.headers)) {
        if (k.toLowerCase() === 'transfer-encoding') continue;
        if (Array.isArray(v)) v.forEach((x) => lines.push(`${k}: ${x}`));
        else lines.push(`${k}: ${v}`);
      }
      try { socket.write(lines.join('\r\n') + '\r\n\r\n'); } catch {}
      pres.on('data', (c) => { try { socket.write(c); } catch {} });
      pres.on('end', kill);
      pres.on('error', kill);
    });
    preq.on('error', (e) => {
      console.log(JSON.stringify({ ts: new Date().toISOString(), ev: 'mount-ws-err', prefix: mnt.prefix, u: req.url, err: String((e && e.message) || e) }));
      kill();
    });
    socket.on('error', () => preq.destroy());
    preq.end();
  }

  // ---- http routing ----------------------------------------------------------
  _handleHttp(req, res) {
    // JSONL access log (journald): one line per request, plus a distinct line
    // when the client vanishes before the response finished (reset socket) —
    // that's invisible in a status-only log but is exactly what "browser says
    // Failed to fetch, server says 200" looks like from this side.
    const t0 = Date.now();
    const jlog = (rec) => console.log(JSON.stringify({ ts: new Date().toISOString(), ...rec }));
    req.on('error', (e) => jlog({ ev: 'http-req-err', m: req.method, u: req.url, err: String(e && e.message || e) }));
    res.on('error', (e) => jlog({ ev: 'http-res-err', m: req.method, u: req.url, err: String(e && e.message || e) }));
    res.on('close', () => { if (!res.writableEnded) jlog({ ev: 'http-client-gone', m: req.method, u: req.url, ms: Date.now() - t0 }); });
    res.on('finish', () => jlog({ ev: 'http', m: req.method, u: req.url, st: res.statusCode, ms: Date.now() - t0 }));
    // CSRF guard: a cross-origin browser must not be able to hit a mutating
    // route. GETs stay open (same-origin policy already stops a foreign page
    // reading the response, and our GETs don't mutate). Non-mutating verbs and
    // Origin-less (non-browser) callers pass through.
    if (req.method !== 'GET' && req.method !== 'HEAD' && !originAllowed(req.headers.origin, req.headers.host, this.allowOrigins)) {
      jlog({ ev: 'http-origin-reject', m: req.method, u: req.url, origin: req.headers.origin || null, host: req.headers.host || null });
      res.writeHead(403, { 'content-type': 'application/json' });
      return res.end('{"error":"cross-origin request refused"}');
    }
    // Reverse-proxy mounts run AFTER the CSRF guard above (so a foreign page
    // can't POST through us to a remote computer) but before any local routing.
    const mnt = this._mountFor(req.url);
    if (mnt) return this._proxyHttp(mnt, req, res);
    if (this.rewrites.length) {
      const q = req.url.indexOf('?');
      const rw = this.rewrites.find((r) => r.from === (q === -1 ? req.url : req.url.slice(0, q)));
      if (rw) req.url = rw.to + (q === -1 ? '' : req.url.slice(q));
    }
    const url = new URL(req.url, 'http://x');
    const pathname = url.pathname;
    // core api
    // client-side error reports (import failures, boot issues) — the server's
    // access log can't see a fetch the client never managed to make, so the
    // shell reports its own view here. Same JSONL journald sink as the access log.
    if (pathname === '/api/client-log' && req.method === 'POST') {
      let body = '';
      req.on('data', (c) => { body += c; if (body.length > 4096) req.destroy(); });
      req.on('end', () => {
        try { const rec = JSON.parse(body); jlog({ ev: 'client', ...rec }); } catch { jlog({ ev: 'client', raw: body.slice(0, 500) }); }
        res.writeHead(204); res.end();
      });
      return;
    }
    if (pathname === '/api/instance') {
      const safe = url.searchParams.get('safe') === '1';
      const ui = url.searchParams.get('ui') || '';
      const only = Object.prototype.hasOwnProperty.call(this.uiModes, ui) ? new Set(this.uiModes[ui]) : null;
      return jsonResp(res, 200, {
        appName: this.appName,
        safe,
        ui: only ? ui : null,
        plugins: [...this.plugins.values()].map((p) => {
          // v = frontend.js mtime: a STABLE cache key. The shell used to bust
          // with Date.now() on every load, defeating HTTP caching entirely —
          // reloads re-fetched every plugin through the proxy (slow computer
          // switching on phones). mtime changes exactly when the code does.
          let v = 0;
          try { v = Math.floor(fs.statSync(path.join(p.dir, 'frontend.js')).mtimeMs); } catch {}
          return {
            id: p.manifest.id, name: p.manifest.name || p.manifest.id,
            frontend: !!p.manifest.frontend && (!only || only.has(p.manifest.id)), slot: p.manifest.slot || null, user: !!p.user, v,
          };
        }),
        available: this.availablePlugins(), // all known plugins incl. disabled (for the Customize panel)
      });
    }
    // plugin frontend + static assets: /plugins/<id>/<file>
    let m = pathname.match(/^\/plugins\/([^/]+)\/(.+)$/);
    if (m) {
      const p = this.plugins.get(m[1]);
      if (!p) { res.writeHead(404); return res.end('no plugin'); }
      const fp = path.join(p.dir, path.normalize(m[2]).replace(/^(\.\.[/\\])+/, ''));
      return serveFile(res, fp);
    }
    // plugin backend routes: /api/p/<id>/<subpath>
    m = pathname.match(/^\/api\/p\/([^/]+)\/(.+)$/);
    if (m) {
      const p = this.plugins.get(m[1]);
      const h = p && p.routes.get(m[2]);
      if (!h) { res.writeHead(404); return res.end('no route'); }
      try { return h(req, res, url); }
      catch (e) { console.error(`[${m[1]}] route '${m[2]}' threw`, e.message); res.writeHead(500); return res.end('plugin error'); }
    }
    // PWA: SW + manifest must be at root scope so the SW controls '/'
    if (pathname === '/sw.js') return serveFile(res, path.join(SHELL_DIR, 'sw.js'));
    if (pathname === '/manifest.webmanifest') return serveFile(res, path.join(SHELL_DIR, 'manifest.webmanifest'));
    // shell
    if (pathname === '/' ) return serveFile(res, path.join(SHELL_DIR, 'index.html'));
    if (pathname.startsWith('/shell/')) return serveFile(res, path.join(SHELL_DIR, path.basename(pathname)));
    res.writeHead(404); res.end('not found');
  }

  // ---- ws message bus --------------------------------------------------------
  _handleWs(ws, req) {
    // Client identity, injected by the trusted host proxy (never taken from
    // the browser): powers the presence indicator + typing attribution.
    ws._user = String((req && req.headers['x-opendev-user']) || '').slice(0, 80) || null;
    // Read-only viewers (injected by the trusted host proxy, never the
    // browser): may observe the terminal but drive nothing. Enforced here as a
    // whitelist — a viewer connection can only list sessions and subscribe.
    ws._readonly = String((req && req.headers['x-opendev-readonly']) || '') === '1';
    this.clients.add(ws);
    try { ws.send(JSON.stringify({ plugin: '$core', type: 'hello', payload: { you: ws._user, readonly: ws._readonly } })); } catch {}
    this._broadcastPresence();
    const RO_ALLOW = { terminal: new Set(['list', 'sub']) };
    ws.on('message', (raw) => {
      let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
      if (ws._readonly && !(RO_ALLOW[msg.plugin] && RO_ALLOW[msg.plugin].has(msg.type))) return;
      const p = this.plugins.get(msg.plugin);
      const h = p && p.handlers.get(msg.type);
      if (!h) return;
      // targeted reply is scoped to the same plugin so the shell can route it
      const client = {
        id: msg.plugin,
        send: (type, payload) => ws.readyState === 1 && ws.send(JSON.stringify({ plugin: msg.plugin, type, payload })),
        raw: ws,
      };
      try { h(msg.payload, client); }
      catch (e) { console.error(`[${msg.plugin}] handler '${msg.type}' threw`, e.message); }
    });
    ws.on('close', () => {
      this.clients.delete(ws);
      this._broadcastPresence();
      for (const fn of this.disconnectHandlers) { try { fn(ws); } catch (e) { console.error('[disconnect]', e.message); } }
    });
  }

  _broadcastPresence() {
    const users = [...this.clients].filter((c) => c.readyState === 1).map((c) => c._user || 'someone');
    this._broadcastCore('presence', { count: users.length, users });
  }

  start() {
    this.loadAll();           // shipped + user plugins, per config (enable/disable/order)
    this._watchContainer();   // new/removed user plugins
    this._watchConfig();      // live enable/disable/reorder
    const server = http.createServer((req, res) => this._handleHttp(req, res));
    this.server = server;
    // Upgrades are dispatched by hand (noServer) because a mounted prefix must
    // be spliced to its upstream instead of joining our local bus.
    const wss = new WebSocketServer({ noServer: true });
    this.wss = wss;
    wss.on('connection', (ws, req) => this._handleWs(ws, req));
    server.on('upgrade', (req, socket, head) => {
      // Reject the ws HANDSHAKE (not after connect) for a foreign browser Origin —
      // this is the drive-by-RCE fix: without it any page could open our bus.
      // It runs BEFORE the mount dispatch too: we rewrite Origin upstream, so
      // upstream can no longer defend itself; the guard has to live here.
      if (!originAllowed(req.headers.origin, req.headers.host, this.allowOrigins)) {
        console.log(JSON.stringify({ ts: new Date().toISOString(), ev: 'ws-origin-reject', origin: req.headers.origin || null, host: req.headers.host || null }));
        socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
        return socket.destroy();
      }
      const mnt = this._mountFor(req.url);
      if (mnt) return this._proxyUpgrade(mnt, req, socket, head);
      wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
    });
    const [host, port] = this.bind.split(':');
    server.listen(Number(port), host, () => console.log(`[kernel] ${this.appName} on http://${this.bind}`));
    // run plugin teardowns on termination so they can clean up (e.g. restore
    // tmux window sizes they pinned) — node would otherwise exit without them.
    const shutdown = (sig) => {
      if (this._shuttingDown) return; this._shuttingDown = true;
      console.log(`[kernel] ${sig} — running teardowns`);
      this.stop();
      process.exit(0);
    };
    this._onSigterm = () => shutdown('SIGTERM');
    this._onSigint = () => shutdown('SIGINT');
    process.on('SIGTERM', this._onSigterm);
    process.on('SIGINT', this._onSigint);
    return server;
  }

  // Full teardown: plugin teardowns, fs watchers, ws + http server, and the
  // process signal listeners. Without this the kernel could never fully stop —
  // fs.watch handles kept the event loop alive forever (a real leak the tests
  // surfaced; a daemon that can't shut down cleanly can't be embedded/tested).
  stop() {
    for (const id of [...this.plugins.keys()]) this._unload(id);
    for (const w of this.watchers) { try { w.close(); } catch {} }
    this.watchers.clear(); this.watched.clear();
    if (this._onSigterm) process.removeListener('SIGTERM', this._onSigterm);
    if (this._onSigint) process.removeListener('SIGINT', this._onSigint);
    for (const s of this.proxySockets) { try { s.destroy(); } catch {} }
    this.proxySockets.clear();
    try { this.wss && this.wss.close(); } catch {}
    try { if (this.server) { this.server.closeAllConnections && this.server.closeAllConnections(); this.server.close(); } } catch {}
  }
}

module.exports = { Kernel, createKernel: (opts) => new Kernel(opts), originAllowed, hostOf };
