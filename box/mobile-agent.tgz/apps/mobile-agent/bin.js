#!/usr/bin/env node
// The mobile app = the skeleton + a curated plugin set + opinionated config.
// It owns NO terminal logic; it just tells the kernel which plugins to load and
// where the user's own (agent-authored) plugins live.
const path = require('path');
const fs = require('fs');
const { createKernel } = require('appcore');

const REPO = path.resolve(__dirname, '..', '..');
const SHIPPED = path.join(REPO, 'plugins');

// --- tiny flag parse --------------------------------------------------------
const argv = process.argv.slice(2);
const flag = (name, def) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 ? argv[i + 1] : def;
};

const configDir = flag('config-dir', path.join(process.env.HOME, '.config', 'mobile-agent'));
const userPlugins = path.join(configDir, 'plugins'); // where self-authored plugins land

// Extra browser origins allowed beyond same-origin (comma-separated host[:port]).
// Same-origin (incl. tailscale-serve, which preserves Host) works without this;
// use it only for an odd proxy that rewrites Host, or an emulator on 10.0.2.2.
const allowOrigins = String(flag('allow-origin', '') || '').split(',').map((s) => s.trim()).filter(Boolean);

// --- remote computers (optional) --------------------------------------------
// ~/.config/mobile-agent/remotes.json (chmod 600, never committed):
//   { "base": "https://opendev.page", "sessionToken": "<session cookie value>" }
// When present, this app reverse-proxies the control plane's computer paths on
// its OWN origin (/t/<id>/, /c/<id>/agent/) with the token attached SERVER-SIDE,
// and the header's switch-computer strip lists laptop + running cloud boxes.
// The laptop itself stays exactly as exposed as before — nothing inbound opens.
// Absent or malformed => everything below no-ops and the app is unchanged.
let remotes = null;
try {
  const r = JSON.parse(fs.readFileSync(path.join(configDir, 'remotes.json'), 'utf8'));
  if (r && r.base && r.sessionToken) remotes = r;
} catch { /* not configured */ }
const mounts = remotes
  ? ['/t/', '/c/'].map((prefix) => ({ prefix, target: remotes.base, headers: { cookie: 'session=' + remotes.sessionToken } }))
  : [];
// A cloud computer's own page is served through the mount, so ITS header
// resolves the root-relative switcher endpoint (/api/computers, baked into the
// remote by its host) against OUR origin. Answer it with the same merged list,
// so every computer — local or remote — shows the identical switcher strip and
// there is always a chip back to the laptop.
const rewrites = remotes ? [{ from: '/api/computers', to: '/api/p/remotes/computers' }] : [];
// flag > env > (remotes configured ? our own merged endpoint : nothing)
const switcherUrl = flag('switcher-url', process.env.MA_SWITCHER_URL || (remotes ? '/api/p/remotes/computers' : ''));

const kernel = createKernel({
  appName: flag('app-name', 'mobile-agent'),
  bind: flag('bind', '127.0.0.1:7901'),
  configDir,
  allowOrigins,
  mounts,
  rewrites,
  // curated, shipped plugins for this app + the user's own dir (created on demand)
  pluginDirs: [
    path.join(SHIPPED, 'header'),
    path.join(SHIPPED, 'theme'),
    path.join(SHIPPED, 'studio'),
    path.join(SHIPPED, 'ask'),
    path.join(SHIPPED, 'router'),   // one place to ask; it picks the project
    path.join(SHIPPED, 'tabs'),
    path.join(SHIPPED, 'terminal'),
    path.join(SHIPPED, 'model'),
    path.join(SHIPPED, 'overview'),
    path.join(SHIPPED, 'sessions'),
    path.join(SHIPPED, 'download'),
    path.join(SHIPPED, 'images'),
    path.join(SHIPPED, 'voice'),
    path.join(SHIPPED, 'push'),
    path.join(SHIPPED, 'commands'),
    path.join(SHIPPED, 'quickkeys'),
    path.join(SHIPPED, 'usage'),        // local-only UI telemetry (see plugins/usage)
    path.join(SHIPPED, 'layouts'),
    // no-ops (returns []) unless remotes.json exists
    path.join(SHIPPED, 'remotes'),
    path.join(SHIPPED, 'minimal'),      // layout for ?ui=minimal (frontend loads only in that mode)
  ],
  // ?ui=minimal — the terminal, one row of keys and the input; nothing else.
  // For embedding (forq's agent sheet) where the host page owns navigation,
  // sessions and chat. Backends all still run.
  uiModes: {
    minimal: ['terminal', 'quickkeys', 'minimal'],
  },
  pluginConfig: {
    header: {
      name: flag('app-name', 'mobile-agent'),
      // Optional ⌂ link in the header (e.g. the OpenDev dashboard).
      homeUrl: flag('home-url', process.env.MA_HOME_URL || ''),
      // Same-origin endpoint returning [{name,url}] — renders the
      // switch-computer strip when present.
      switcherUrl,
    },
    remotes: {
      base: (remotes && remotes.base) || '',
      sessionToken: (remotes && remotes.sessionToken) || '',
      localName: flag('app-name', 'mobile-agent'),
    },
    // sessionFilter = which tmux sessions show up as tabs (regex).
    // Default is EMPTY = show every tmux session, which is the only sensible
    // first run for someone who just installed this: whatever they already have
    // open shows up. Narrow it with --session-filter '^(work|api)' once you have
    // more sessions than you want as tabs.
    terminal: {
      sessionFilter: flag('session-filter', ''),
      // Where created sessions live; relative folder names from the create
      // dialog resolve (and are created) under this. Flag > env > $HOME.
      defaultCwd: flag('default-cwd', process.env.MA_DEFAULT_CWD || process.env.HOME || '/'),
    },
  },
});
kernel.start();
console.log(`[mobile] user plugins dir: ${userPlugins}`);
